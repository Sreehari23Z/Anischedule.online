<?php
// ============================================================
//  Anime Detail Page  — /anime.php?id=<mal_id>
//  Shell renders instantly; data loads via JS → api/anime-detail.php
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: /');
    exit;
}

// Fetch anime data server-side for SEO title/description/schema
$page_title    = 'Anime Details — ' . SITE_NAME;
$page_desc     = 'Watch this anime online. Get episode schedule, air times, streaming links, and more.';
$page_keywords = 'anime, watch anime, anime schedule, anime episodes, anime streaming';
$og_image      = SITE_URL . '/assets/img/logo.png';
$json_ld       = '';
$active_nav    = '';

try {
    require_once __DIR__ . '/api/anilist.php';
    $anime = jikan_anime($id);
    if ($anime) {
        $title     = $anime['title_english'] ?: $anime['title'];
        $title_jp  = $anime['title_japanese'] ?? '';
        $score     = $anime['score'] ?? null;
        $synopsis  = $anime['synopsis'] ?? '';
        $cover     = $anime['images']['jpg']['large_image_url'] ?? '';
        $genres    = implode(', ', array_column($anime['genres'] ?? [], 'name'));
        $status    = $anime['status'] ?? '';
        $episodes  = $anime['episodes'] ?? null;
        $bday      = $anime['broadcast']['day'] ?? '';
        $btime     = $anime['broadcast']['time'] ?? '';

        $page_title    = $title . ' — Watch Schedule, Air Times & Episodes | AniSchedule';
        $page_desc     = trim(substr(strip_tags($synopsis), 0, 155)) ?: "Watch $title online. Schedule, air times, streaming links, and episode guide.";
        $page_keywords = "$title, $title_jp, $title anime, $title episodes, $title schedule, $genres, watch anime online, anime air time";
        $og_image      = $cover ?: $og_image;
        $og_type       = 'video.tv_show';

        // JSON-LD TVSeries schema
        $schemaData = [
            '@context'    => 'https://schema.org',
            '@type'       => 'TVSeries',
            'name'        => $title,
            'url'         => SITE_URL . '/anime.php?id=' . $id,
            'image'       => $cover,
            'description' => substr(strip_tags($synopsis), 0, 300),
            'genre'       => array_column($anime['genres'] ?? [], 'name'),
            'numberOfEpisodes' => $episodes,
        ];
        if ($score) $schemaData['aggregateRating'] = [
            '@type' => 'AggregateRating',
            'ratingValue' => $score,
            'bestRating'  => 10,
            'ratingCount' => $anime['scored_by'] ?? 1,
        ];
        if ($bday && $btime) $schemaData['startDate'] = $bday . ' ' . $btime . ' JST';
        $json_ld = json_encode($schemaData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
} catch (\Throwable $e) {
    // silently fall back to generic title
}
include __DIR__ . '/includes/header.php';
?>

<div class="page-anime-detail2" id="animePage">

  <!-- Breadcrumb -->
  <div class="ad2-breadcrumb-bar">
    <div class="container">
      <nav class="ad2-breadcrumb">
        <a href="<?= $base ?>/"><i class="fa-solid fa-house"></i> Home</a>
        <i class="fa-solid fa-chevron-right"></i>
        <a href="<?= $base ?>/">Anime</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span id="ad2BreadTitle">Loading…</span>
      </nav>
    </div>
  </div>

  <!-- Loading state -->
  <div class="container" id="ad2Loading" style="padding:5rem 1rem;text-align:center">
    <div class="ad2-skeleton-layout">
      <!-- Left skeleton -->
      <div class="ad2-skel-left">
        <div class="skel-block" style="width:100%;aspect-ratio:2/3;border-radius:var(--radius)"></div>
        <div class="skel-block" style="height:80px;border-radius:var(--radius);margin-top:.75rem"></div>
        <div class="skel-block" style="height:60px;border-radius:var(--radius);margin-top:.75rem"></div>
        <div class="skel-block" style="height:100px;border-radius:var(--radius);margin-top:.75rem"></div>
      </div>
      <!-- Main skeleton -->
      <div class="ad2-skel-main">
        <div class="skel-block" style="height:2.5rem;width:70%;border-radius:var(--radius);margin-bottom:.5rem"></div>
        <div class="skel-block" style="height:1rem;width:40%;border-radius:var(--radius);margin-bottom:1rem"></div>
        <div class="skel-block" style="height:3rem;border-radius:var(--radius);margin-bottom:1rem"></div>
        <div class="skel-block" style="height:8rem;border-radius:var(--radius);margin-bottom:1rem"></div>
        <div class="skel-block" style="height:5rem;border-radius:var(--radius);margin-bottom:1rem"></div>
        <div class="skel-block" style="height:5rem;border-radius:var(--radius)"></div>
      </div>
      <!-- Right skeleton -->
      <div class="ad2-skel-right">
        <div class="skel-block" style="height:180px;border-radius:var(--radius);margin-bottom:.75rem"></div>
        <div class="skel-block" style="height:300px;border-radius:var(--radius)"></div>
      </div>
    </div>
  </div>

  <!-- Error state (hidden initially) -->
  <div class="container" id="ad2Error" style="display:none;padding:5rem 1rem;text-align:center">
    <i class="fa-solid fa-circle-exclamation" style="font-size:3rem;color:var(--danger,#ef4444);display:block;margin-bottom:1rem"></i>
    <h2>Could Not Load Anime</h2>
    <p style="color:var(--text3);margin:.5rem 0 1.5rem" id="ad2ErrorMsg">The anime data could not be fetched. Please try again.</p>
    <div style="display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="loadAnime()">
        <i class="fa-solid fa-rotate-right"></i> Retry
      </button>
      <a href="<?= $base ?>/" class="btn btn-ghost">Back to Schedule</a>
    </div>
  </div>

  <!-- Main content (hidden until data loads) -->
  <div class="container ad2-layout" id="ad2Content" style="display:none">

    <!-- ══ LEFT SIDEBAR ══════════════════════════════════════ -->
    <aside class="ad2-left">
      <div class="ad2-cover-wrap">
        <img id="ad2Cover" src="" alt="" class="ad2-cover"
             onerror="this.src='<?= $base ?>/assets/img/no-cover.svg'">
        <div class="ad2-airing-badge" id="ad2AiringBadge" style="display:none">
          <i class="fa-solid fa-circle-dot"></i> Airing
        </div>
      </div>

      <!-- Score -->
      <div class="ad2-score-block" id="ad2ScoreBlock" style="display:none">
        <div class="ad2-score-circle">
          <span class="ad2-score-num" id="ad2ScoreNum">—</span>
          <span class="ad2-score-lbl">Score</span>
        </div>
        <div class="ad2-score-meta" id="ad2ScoreMeta"></div>
      </div>

      <!-- Broadcast / countdown -->
      <div class="ad2-sidebar-card" id="ad2BroadcastCard" style="display:none">
        <h4 class="ad2-sidebar-card-title"><i class="fa-solid fa-clock"></i> Release Time</h4>
        <div id="ad2BroadcastBody"></div>
      </div>

      <!-- Genres -->
      <div class="ad2-sidebar-card" id="ad2GenresCard" style="display:none">
        <h4 class="ad2-sidebar-card-title"><i class="fa-solid fa-tags"></i> Genres</h4>
        <div class="ad2-tag-cloud" id="ad2GenresList"></div>
      </div>

      <!-- Studios -->
      <div class="ad2-sidebar-card" id="ad2StudiosCard" style="display:none">
        <h4 class="ad2-sidebar-card-title"><i class="fa-solid fa-building"></i> Studios</h4>
        <div class="ad2-tag-cloud" id="ad2StudiosList"></div>
      </div>

      <!-- Synonyms -->
      <div class="ad2-sidebar-card" id="ad2SynCard" style="display:none">
        <h4 class="ad2-sidebar-card-title"><i class="fa-solid fa-language"></i> Synonyms</h4>
        <ul class="ad2-synonyms" id="ad2SynList"></ul>
      </div>
    </aside>

    <!-- ══ MAIN CONTENT ══════════════════════════════════════ -->
    <main class="ad2-main">
      <div class="ad2-title-block">
        <h1 class="ad2-title" id="ad2Title"></h1>
        <div class="ad2-title-jp" id="ad2TitleJp" style="display:none"></div>
      </div>

      <div class="ad2-info-bar" id="ad2InfoBar"></div>

      <!-- Synopsis -->
      <section class="ad2-section" id="ad2SynopsisSection" style="display:none">
        <h2 class="ad2-section-heading">Synopsis</h2>
        <div class="ad2-synopsis" id="ad2Synopsis"></div>
        <button class="ad2-synopsis-toggle" id="ad2SynToggle" style="display:none">
          Show more <i class="fa-solid fa-chevron-down"></i>
        </button>
      </section>

      <!-- Streaming -->
      <section class="ad2-section" id="ad2StreamSection" style="display:none">
        <h2 class="ad2-section-heading">Official Streaming Platforms</h2>
        <div class="ad2-stream-grid" id="ad2StreamGrid"></div>
      </section>

      <!-- Info sites -->
      <section class="ad2-section">
        <h2 class="ad2-section-heading">Information Websites</h2>
        <div class="ad2-info-sites" id="ad2InfoSites"></div>
      </section>

      <!-- Trailer -->
      <section class="ad2-section" id="ad2TrailerSection" style="display:none">
        <h2 class="ad2-section-heading">Trailer</h2>
        <div class="ad2-trailer-wrap">
          <iframe id="ad2Trailer" src="" allowfullscreen loading="lazy"
                  class="ad2-trailer-frame"></iframe>
        </div>
      </section>

      <!-- Background -->
      <section class="ad2-section" id="ad2BgSection" style="display:none">
        <h2 class="ad2-section-heading">Background</h2>
        <div class="ad2-background-text" id="ad2BgText"></div>
      </section>

      <!-- Related -->
      <section class="ad2-section" id="ad2RelSection" style="display:none">
        <h2 class="ad2-section-heading">Related Anime</h2>
        <div class="ad2-relations" id="ad2RelList"></div>
      </section>
    </main>

    <!-- ══ RIGHT SIDEBAR ════════════════════════════════════ -->
    <aside class="ad2-right">
      <!-- Tracking -->
      <div class="ad2-track-card">
        <h3 class="ad2-track-title">Anime Tracking</h3>
        <div class="ad2-track-grid">
          <button class="ad2-track-btn" data-status="watching"      style="--track-color:#22c55e">
            <i class="fa-solid fa-play"></i><span>Watching</span></button>
          <button class="ad2-track-btn" data-status="on_hold"       style="--track-color:#f59e0b">
            <i class="fa-solid fa-pause"></i><span>On Hold</span></button>
          <button class="ad2-track-btn" data-status="dropped"       style="--track-color:#ef4444">
            <i class="fa-solid fa-xmark"></i><span>Dropped</span></button>
          <button class="ad2-track-btn" data-status="plan_to_watch" style="--track-color:#6366f1">
            <i class="fa-regular fa-clock"></i><span>To Watch</span></button>
        </div>
        <div class="ad2-track-current" id="ad2TrackStatus" style="display:none"></div>
      </div>

      <!-- Similar -->
      <div class="ad2-similar-card" id="ad2SimilarCard" style="display:none">
        <h3 class="ad2-similar-title">Similar Anime</h3>
        <div class="ad2-similar-list" id="ad2SimilarList"></div>
      </div>

      <!-- Details -->
      <div class="ad2-info-card2">
        <h3 class="ad2-info-card2-title">Details</h3>
        <div id="ad2DetailRows"></div>
      </div>
    </aside>

  </div><!-- /ad2-layout -->
</div><!-- /page-anime-detail2 -->

<script>
(function(){
  'use strict';
  const ANIME_ID = <?= $id ?>;
  const BASE     = (window.SITE && window.SITE.base) || '';

  // ── Stream platform brand colours ──────────────────────
  const STREAM_BRANDS = {
    crunchyroll: { color:'#f47521', icon:'fa-solid fa-play' },
    netflix:     { color:'#e50914', icon:'fa-solid fa-play' },
    funimation:  { color:'#410099', icon:'fa-solid fa-play' },
    hidive:      { color:'#00aeef', icon:'fa-solid fa-play' },
    amazon:      { color:'#00a8e0', icon:'fa-brands fa-amazon' },
    prime:       { color:'#00a8e0', icon:'fa-brands fa-amazon' },
    disney:      { color:'#006e99', icon:'fa-solid fa-play' },
    youtube:     { color:'#ff0000', icon:'fa-brands fa-youtube' },
    bilibili:    { color:'#00a1d6', icon:'fa-solid fa-play' },
    wakanim:     { color:'#e6323b', icon:'fa-solid fa-play' },
  };
  const SITE_BRANDS = [
    { key:'myanimelist',  label:'MyAnimeList', color:'#2e51a2', abbr:'MAL'   },
    { key:'anilist',      label:'AniList',     color:'#02a9ff', abbr:'AL'    },
    { key:'anime-planet', label:'Anime-Planet',color:'#e1a800', abbr:'AP'    },
    { key:'anidb',        label:'AniDB',       color:'#2a2f6b', abbr:'aDB'   },
    { key:'kitsu',        label:'Kitsu',       color:'#f55b00', abbr:'K'     },
  ];

  function esc(s){
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function show(id){ const el=document.getElementById(id); if(el) el.style.display=''; }
  function hide(id){ const el=document.getElementById(id); if(el) el.style.display='none'; }
  function el(id){ return document.getElementById(id); }
  function html(id,v){ const e=el(id); if(e) e.innerHTML=v; }
  function txt(id,v){ const e=el(id); if(e) e.textContent=v; }

  // ── Main loader ─────────────────────────────────────────
  window.loadAnime = async function() {
    show('ad2Loading'); hide('ad2Error'); hide('ad2Content');

    try {
      const res = await fetch(BASE + '/api/anime-detail.php?id=' + ANIME_ID);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Unknown error');
      render(json.anime);
    } catch(e) {
      hide('ad2Loading');
      show('ad2Error');
      txt('ad2ErrorMsg', 'Failed to load: ' + e.message);
    }
  };

  // ── Render all data ─────────────────────────────────────
  function render(a) {
    // Update page title
    const titleStr = a.title_en || a.title;
    document.title = esc(titleStr) + ' — <?= SITE_NAME ?>';
    txt('ad2BreadTitle', titleStr);
    txt('ad2Title', titleStr);

    // Japanese title
    if (a.title_jp) {
      txt('ad2TitleJp', a.title_jp);
      show('ad2TitleJp');
    }

    // Cover image
    const coverEl = el('ad2Cover');
    if (coverEl) { coverEl.src = a.cover || ''; coverEl.alt = titleStr; }

    // Airing badge
    if (a.airing) show('ad2AiringBadge');

    // Score
    if (a.score) {
      txt('ad2ScoreNum', Number(a.score).toFixed(2));
      let metaHtml = '';
      if (a.rank)       metaHtml += `<div class="ad2-score-stat"><i class="fa-solid fa-trophy"></i> Ranked #${Number(a.rank).toLocaleString()}</div>`;
      if (a.popularity) metaHtml += `<div class="ad2-score-stat"><i class="fa-solid fa-fire"></i> Popularity #${Number(a.popularity).toLocaleString()}</div>`;
      if (a.members)    metaHtml += `<div class="ad2-score-stat"><i class="fa-solid fa-users"></i> ${Number(a.members).toLocaleString()} members</div>`;
      html('ad2ScoreMeta', metaHtml);
      show('ad2ScoreBlock');
    }

    // Broadcast / countdown
    const bc = a.broadcast || {};
    if (bc.string || bc.time) {
      let bcHtml = '';
      if (a.airing && bc.day && bc.time) {
        bcHtml = `
          <div class="ad2-next-ep">
            <div class="ad2-next-ep-label">Next Episode</div>
            <div class="ad2-next-ep-day">${esc(bc.day)}</div>
            <div class="ad2-next-ep-time">${esc(bc.time)} (${esc(bc.timezone||'JST')})</div>
          </div>
          <div class="ad2-countdown-wrap">
            <span class="ad2-countdown-label">Countdown</span>
            <span class="ad2-countdown" id="ad2Countdown"
                  data-day="${esc(bc.day)}" data-time="${esc(bc.time)}"
                  data-tz="${esc(bc.timezone||'Asia/Tokyo')}">Calculating…</span>
          </div>`;
        startCountdown(bc.day, bc.time, bc.timezone || 'Asia/Tokyo');
      } else if (bc.string) {
        bcHtml = `<div class="ad2-broadcast-str">${esc(bc.string)}</div>`;
      }
      html('ad2BroadcastBody', bcHtml);
      show('ad2BroadcastCard');
    }

    // Genres + themes
    const allGenres = [...(a.genres||[]), ...(a.themes||[]), ...(a.demographics||[])];
    if (allGenres.length) {
      html('ad2GenresList', allGenres.map(g =>
        `<a href="${BASE}/search.php?genre=${encodeURIComponent(g)}" class="ad2-genre-tag">${esc(g)}</a>`
      ).join(''));
      show('ad2GenresCard');
    }

    // Studios
    if ((a.studios||[]).length) {
      html('ad2StudiosList', a.studios.map(s => `<span class="ad2-studio-tag">${esc(s)}</span>`).join(''));
      show('ad2StudiosCard');
    }

    // Synonyms — use titles array from raw or just skip
    // (api/anime-detail.php doesn't expose titles array, so we skip for now)

    // Info bar chips
    let infoHtml = '';
    if (a.type)       infoHtml += `<div class="ad2-info-chip ad2-chip-type">${esc(a.type)}</div>`;
    const seasonLabel = a.season && a.year ? (a.season.charAt(0).toUpperCase()+a.season.slice(1)+' '+a.year) : (a.year||'');
    if (seasonLabel)  infoHtml += `<div class="ad2-info-chip ad2-chip-season">${esc(seasonLabel)}</div>`;
    if (a.aired)      infoHtml += pill('Aired', a.aired);
    if (a.status)     infoHtml += `<div class="ad2-info-pill"><span class="ad2-pill-lbl">Status</span><span class="ad2-pill-val${a.airing?' ad2-status-airing':''}">${esc(a.status)}</span></div>`;
    if (a.source)     infoHtml += `<div class="ad2-info-chip ad2-chip-source">${esc(a.source)}</div>`;
    if (a.duration)   infoHtml += pill('Episode Length', a.duration);
    if (a.episodes)   infoHtml += pill('Episodes', a.episodes);
    if (a.rating)     infoHtml += pill('Rating', a.rating);
    html('ad2InfoBar', infoHtml);

    // Synopsis
    if (a.synopsis) {
      html('ad2Synopsis', esc(a.synopsis).replace(/\n/g,'<br>'));
      show('ad2SynopsisSection');
      if (a.synopsis.length > 600) {
        el('ad2Synopsis').classList.add('ad2-synopsis-collapsed');
        show('ad2SynToggle');
        el('ad2SynToggle').addEventListener('click', function(){
          const coll = el('ad2Synopsis').classList.toggle('ad2-synopsis-collapsed');
          this.innerHTML = coll
            ? 'Show more <i class="fa-solid fa-chevron-down"></i>'
            : 'Show less <i class="fa-solid fa-chevron-up"></i>';
        });
      }
    }

    // Streaming platforms
    if ((a.streaming||[]).length) {
      html('ad2StreamGrid', a.streaming.map(s => {
        const sname = s.name.toLowerCase();
        let brand = { color:'#6366f1', icon:'fa-solid fa-play' };
        for (const [k,b] of Object.entries(STREAM_BRANDS)) {
          if (sname.includes(k)) { brand=b; break; }
        }
        return `<a href="${esc(s.url)}" target="_blank" rel="noopener"
                   class="ad2-stream-btn" style="--brand-color:${brand.color}">
                  <i class="${brand.icon}"></i> ${esc(s.name)}
                </a>`;
      }).join(''));
      show('ad2StreamSection');
    }

    // Information websites
    const infoSites = buildInfoSites(a);
    html('ad2InfoSites', infoSites.map(s =>
      `<a href="${esc(s.url)}" target="_blank" rel="noopener"
          class="ad2-info-site-btn" style="--site-color:${s.color}">
         <span class="ad2-site-icon" style="background:${s.color}">${esc(s.abbr)}</span>
         ${esc(s.label)}
       </a>`
    ).join(''));

    // Trailer
    if (a.trailer) {
      el('ad2Trailer').src = a.trailer;
      show('ad2TrailerSection');
    }

    // Background
    if (a.background) {
      html('ad2BgText', esc(a.background.substring(0,800)).replace(/\n/g,'<br>'));
      show('ad2BgSection');
    }

    // Related anime
    const rels = [];
    (a.relations||[]).forEach(r => {
      (r.entries||[]).forEach(entry => {
        if (entry.type === 'anime') {
          rels.push(`<a href="${BASE}/anime.php?id=${entry.id}" class="ad2-relation-chip">
            <span class="ad2-relation-type">${esc(r.relation)}</span>
            <span>${esc(entry.name)}</span>
          </a>`);
        }
      });
    });
    if (rels.length) { html('ad2RelList', rels.join('')); show('ad2RelSection'); }

    // Detail rows
    const rows = [
      ['Format',    a.type],
      ['Episodes',  a.episodes || 'Unknown'],
      ['Status',    a.status],
      ['Aired',     a.aired],
      ['Duration',  a.duration],
      ['Rating',    a.rating],
      ['Favorites', a.favorites ? Number(a.favorites).toLocaleString() : ''],
    ];
    html('ad2DetailRows', rows.filter(r=>r[1]).map(r =>
      `<div class="ad2-detail-row">
         <span class="ad2-detail-lbl">${esc(r[0])}</span>
         <span class="ad2-detail-val">${esc(String(r[1]))}</span>
       </div>`
    ).join(''));

    // Tracking buttons — set active state from watchlist
    setupTracking(a);

    // Fetch similar/recommendations (separate call, non-blocking)
    loadRecs();

    // Swap loading → content
    hide('ad2Loading');
    show('ad2Content');
  }

  // ── Helpers ─────────────────────────────────────────────
  function pill(lbl, val){
    return `<div class="ad2-info-pill">
              <span class="ad2-pill-lbl">${esc(lbl)}</span>
              <span class="ad2-pill-val">${esc(String(val))}</span>
            </div>`;
  }

  function buildInfoSites(a) {
    const sites = [];
    const seen  = new Set();
    // Always add MAL link
    const malUrl = `https://myanimelist.net/anime/${ANIME_ID}`;
    sites.push({ label:'MyAnimeList', color:'#2e51a2', abbr:'MAL', url: a.mal_url || malUrl });
    seen.add(a.mal_url || malUrl);
    // Add from external (not exposed by current API — placeholder for future)
    // AniList search link
    const alUrl = `https://anilist.co/search/anime?search=${encodeURIComponent(a.title||'')}`;
    sites.push({ label:'AniList',     color:'#02a9ff', abbr:'AL',  url: alUrl });
    sites.push({ label:'Anime-Planet',color:'#e1a800', abbr:'AP',  url:`https://www.anime-planet.com/anime/all?name=${encodeURIComponent(a.title||'')}` });
    return sites;
  }

  function setupTracking(a) {
    // Try to get watchlist status from server if user is logged in
    if (window.SITE && window.SITE.user) {
      fetch(BASE + '/api/watchlist.php?status=')
        .then(r=>r.json())
        .then(d=>{
          const entry = (d.list||[]).find(x=>String(x.anime_id)===String(ANIME_ID));
          if (entry) {
            document.querySelectorAll('.ad2-track-btn').forEach(b=>b.classList.remove('active'));
            const activeBtn = document.querySelector(`.ad2-track-btn[data-status="${entry.status}"]`);
            if (activeBtn) activeBtn.classList.add('active');
            const statusEl = el('ad2TrackStatus');
            if (statusEl) {
              statusEl.innerHTML = `Currently: <strong>${esc(entry.status.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()))}</strong>`;
              show('ad2TrackStatus');
            }
          }
        }).catch(()=>{});
    }

    document.querySelectorAll('.ad2-track-btn').forEach(btn=>{
      btn.dataset.id    = ANIME_ID;
      btn.dataset.title = a.title_en || a.title;
      btn.dataset.cover = a.cover || '';
      btn.addEventListener('click', function(){
        if (window.App && window.App.openWatchlistModal) {
          window.App.openWatchlistModal({
            id: ANIME_ID, title: a.title_en||a.title,
            cover: a.cover||'', format: a.type||''
          });
        } else {
          document.querySelectorAll('.ad2-track-btn').forEach(b=>b.classList.remove('active'));
          this.classList.add('active');
        }
      });
    });
  }

  async function loadRecs() {
    try {
      const res  = await fetch(BASE + '/api/anime-detail.php?id=' + ANIME_ID + '&recs=1');
      const json = await res.json();
      if (!json.recs || !json.recs.length) return;
      html('ad2SimilarList', json.recs.slice(0,8).map(r =>
        `<a href="${BASE}/anime.php?id=${r.id}" class="ad2-similar-row">
           <img src="${esc(r.cover)}" alt="${esc(r.title)}" class="ad2-similar-img"
                onerror="this.src='${BASE}/assets/img/no-cover.svg'">
           <div class="ad2-similar-info">
             <span class="ad2-similar-name">${esc(r.title)}</span>
             ${r.votes ? `<span class="ad2-similar-votes">${r.votes} votes</span>` : ''}
           </div>
         </a>`
      ).join(''));
      show('ad2SimilarCard');
    } catch(e) { /* recs are optional */ }
  }

  // ── Countdown ───────────────────────────────────────────
  function startCountdown(dayName, time, tz) {
    const dayMap = {sunday:0,monday:1,tuesday:2,wednesday:3,thursday:4,friday:5,saturday:6};
    const targetDow = dayMap[(dayName||'').toLowerCase().replace(/s$/,'')] ?? -1;
    const [hh,mm]   = (time||'00:00').split(':').map(Number);

    function tick(){
      const cdEl = document.getElementById('ad2Countdown');
      if (!cdEl) return;
      if (targetDow < 0) { cdEl.textContent='N/A'; return; }
      try {
        const now   = new Date();
        const opts  = {timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',
                       hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false};
        const parts = new Intl.DateTimeFormat('en-CA',opts).formatToParts(now);
        const p = {}; parts.forEach(x=>{ if(x.type!=='literal') p[x.type]=parseInt(x.value); });
        const nowTz = new Date(p.year,p.month-1,p.day,p.hour,p.minute,p.second);
        const target = new Date(nowTz); target.setHours(hh,mm,0,0);
        let diff = (targetDow - nowTz.getDay() + 7) % 7;
        if (diff===0 && nowTz>=target) diff=7;
        target.setDate(target.getDate()+diff);
        const ms = target-nowTz;
        const d=Math.floor(ms/86400000), h=Math.floor((ms%86400000)/3600000),
              m=Math.floor((ms%3600000)/60000), s=Math.floor((ms%60000)/1000);
        cdEl.textContent = d>0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m ${s}s`;
      } catch(e) { cdEl.textContent='Calculating…'; }
    }
    tick(); setInterval(tick,1000);
  }

  // ── Boot ─────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', loadAnime);
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
