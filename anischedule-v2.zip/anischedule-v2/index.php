<?php
// ============================================================
//  Schedule Page — /index.php
// ============================================================
require_once __DIR__ . '/config.php';
$month = (int) date('n');
$curSeason = $month <= 3 ? 'Winter' : ($month <= 6 ? 'Spring' : ($month <= 9 ? 'Summer' : 'Fall'));
$curYear   = date('Y');
$page_title    = $curSeason . ' ' . $curYear . ' Anime Schedule | Air Times & Countdown — AniSchedule';
$page_desc     = 'Free ' . $curSeason . ' ' . $curYear . ' anime airing schedule. See exact air times in your timezone, episode countdowns, and streaming links for all currently airing anime including Donghua.';
$page_keywords = 'anime schedule ' . $curYear . ', ' . strtolower($curSeason) . ' ' . $curYear . ' anime, anime air times, airing anime ' . $curYear . ', anime timetable, weekly anime schedule, anime episode countdown, new anime episodes, anime streaming schedule';
$json_ld = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'BreadcrumbList',
  'itemListElement' => [[
    '@type'    => 'ListItem',
    'position' => 1,
    'name'     => 'Anime Schedule',
    'item'     => SITE_URL . '/'
  ]]
]);
$active_nav = 'schedule';
include __DIR__ . '/includes/header.php';
?>

<div class="page-schedule">

  <!-- SEO H1 — visually hidden but readable by Google -->
  <h1 class="seo-h1"><?= htmlspecialchars($curSeason . ' ' . $curYear) ?> Anime Airing Schedule — Air Times in Your Timezone</h1>

  <!-- ── Season navigation bar ────────────────────────── -->
  <div class="sched-season-bar" id="schedSeasonBar">
    <div class="container">
      <div class="sched-season-inner">
        <button class="sched-season-arrow" id="seasonYearPrev" title="Previous year">
          <i class="fa-solid fa-chevron-left"></i>
        </button>
        <div class="sched-season-tabs" id="schedSeasonTabs"><!-- JS fills this --></div>
        <button class="sched-season-arrow" id="seasonYearNext" title="Next year">
          <i class="fa-solid fa-chevron-right"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- ── Sticky Controls Bar (day tabs + week nav + filters + layout toggle) ── -->
  <div class="schedule-controls-wrap" id="schedControlsWrap">
    <div class="schedule-controls container">

      <!-- Day tabs (card mode) -->
      <div class="day-tabs" id="dayTabs" role="tablist">
        <?php
        $days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
        $today = strtolower(date('l'));
        foreach ($days as $d): ?>
          <button class="day-tab <?= $d === $today ? 'active' : '' ?>"
                  data-day="<?= $d ?>"
                  role="tab"
                  aria-selected="<?= $d === $today ? 'true' : 'false' ?>">
            <?= ucfirst(substr($d, 0, 3)) ?>
            <?php if ($d === $today): ?>
              <span class="today-dot" title="Today"></span>
            <?php endif; ?>
          </button>
        <?php endforeach; ?>
        <button class="day-tab" data-day="all" role="tab">All Week</button>
      </div>

      <!-- Week nav (grid mode — replaces day tabs) -->
      <div class="week-nav-inline" id="weekNavBar" style="display:none">
        <button class="week-nav-btn" id="weekPrevBtn">
          <i class="fa-solid fa-chevron-left"></i> Prev
        </button>
        <span class="week-nav-label" id="weekNavLabel"></span>
        <button class="week-nav-btn" id="weekNextBtn">
          Next <i class="fa-solid fa-chevron-right"></i>
        </button>
      </div>

      <!-- Filters + Layout toggle -->
      <div class="schedule-filters">
        <label class="filter-label">Type:</label>
        <div class="filter-chips" id="typeFilter" role="group" aria-label="Filter by type">
          <button class="chip active" data-type="">All</button>
          <button class="chip" data-type="TV">TV</button>
          <button class="chip" data-type="Movie">Movie</button>
          <button class="chip" data-type="OVA">OVA</button>
          <button class="chip" data-type="ONA">ONA</button>
          <button class="chip" data-type="Special">Special</button>
        </div>
        <label class="filter-label">Sort:</label>
        <select id="sortSelect" class="sort-select">
          <option value="members">Popularity</option>
          <option value="score">Score</option>
          <option value="title">Title A–Z</option>
          <option value="time">Air Time</option>
        </select>

        <!-- Layout toggle -->
        <div class="layout-toggle" role="group" aria-label="Switch layout">
          <button class="layout-btn" id="layoutRows" title="Row view (default)" aria-pressed="false">
            <i class="fa-solid fa-table-list"></i>
          </button>
          <button class="layout-btn" id="layoutGrid" title="Column grid view" aria-pressed="false">
            <i class="fa-solid fa-table-columns"></i>
          </button>
          <button class="layout-btn" id="layoutCard" title="Card view" aria-pressed="false">
            <i class="fa-solid fa-table-cells-large"></i>
          </button>
        </div>

        <!-- Filter button -->
        <button class="adv-filter-btn" id="advFilterBtn" title="Filters" aria-expanded="false">
          <i class="fa-solid fa-sliders"></i>
          <span>Filters</span>
          <span class="adv-filter-badge" id="advFilterBadge" style="display:none">0</span>
        </button>
      </div>
    </div>
  </div>

  <!-- ── Advanced Filter Panel ─────────────────────────── -->
  <div class="adv-filter-overlay" id="advFilterOverlay" aria-hidden="true"></div>
  <div class="adv-filter-panel" id="advFilterPanel" aria-hidden="true" role="dialog" aria-label="Filters">
    <button class="adv-filter-close" id="advFilterClose" aria-label="Close filters">
      <i class="fa-solid fa-xmark"></i>
    </button>

    <div class="adv-filter-body">

      <!-- Left column -->
      <div class="adv-filter-left">

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Air Type</div>
          <div class="adv-filter-chips" id="fAirType">
            <button class="adv-chip active" data-val="raw">Raw</button>
            <button class="adv-chip active" data-val="sub">Sub</button>
            <button class="adv-chip active" data-val="dub">Dub</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Hide Raw When</div>
          <div class="adv-filter-chips" id="fHideRawWhen">
            <button class="adv-chip" data-val="sub_exists">Sub Exists</button>
            <button class="adv-chip" data-val="dub_exists">Dub Exists</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Hide Sub When</div>
          <div class="adv-filter-chips" id="fHideSubWhen">
            <button class="adv-chip" data-val="dub_exists">Dub Exists</button>
            <button class="adv-chip" data-val="raw_exists">Raw Exists</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Hide Dub When</div>
          <div class="adv-filter-chips" id="fHideDubWhen">
            <button class="adv-chip" data-val="sub_exists">Sub Exists</button>
            <button class="adv-chip" data-val="raw_exists">Raw Exists</button>
          </div>
        </div>

        <div class="adv-filter-row-3">
          <div class="adv-filter-group">
            <div class="adv-filter-group-label">Time Format</div>
            <div class="adv-filter-chips" id="fTimeFormat">
              <button class="adv-chip active" data-val="24h">24H</button>
              <button class="adv-chip" data-val="12h">12H</button>
            </div>
          </div>
          <div class="adv-filter-group">
            <div class="adv-filter-group-label">Images</div>
            <div class="adv-filter-chips" id="fImages">
              <button class="adv-chip active" data-val="show">Show</button>
              <button class="adv-chip" data-val="hide">Hide</button>
            </div>
          </div>
          <div class="adv-filter-group">
            <div class="adv-filter-group-label">Donghua</div>
            <div class="adv-filter-chips" id="fDonghua">
              <button class="adv-chip active" data-val="show">Show</button>
              <button class="adv-chip" data-val="hide">Hide</button>
            </div>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Sort By</div>
          <div class="adv-filter-chips" id="fSortBy">
            <button class="adv-chip" data-val="title">Alphabetically</button>
            <button class="adv-chip active" data-val="members">Popularity</button>
            <button class="adv-chip" data-val="score">Score</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Week Type</div>
          <div class="adv-filter-chips" id="fWeekType">
            <button class="adv-chip active" data-val="monday">Monday First</button>
            <button class="adv-chip" data-val="sunday">Sunday First</button>
            <button class="adv-chip" data-val="saturday">Saturday First</button>
          </div>
        </div>

        <div class="adv-filter-actions">
          <button class="btn btn-sm adv-filter-clear" id="advFilterClear">Clear</button>
          <button class="btn btn-sm btn-primary adv-filter-reset" id="advFilterReset">Reset</button>
        </div>
      </div>

      <!-- Right column -->
      <div class="adv-filter-right">
        <div class="adv-filter-section-title">Filters</div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Type</div>
          <div class="adv-filter-chips" id="fIncludeType">
            <button class="adv-chip active" data-val="include">Include</button>
            <button class="adv-chip" data-val="exclude">Exclude</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Media Type</div>
          <div class="adv-filter-chips" id="fMediaType">
            <button class="adv-chip active" data-val="TV">TV</button>
            <button class="adv-chip active" data-val="TV Short">TV Short</button>
            <button class="adv-chip active" data-val="ONA">ONA</button>
            <button class="adv-chip active" data-val="OVA">OVA</button>
            <button class="adv-chip active" data-val="Special">Special</button>
            <button class="adv-chip active" data-val="Movie">Movie</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Official Streaming Platforms</div>
          <div class="adv-filter-chips" id="fPlatforms">
            <button class="adv-chip active" data-val="crunchyroll"><img src="<?= $base ?>/assets/img/logos/crunchyroll.svg" class="platform-logo" alt="">Crunchyroll</button>
            <button class="adv-chip active" data-val="netflix"><img src="<?= $base ?>/assets/img/logos/netflix.svg" class="platform-logo" alt="">Netflix</button>
            <button class="adv-chip active" data-val="amazon"><img src="<?= $base ?>/assets/img/logos/amazon.svg" class="platform-logo" alt="">Amazon</button>
            <button class="adv-chip active" data-val="hidive"><img src="<?= $base ?>/assets/img/logos/hidive.svg" class="platform-logo" alt="">HiDive</button>
            <button class="adv-chip active" data-val="hulu"><img src="<?= $base ?>/assets/img/logos/hulu.svg" class="platform-logo" alt="">Hulu</button>
            <button class="adv-chip active" data-val="disney"><img src="<?= $base ?>/assets/img/logos/disney.svg" class="platform-logo" alt="">Disney+</button>
            <button class="adv-chip active" data-val="appletv"><img src="<?= $base ?>/assets/img/logos/appletv.svg" class="platform-logo" alt="">Apple TV</button>
            <button class="adv-chip active" data-val="youtube"><img src="<?= $base ?>/assets/img/logos/youtube.svg" class="platform-logo" alt="">YouTube</button>
            <button class="adv-chip active" data-val="bilibili"><img src="<?= $base ?>/assets/img/logos/bilibili.svg" class="platform-logo" alt="">BiliBili TV</button>
          </div>
        </div>

        <div class="adv-filter-group">
          <div class="adv-filter-group-label">Episodes</div>
          <div class="adv-filter-episodes">
            <div class="adv-ep-labels">
              <span id="epMinLabel">0</span>
              <span id="epMaxLabel">60+</span>
            </div>
            <div class="adv-ep-slider-wrap">
              <input type="range" id="epMin" min="0" max="60" value="0" class="adv-ep-slider">
              <input type="range" id="epMax" min="0" max="60" value="60" class="adv-ep-slider adv-ep-slider-max">
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- ── Schedule Grid ─────────────────────────────────── -->
  <div class="container">
    <div id="scheduleContainer" class="schedule-container">
      <div class="loading-state">
        <div class="spinner"></div>
        <p>Loading schedule…</p>
      </div>
    </div>
  </div>

  <!-- ── Community Comments ────────────────────────────── -->
  <div class="container">
    <div class="comments-section" id="commentsSection">
      <h2 class="comments-heading">
        <i class="fa-solid fa-comments"></i> Community Discussion
      </h2>

      <?php if (auth_user()): ?>
      <!-- Post a comment -->
      <div class="comment-form-wrap">
        <div class="comment-avatar-col">
          <?php if (auth_user()['avatar']): ?>
            <img src="<?= htmlspecialchars(auth_user()['avatar']) ?>" class="comment-avatar" alt="You">
          <?php else: ?>
            <div class="comment-avatar comment-avatar-init"><?= strtoupper(auth_user()['username'][0]) ?></div>
          <?php endif; ?>
        </div>
        <div class="comment-input-col">
          <textarea id="commentInput" class="comment-textarea" placeholder="Share your thoughts on this week's anime…" rows="3" maxlength="1000"></textarea>
          <div class="comment-form-footer">
            <span class="comment-char-count"><span id="commentCharLeft">1000</span> chars left</span>
            <button class="btn btn-primary btn-sm" id="commentSubmitBtn">
              <i class="fa-solid fa-paper-plane"></i> Post
            </button>
          </div>
        </div>
      </div>
      <?php else: ?>
      <div class="comment-login-prompt">
        <i class="fa-solid fa-lock"></i>
        <span><a href="<?= $base ?>/login.php">Sign in</a> to join the discussion</span>
      </div>
      <?php endif; ?>

      <!-- Comments list -->
      <div id="commentsList" class="comments-list">
        <div class="comments-empty" id="commentsEmpty">
          <i class="fa-regular fa-comment-dots"></i>
          <p>No comments yet. Be the first to start the discussion!</p>
        </div>
      </div>
    </div>
  </div>

</div>

<script src="<?= $base . asset_ver('assets/js/schedule.js') ?>"></script>
<script>
// Prevent browser scroll-restoration jumping the hero out of view
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
window.scrollTo(0, 0);

document.addEventListener('DOMContentLoaded', () => {
  window.scrollTo(0, 0); // ensure top on DOMContentLoaded too
  window.SchedulePage.init({
    defaultDay:  '<?= $today ?>',
    apiBase:     '<?= $base ?>/api/schedule.php',
    donghuaApi:  '<?= $base ?>/api/donghua.php',
    episodeApi:  '<?= $base ?>/api/episode-data.php',
  });
});
</script>

<script>
// ── Comments (localStorage-backed) ────────────────────────────────────
(function () {
  const STORAGE_KEY  = 'anisched_comments_v2';
  const LIKES_KEY    = 'anisched_likes_v2';
  const MAX_COMMENTS = 999;   // prune oldest beyond this
  const PAGE_SIZE    = 30;    // show 30 at a time
  const MAX_REPLIES  = 99;    // replies per comment

  <?php $cu = auth_user(); ?>
  const CURRENT_USER = <?= $cu ? json_encode(['id' => $cu['id'], 'username' => $cu['username']]) : 'null' ?>;

  let visibleCount = PAGE_SIZE; // how many top-level comments currently shown

  /* ── Storage helpers ──────────────────────────────────── */
  function loadComments() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch(e) { return []; }
  }
  function saveComments(arr) {
    // Keep newest MAX_COMMENTS (arr is newest-first)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr.slice(0, MAX_COMMENTS)));
  }
  function loadLikes() {
    try { return new Set(JSON.parse(localStorage.getItem(LIKES_KEY)) || []); }
    catch(e) { return new Set(); }
  }
  function saveLikes(s) {
    localStorage.setItem(LIKES_KEY, JSON.stringify([...s]));
  }

  /* ── Utilities ────────────────────────────────────────── */
  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function timeAgo(ts) {
    const d = Math.floor((Date.now() - ts) / 1000);
    if (d < 60)    return 'just now';
    if (d < 3600)  return Math.floor(d/60) + 'm ago';
    if (d < 86400) return Math.floor(d/3600) + 'h ago';
    return Math.floor(d/86400) + 'd ago';
  }
  function uid() {
    return Date.now() + '_' + Math.random().toString(36).slice(2,7);
  }

  /* ── Build a single comment DOM node ─────────────────── */
  function buildCommentEl(c, likedSet, depth) {
    depth = depth || 0;
    const isLiked = likedSet.has(c.id);
    const isOwn   = CURRENT_USER && CURRENT_USER.id === c.userId;
    const init    = c.username ? c.username[0].toUpperCase() : '?';
    const replies = c.replies || [];
    const canReply = CURRENT_USER && depth === 0; // only 1 level of nesting

    const div = document.createElement('div');
    div.className = 'comment-item' + (depth > 0 ? ' comment-reply' : '');
    div.dataset.id = c.id;

    div.innerHTML = `
      <div class="comment-avatar-col">
        <div class="comment-avatar comment-avatar-init">${init}</div>
      </div>
      <div class="comment-body">
        <div class="comment-meta">
          <span class="comment-user">${escHtml(c.username)}</span>
          <span class="comment-time">${timeAgo(c.ts)}</span>
          ${replies.length ? `<span class="comment-reply-count">${replies.length} repl${replies.length===1?'y':'ies'}</span>` : ''}
        </div>
        <div class="comment-text">${escHtml(c.text)}</div>
        <div class="comment-actions">
          <button class="comment-like-btn ${isLiked?'liked':''}" data-id="${c.id}">
            <i class="fa-${isLiked?'solid':'regular'} fa-heart"></i> <span>${c.likes||0}</span>
          </button>
          ${canReply ? `<button class="comment-reply-btn" data-id="${c.id}"><i class="fa-solid fa-reply"></i> Reply</button>` : ''}
          ${isOwn ? `<button class="comment-delete-btn" data-id="${c.id}" data-parent="${c.parentId||''}"><i class="fa-solid fa-trash-can"></i></button>` : ''}
        </div>
        ${canReply ? `<div class="reply-form-wrap" id="rf_${c.id}" style="display:none">
          <textarea class="comment-textarea reply-textarea" placeholder="Write a reply…" rows="2" maxlength="500"></textarea>
          <div class="comment-form-footer">
            <span class="comment-char-count"><span class="reply-char-left">500</span> chars left</span>
            <div style="display:flex;gap:.4rem">
              <button class="btn btn-ghost btn-sm reply-cancel-btn" data-id="${c.id}">Cancel</button>
              <button class="btn btn-primary btn-sm reply-submit-btn" data-id="${c.id}"><i class="fa-solid fa-paper-plane"></i> Reply</button>
            </div>
          </div>
        </div>` : ''}
        <div class="replies-container" id="replies_${c.id}"></div>
      </div>`;

    // Append existing replies
    if (replies.length) {
      const rc = div.querySelector('#replies_' + c.id);
      replies.forEach(r => rc.appendChild(buildCommentEl(r, likedSet, 1)));
    }

    return div;
  }

  /* ── Full render ──────────────────────────────────────── */
  function renderComments() {
    const list  = document.getElementById('commentsList');
    const empty = document.getElementById('commentsEmpty');
    if (!list) return;

    const all     = loadComments();
    const likedSet = loadLikes();

    // Clear list (keep empty node)
    [...list.children].forEach(c => {
      if (c.id !== 'commentsEmpty') c.remove();
    });

    if (!all.length) { if (empty) empty.style.display=''; return; }
    if (empty) empty.style.display = 'none';

    const slice = all.slice(0, visibleCount);
    slice.forEach(c => list.appendChild(buildCommentEl(c, likedSet, 0)));

    // Load more button
    if (all.length > visibleCount) {
      const btn = document.createElement('button');
      btn.className = 'btn btn-ghost btn-sm comments-load-more';
      btn.innerHTML = `<i class="fa-solid fa-chevron-down"></i> Load more (${all.length - visibleCount} remaining)`;
      btn.addEventListener('click', () => { visibleCount += PAGE_SIZE; renderComments(); });
      list.appendChild(btn);
    }
  }

  /* ── Submit top-level comment ─────────────────────────── */
  const submitBtn = document.getElementById('commentSubmitBtn');
  const textarea  = document.getElementById('commentInput');
  const charLeft  = document.getElementById('commentCharLeft');

  if (textarea && charLeft) {
    textarea.addEventListener('input', () => { charLeft.textContent = 1000 - textarea.value.length; });
  }
  if (submitBtn && textarea && CURRENT_USER) {
    submitBtn.addEventListener('click', () => {
      const text = textarea.value.trim();
      if (!text) return;
      const comments = loadComments();
      comments.unshift({ id: uid(), userId: CURRENT_USER.id, username: CURRENT_USER.username,
                          text: text.slice(0,1000), ts: Date.now(), likes: 0, replies: [] });
      saveComments(comments);
      textarea.value = ''; charLeft.textContent = '1000';
      visibleCount = PAGE_SIZE;
      renderComments();
    });
  }

  /* ── Event delegation on comments list ───────────────── */
  document.getElementById('commentsList')?.addEventListener('click', e => {
    // Like
    const likeBtn = e.target.closest('.comment-like-btn');
    if (likeBtn) {
      const id = likeBtn.dataset.id;
      const likes = loadLikes();
      const comments = loadComments();
      // Search top-level and replies
      function findAndUpdate(arr) {
        for (let i=0; i<arr.length; i++) {
          if (arr[i].id === id) {
            if (likes.has(id)) { likes.delete(id); arr[i].likes = Math.max(0,(arr[i].likes||1)-1); }
            else               { likes.add(id);    arr[i].likes = (arr[i].likes||0)+1; }
            return true;
          }
          if (arr[i].replies && findAndUpdate(arr[i].replies)) return true;
        }
        return false;
      }
      findAndUpdate(comments);
      saveLikes(likes); saveComments(comments); renderComments();
    }

    // Delete
    const delBtn = e.target.closest('.comment-delete-btn');
    if (delBtn && CURRENT_USER) {
      const id = delBtn.dataset.id;
      let comments = loadComments();
      // Top-level
      comments = comments.filter(c => !(c.id === id && c.userId === CURRENT_USER.id));
      // Replies
      comments.forEach(c => {
        if (c.replies) c.replies = c.replies.filter(r => !(r.id === id && r.userId === CURRENT_USER.id));
      });
      saveComments(comments); renderComments();
    }

    // Toggle reply form
    const replyBtn = e.target.closest('.comment-reply-btn');
    if (replyBtn) {
      const id = replyBtn.dataset.id;
      const form = document.getElementById('rf_' + id);
      if (!form) return;
      const isOpen = form.style.display !== 'none';
      // Close all open reply forms first
      document.querySelectorAll('.reply-form-wrap').forEach(f => f.style.display='none');
      if (!isOpen) form.style.display = '';
    }

    // Cancel reply
    const cancelBtn = e.target.closest('.reply-cancel-btn');
    if (cancelBtn) {
      const form = document.getElementById('rf_' + cancelBtn.dataset.id);
      if (form) form.style.display = 'none';
    }

    // Submit reply
    const replySubmit = e.target.closest('.reply-submit-btn');
    if (replySubmit && CURRENT_USER) {
      const parentId = replySubmit.dataset.id;
      const form     = document.getElementById('rf_' + parentId);
      if (!form) return;
      const ta   = form.querySelector('.reply-textarea');
      const text = ta?.value.trim();
      if (!text) return;
      const comments = loadComments();
      const parent   = comments.find(c => c.id === parentId);
      if (!parent) return;
      if (!parent.replies) parent.replies = [];
      if (parent.replies.length >= MAX_REPLIES) {
        ta.value = ''; alert('Reply limit (99) reached for this comment.'); return;
      }
      parent.replies.push({ id: uid(), userId: CURRENT_USER.id, username: CURRENT_USER.username,
                             text: text.slice(0,500), ts: Date.now(), likes: 0, parentId });
      saveComments(comments);
      form.style.display = 'none';
      renderComments();
    }
  });

  // Char counter for reply textarea (delegated)
  document.getElementById('commentsList')?.addEventListener('input', e => {
    if (e.target.classList.contains('reply-textarea')) {
      const cl = e.target.closest('.reply-form-wrap')?.querySelector('.reply-char-left');
      if (cl) cl.textContent = 500 - e.target.value.length;
    }
  });

  document.addEventListener('DOMContentLoaded', renderComments);
})();
</script>

<script>
/* ── Advanced Filter Panel ─────────────────────────────── */
(function () {
  const STORE_KEY = 'anisched_adv_filter_v1';

  const DEFAULTS = {
    airType:      ['raw','sub','dub'],
    hideRawWhen:  [],
    hideSubWhen:  [],
    hideDubWhen:  [],
    timeFormat:   '24h',
    images:       'show',
    donghua:      'show',
    sortBy:       'members',
    weekType:     'monday',
    includeType:  'include',
    mediaType:    ['TV','TV Short','ONA','OVA','Special','Movie'],
    platforms:    ['crunchyroll','netflix','amazon','hidive','hulu','disney','appletv','youtube','bilibili'],
    epMin:        0,
    epMax:        60,
  };

  function load() {
    try { return Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem(STORE_KEY) || '{}')); }
    catch(e) { return Object.assign({}, DEFAULTS); }
  }
  function save(state) { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }

  let state = load();

  // ── UI refs ──
  const btn     = document.getElementById('advFilterBtn');
  const panel   = document.getElementById('advFilterPanel');
  const overlay = document.getElementById('advFilterOverlay');
  const closeBtn= document.getElementById('advFilterClose');
  const badge   = document.getElementById('advFilterBadge');
  const clearBtn= document.getElementById('advFilterClear');
  const resetBtn= document.getElementById('advFilterReset');
  const epMinEl = document.getElementById('epMin');
  const epMaxEl = document.getElementById('epMax');
  const epMinLbl= document.getElementById('epMinLabel');
  const epMaxLbl= document.getElementById('epMaxLabel');

  // ── Open / Close ──
  function openPanel() {
    panel.classList.add('open');
    overlay.classList.add('open');
    btn.setAttribute('aria-expanded','true');
    panel.setAttribute('aria-hidden','false');
    overlay.setAttribute('aria-hidden','false');
  }
  function closePanel() {
    panel.classList.remove('open');
    overlay.classList.remove('open');
    btn.setAttribute('aria-expanded','false');
    panel.setAttribute('aria-hidden','true');
    overlay.setAttribute('aria-hidden','true');
    applyFilters();
  }

  btn.addEventListener('click', () => panel.classList.contains('open') ? closePanel() : openPanel());
  closeBtn.addEventListener('click', closePanel);
  overlay.addEventListener('click', closePanel);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && panel.classList.contains('open')) closePanel(); });

  // ── Toggle chip helpers ──
  // Multi-select (array state key)
  function bindMulti(groupId, stateKey) {
    const group = document.getElementById(groupId);
    if (!group) return;
    group.querySelectorAll('.adv-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const val = chip.dataset.val;
        const idx = state[stateKey].indexOf(val);
        if (idx >= 0) state[stateKey].splice(idx, 1);
        else state[stateKey].push(val);
        chip.classList.toggle('active', state[stateKey].includes(val));
        save(state); updateBadge();
      });
    });
  }

  // Single-select (string state key)
  function bindSingle(groupId, stateKey) {
    const group = document.getElementById(groupId);
    if (!group) return;
    group.querySelectorAll('.adv-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        state[stateKey] = chip.dataset.val;
        group.querySelectorAll('.adv-chip').forEach(c => c.classList.toggle('active', c.dataset.val === state[stateKey]));
        save(state); updateBadge();
      });
    });
  }

  bindMulti('fAirType',      'airType');
  bindMulti('fHideRawWhen',  'hideRawWhen');
  bindMulti('fHideSubWhen',  'hideSubWhen');
  bindMulti('fHideDubWhen',  'hideDubWhen');
  bindSingle('fTimeFormat',  'timeFormat');
  bindSingle('fImages',      'images');
  bindSingle('fDonghua',     'donghua');
  bindSingle('fSortBy',      'sortBy');
  bindSingle('fWeekType',    'weekType');
  bindSingle('fIncludeType', 'includeType');
  bindMulti('fMediaType',    'mediaType');
  bindMulti('fPlatforms',    'platforms');

  // ── Episode range slider ──
  function updateEpLabels() {
    epMinLbl.textContent = state.epMin;
    epMaxLbl.textContent = state.epMax >= 60 ? '60+' : state.epMax;
    epMinEl.value = state.epMin;
    epMaxEl.value = state.epMax;
  }
  epMinEl.addEventListener('input', () => {
    state.epMin = Math.min(+epMinEl.value, state.epMax - 1);
    updateEpLabels(); save(state); updateBadge();
  });
  epMaxEl.addEventListener('input', () => {
    state.epMax = Math.max(+epMaxEl.value, state.epMin + 1);
    updateEpLabels(); save(state); updateBadge();
  });

  // ── Badge count (how many settings differ from defaults) ──
  function updateBadge() {
    let diff = 0;
    if (JSON.stringify([...state.airType].sort()) !== JSON.stringify([...DEFAULTS.airType].sort())) diff++;
    if (state.hideRawWhen.length)  diff++;
    if (state.hideSubWhen.length)  diff++;
    if (state.hideDubWhen.length)  diff++;
    if (state.timeFormat !== DEFAULTS.timeFormat) diff++;
    if (state.images !== DEFAULTS.images) diff++;
    if (state.donghua !== DEFAULTS.donghua) diff++;
    if (state.sortBy !== DEFAULTS.sortBy) diff++;
    if (state.weekType !== DEFAULTS.weekType) diff++;
    if (state.includeType !== DEFAULTS.includeType) diff++;
    if (JSON.stringify([...state.mediaType].sort()) !== JSON.stringify([...DEFAULTS.mediaType].sort())) diff++;
    if (JSON.stringify([...state.platforms].sort()) !== JSON.stringify([...DEFAULTS.platforms].sort())) diff++;
    if (state.epMin !== DEFAULTS.epMin || state.epMax !== DEFAULTS.epMax) diff++;
    badge.textContent = diff;
    badge.style.display = diff > 0 ? 'inline-flex' : 'none';
  }

  // ── Clear / Reset ──
  clearBtn.addEventListener('click', () => {
    state = { airType:[], hideRawWhen:[], hideSubWhen:[], hideDubWhen:[], timeFormat:'24h',
              images:'show', donghua:'show', sortBy:'members', weekType:'monday',
              includeType:'include', mediaType:[], platforms:[], epMin:0, epMax:60 };
    save(state); renderState(); updateBadge();
  });
  resetBtn.addEventListener('click', () => {
    state = Object.assign({}, DEFAULTS);
    save(state); renderState(); updateBadge();
  });

  // ── Render state → chips ──
  function renderState() {
    function syncMulti(groupId, stateKey) {
      const group = document.getElementById(groupId);
      if (!group) return;
      group.querySelectorAll('.adv-chip').forEach(c => c.classList.toggle('active', state[stateKey].includes(c.dataset.val)));
    }
    function syncSingle(groupId, stateKey) {
      const group = document.getElementById(groupId);
      if (!group) return;
      group.querySelectorAll('.adv-chip').forEach(c => c.classList.toggle('active', c.dataset.val === state[stateKey]));
    }
    syncMulti('fAirType','airType');
    syncMulti('fHideRawWhen','hideRawWhen');
    syncMulti('fHideSubWhen','hideSubWhen');
    syncMulti('fHideDubWhen','hideDubWhen');
    syncSingle('fTimeFormat','timeFormat');
    syncSingle('fImages','images');
    syncSingle('fDonghua','donghua');
    syncSingle('fSortBy','sortBy');
    syncSingle('fWeekType','weekType');
    syncSingle('fIncludeType','includeType');
    syncMulti('fMediaType','mediaType');
    syncMulti('fPlatforms','platforms');
    updateEpLabels();
  }

  // ── Apply filters to rendered cards ──
  function applyFilters() {
    // Sync sort select with filter panel sort
    const sortSel = document.getElementById('sortSelect');
    if (sortSel && sortSel.value !== state.sortBy) {
      sortSel.value = state.sortBy;
      sortSel.dispatchEvent(new Event('change'));
    }

    // Hide images
    document.querySelectorAll('.card-cover, .grid-card-cover, .mob-card-cover').forEach(img => {
      img.style.display = state.images === 'hide' ? 'none' : '';
    });

    // Filter cards by media type
    const inEx = state.includeType;
    document.querySelectorAll('.anime-card, .grid-card, .mob-card').forEach(card => {
      const type = (card.dataset.type || '').trim();
      if (!type) return;
      const inList = state.mediaType.includes(type);
      const show = inEx === 'include' ? inList : !inList;
      card.style.display = show ? '' : 'none';
    });

    // Episode filter
    document.querySelectorAll('.anime-card, .grid-card, .mob-card').forEach(card => {
      const eps = parseInt(card.dataset.episodes || '0', 10);
      if (state.epMax < 60 && eps > state.epMax) card.style.display = 'none';
      if (eps < state.epMin) card.style.display = 'none';
    });

    // Donghua filter — hide/show cards that came from the Donghua (CN) API
    document.querySelectorAll('[data-donghua="true"]').forEach(card => {
      card.style.display = state.donghua === 'hide' ? 'none' : '';
    });
  }

  // ── Init ──
  renderState();
  updateBadge();
  updateEpLabels();

  // Re-apply after schedule renders
  document.addEventListener('scheduleRendered', applyFilters);
  window.__advFilter = { state, applyFilters };
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
