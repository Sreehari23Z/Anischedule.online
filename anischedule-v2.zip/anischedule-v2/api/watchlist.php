<?php
// ============================================================
//  API: /api/watchlist.php  (GET / POST / PATCH / DELETE)
//  Requires authentication
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

$user = auth_user();
if (!$user) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Not logged in']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

// ── GET — fetch user's watchlist ──────────────────────────
if ($method === 'GET') {
    $status = $_GET['status'] ?? '';
    $valid  = ['watching','plan_to_watch','completed','on_hold','dropped'];

    $sql    = 'SELECT * FROM watchlist WHERE user_id = ?';
    $params = [$user['id']];

    if ($status && in_array($status, $valid)) {
        $sql    .= ' AND status = ?';
        $params[] = $status;
    }
    $sql .= ' ORDER BY updated_at DESC';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['ok' => true, 'list' => $stmt->fetchAll()]);
    exit;
}

// ── Parse JSON body for POST/PATCH/DELETE ─────────────────
$body = json_decode(file_get_contents('php://input'), true) ?? [];

// CSRF check
if (!csrf_verify($body['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid CSRF token']);
    exit;
}

// ── POST — add or update entry ────────────────────────────
if ($method === 'POST' || $method === 'PATCH') {
    $anime_id    = (int) ($body['anime_id'] ?? 0);
    $status      = $body['status']      ?? 'plan_to_watch';
    $progress    = (int) ($body['progress'] ?? 0);
    $score       = isset($body['score']) ? (int)$body['score'] : null;
    $title       = trim($body['title']  ?? '');
    $cover       = trim($body['cover']  ?? '');
    $format      = trim($body['format'] ?? '');

    $valid_status = ['watching','plan_to_watch','completed','on_hold','dropped'];
    if ($anime_id <= 0 || !in_array($status, $valid_status)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid data']);
        exit;
    }

    $stmt = db()->prepare(
        'INSERT INTO watchlist (user_id, anime_id, anime_title, anime_cover, anime_format, status, progress, score)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           status = VALUES(status),
           progress = VALUES(progress),
           score = VALUES(score),
           anime_title = VALUES(anime_title),
           anime_cover = VALUES(anime_cover),
           updated_at = NOW()'
    );
    $stmt->execute([$user['id'], $anime_id, $title, $cover, $format, $status, $progress, $score]);
    echo json_encode(['ok' => true, 'message' => 'Watchlist updated']);
    exit;
}

// ── DELETE — remove entry ─────────────────────────────────
if ($method === 'DELETE') {
    $anime_id = (int)($body['anime_id'] ?? 0);
    if ($anime_id <= 0) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid ID']);
        exit;
    }
    $stmt = db()->prepare('DELETE FROM watchlist WHERE user_id = ? AND anime_id = ?');
    $stmt->execute([$user['id'], $anime_id]);
    echo json_encode(['ok' => true, 'message' => 'Removed from watchlist']);
    exit;
}

http_response_code(405);
echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
