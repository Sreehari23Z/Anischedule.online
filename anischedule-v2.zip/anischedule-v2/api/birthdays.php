<?php
// ============================================================
//  API: /api/birthdays.php
//  Returns anime character birthday data
//  ?today=1        – characters with today's birthday
//  ?month=6        – all characters born in month 6
//  ?month=6&day=7  – characters born on June 7
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

// ── Static birthday database ──────────────────────────────────
// [mal_id, name, anime, month, day]  –  mal_id=0 means no linked page
$BIRTHDAYS = [
    // January
    ['id'=>0,      'name'=>'Saitama',                 'anime'=>'One Punch Man',               'month'=>1,  'day'=>9 ],
    ['id'=>118740, 'name'=>'Shoto Todoroki',           'anime'=>'My Hero Academia',            'month'=>1,  'day'=>11],
    ['id'=>10,     'name'=>'Gaara',                    'anime'=>'Naruto',                      'month'=>1,  'day'=>19],
    ['id'=>37677,  'name'=>'Toshiro Hitsugaya',        'anime'=>'Bleach',                      'month'=>1,  'day'=>20],
    ['id'=>0,      'name'=>'Minato Namikaze',           'anime'=>'Naruto',                      'month'=>1,  'day'=>25],
    ['id'=>11,     'name'=>'Edward Elric',              'anime'=>'Fullmetal Alchemist',         'month'=>1,  'day'=>31],
    // February
    ['id'=>0,      'name'=>'Yoichi Isagi',              'anime'=>'Blue Lock',                   'month'=>2,  'day'=>1 ],
    ['id'=>114547, 'name'=>'Rem',                       'anime'=>'Re:Zero',                     'month'=>2,  'day'=>2 ],
    ['id'=>115731, 'name'=>'Ram',                       'anime'=>'Re:Zero',                     'month'=>2,  'day'=>2 ],
    ['id'=>50,     'name'=>'Nico Robin',                'anime'=>'One Piece',                   'month'=>2,  'day'=>6 ],
    ['id'=>146160, 'name'=>'Giyu Tomioka',              'anime'=>'Demon Slayer',                'month'=>2,  'day'=>8 ],
    ['id'=>40881,  'name'=>'Mikasa Ackerman',           'anime'=>'Attack on Titan',             'month'=>2,  'day'=>10],
    ['id'=>0,      'name'=>'Tsuyu Asui',                'anime'=>'My Hero Academia',            'month'=>2,  'day'=>12],
    ['id'=>146162, 'name'=>'Shinobu Kocho',             'anime'=>'Demon Slayer',                'month'=>2,  'day'=>24],
    ['id'=>0,      'name'=>'Zero Two',                  'anime'=>'Darling in the FranXX',       'month'=>2,  'day'=>27],
    ['id'=>80,     'name'=>'Light Yagami',              'anime'=>'Death Note',                  'month'=>2,  'day'=>28],
    // March
    ['id'=>61,     'name'=>'Sanji',                     'anime'=>'One Piece',                   'month'=>3,  'day'=>2 ],
    ['id'=>0,      'name'=>'Leorio Paradinight',        'anime'=>'Hunter x Hunter',             'month'=>3,  'day'=>3 ],
    ['id'=>182757, 'name'=>'Yuji Itadori',              'anime'=>'Jujutsu Kaisen',              'month'=>3,  'day'=>20],
    ['id'=>15,     'name'=>'Sakura Haruno',             'anime'=>'Naruto',                      'month'=>3,  'day'=>28],
    ['id'=>40882,  'name'=>'Eren Yeager',               'anime'=>'Attack on Titan',             'month'=>3,  'day'=>30],
    ['id'=>0,      'name'=>'Rei Ayanami',               'anime'=>'Neon Genesis Evangelion',     'month'=>3,  'day'=>30],
    // April
    ['id'=>198,    'name'=>'Usopp',                     'anime'=>'One Piece',                   'month'=>4,  'day'=>1 ],
    ['id'=>4195,   'name'=>'Brook',                     'anime'=>'One Piece',                   'month'=>4,  'day'=>3 ],
    ['id'=>0,      'name'=>'Kurapika',                  'anime'=>'Hunter x Hunter',             'month'=>4,  'day'=>4 ],
    ['id'=>246,    'name'=>'Son Goku',                  'anime'=>'Dragon Ball Z',               'month'=>4,  'day'=>16],
    ['id'=>0,      'name'=>'Rei Hino / Sailor Mars',   'anime'=>'Sailor Moon',                 'month'=>4,  'day'=>17],
    ['id'=>118736, 'name'=>'Katsuki Bakugo',            'anime'=>'My Hero Academia',            'month'=>4,  'day'=>20],
    ['id'=>146159, 'name'=>'Inosuke Hashibira',         'anime'=>'Demon Slayer',                'month'=>4,  'day'=>22],
    // May
    ['id'=>40,     'name'=>'Monkey D. Luffy',           'anime'=>'One Piece',                   'month'=>5,  'day'=>5 ],
    ['id'=>0,      'name'=>'Gon Freecss',               'anime'=>'Hunter x Hunter',             'month'=>5,  'day'=>5 ],
    ['id'=>146161, 'name'=>'Kyojuro Rengoku',           'anime'=>'Demon Slayer',                'month'=>5,  'day'=>10],
    ['id'=>146163, 'name'=>'Kanao Tsuyuri',             'anime'=>'Demon Slayer',                'month'=>5,  'day'=>19],
    // June
    ['id'=>0,      'name'=>'Hisoka Morow',              'anime'=>'Hunter x Hunter',             'month'=>6,  'day'=>6 ],
    ['id'=>0,      'name'=>'Shinji Ikari',              'anime'=>'Neon Genesis Evangelion',     'month'=>6,  'day'=>6 ],
    ['id'=>82,     'name'=>'Itachi Uchiha',             'anime'=>'Naruto',                      'month'=>6,  'day'=>9 ],
    ['id'=>0,      'name'=>'Winry Rockbell',            'anime'=>'Fullmetal Alchemist',         'month'=>6,  'day'=>9 ],
    ['id'=>0,      'name'=>'All Might',                 'anime'=>'My Hero Academia',            'month'=>6,  'day'=>10],
    ['id'=>0,      'name'=>'Koushi Sugawara',           'anime'=>'Haikyuu!!',                   'month'=>6,  'day'=>13],
    ['id'=>0,      'name'=>'Shoyo Hinata',              'anime'=>'Haikyuu!!',                   'month'=>6,  'day'=>21],
    ['id'=>0,      'name'=>'Spike Spiegel',             'anime'=>'Cowboy Bebop',                'month'=>6,  'day'=>26],
    ['id'=>0,      'name'=>'Usagi Tsukino / Sailor Moon','anime'=>'Sailor Moon',                'month'=>6,  'day'=>30],
    // July
    ['id'=>723,    'name'=>'Nami',                      'anime'=>'One Piece',                   'month'=>7,  'day'=>3 ],
    ['id'=>0,      'name'=>'Neji Hyuga',                'anime'=>'Naruto',                      'month'=>7,  'day'=>3 ],
    ['id'=>0,      'name'=>'Killua Zoldyck',            'anime'=>'Hunter x Hunter',             'month'=>7,  'day'=>7 ],
    ['id'=>146156, 'name'=>'Tanjiro Kamado',            'anime'=>'Demon Slayer',                'month'=>7,  'day'=>14],
    ['id'=>118737, 'name'=>'Izuku Midoriya',            'anime'=>'My Hero Academia',            'month'=>7,  'day'=>15],
    ['id'=>0,      'name'=>'Tooru Oikawa',              'anime'=>'Haikyuu!!',                   'month'=>7,  'day'=>20],
    ['id'=>13,     'name'=>'Sasuke Uchiha',             'anime'=>'Naruto',                      'month'=>7,  'day'=>23],
    ['id'=>0,      'name'=>'Itoshi Rin',                'anime'=>'Blue Lock',                   'month'=>7,  'day'=>28],
    // August
    ['id'=>0,      'name'=>'Nobara Kugisaki',           'anime'=>'Jujutsu Kaisen',              'month'=>8,  'day'=>7 ],
    ['id'=>0,      'name'=>'Tenya Iida',                'anime'=>'My Hero Academia',            'month'=>8,  'day'=>22],
    // September
    ['id'=>12,     'name'=>'Alphonse Elric',            'anime'=>'Fullmetal Alchemist',         'month'=>9,  'day'=>2 ],
    ['id'=>146158, 'name'=>'Zenitsu Agatsuma',          'anime'=>'Demon Slayer',                'month'=>9,  'day'=>3 ],
    ['id'=>0,      'name'=>'Hanji Zoe',                 'anime'=>'Attack on Titan',             'month'=>9,  'day'=>5 ],
    ['id'=>0,      'name'=>'Ami Mizuno / Sailor Mercury','anime'=>'Sailor Moon',                'month'=>9,  'day'=>10],
    ['id'=>85,     'name'=>'Kakashi Hatake',            'anime'=>'Naruto',                      'month'=>9,  'day'=>15],
    ['id'=>0,      'name'=>'Kotaro Bokuto',             'anime'=>'Haikyuu!!',                   'month'=>9,  'day'=>20],
    ['id'=>0,      'name'=>'Emilia',                    'anime'=>'Re:Zero',                     'month'=>9,  'day'=>23],
    ['id'=>0,      'name'=>'Roy Mustang',               'anime'=>'Fullmetal Alchemist',         'month'=>9,  'day'=>29],
    ['id'=>0,      'name'=>'Asuna Yuuki',               'anime'=>'Sword Art Online',            'month'=>9,  'day'=>30],
    // October
    ['id'=>0,      'name'=>'Kirito',                    'anime'=>'Sword Art Online',            'month'=>10, 'day'=>7 ],
    ['id'=>17,     'name'=>'Naruto Uzumaki',            'anime'=>'Naruto',                      'month'=>10, 'day'=>10],
    ['id'=>0,      'name'=>'Erwin Smith',               'anime'=>'Attack on Titan',             'month'=>10, 'day'=>14],
    ['id'=>0,      'name'=>'Eijiro Kirishima',          'anime'=>'My Hero Academia',            'month'=>10, 'day'=>16],
    ['id'=>0,      'name'=>'Kenma Kozume',              'anime'=>'Haikyuu!!',                   'month'=>10, 'day'=>16],
    ['id'=>0,      'name'=>'Minako Aino / Sailor Venus','anime'=>'Sailor Moon',                 'month'=>10, 'day'=>22],
    ['id'=>211,    'name'=>'L Lawliet',                 'anime'=>'Death Note',                  'month'=>10, 'day'=>31],
    // November
    ['id'=>40883,  'name'=>'Armin Arlert',              'anime'=>'Attack on Titan',             'month'=>11, 'day'=>3 ],
    ['id'=>0,      'name'=>'Anya Forger',               'anime'=>'Spy x Family',                'month'=>11, 'day'=>5 ],
    ['id'=>60,     'name'=>'Roronoa Zoro',              'anime'=>'One Piece',                   'month'=>11, 'day'=>11],
    ['id'=>0,      'name'=>'Tetsurou Kuroo',            'anime'=>'Haikyuu!!',                   'month'=>11, 'day'=>17],
    ['id'=>14,     'name'=>'Rock Lee',                  'anime'=>'Naruto',                      'month'=>11, 'day'=>27],
    // December
    ['id'=>0,      'name'=>'Asuka Langley Soryu',       'anime'=>'Neon Genesis Evangelion',     'month'=>12, 'day'=>4 ],
    ['id'=>0,      'name'=>'Makoto Kino / Sailor Jupiter','anime'=>'Sailor Moon',               'month'=>12, 'day'=>5 ],
    ['id'=>182759, 'name'=>'Satoru Gojo',               'anime'=>'Jujutsu Kaisen',              'month'=>12, 'day'=>7 ],
    ['id'=>0,      'name'=>'Misato Katsuragi',          'anime'=>'Neon Genesis Evangelion',     'month'=>12, 'day'=>8 ],
    ['id'=>0,      'name'=>'Yor Forger',                'anime'=>'Spy x Family',                'month'=>12, 'day'=>20],
    ['id'=>0,      'name'=>'Ainz Ooal Gown',            'anime'=>'Overlord',                    'month'=>12, 'day'=>21],
    ['id'=>0,      'name'=>'Megumi Fushiguro',          'anime'=>'Jujutsu Kaisen',              'month'=>12, 'day'=>22],
    ['id'=>0,      'name'=>'Tobio Kageyama',            'anime'=>'Haikyuu!!',                   'month'=>12, 'day'=>22],
    ['id'=>62,     'name'=>'Tony Tony Chopper',         'anime'=>'One Piece',                   'month'=>12, 'day'=>24],
    ['id'=>31964,  'name'=>'Levi Ackerman',             'anime'=>'Attack on Titan',             'month'=>12, 'day'=>25],
    ['id'=>0,      'name'=>'Hinata Hyuga',              'anime'=>'Naruto',                      'month'=>12, 'day'=>27],
    ['id'=>0,      'name'=>'Ochaco Uraraka',            'anime'=>'My Hero Academia',            'month'=>12, 'day'=>27],
    ['id'=>146157, 'name'=>'Nezuko Kamado',             'anime'=>'Demon Slayer',                'month'=>12, 'day'=>28],
    ['id'=>0,      'name'=>'Ryomen Sukuna',             'anime'=>'Jujutsu Kaisen',              'month'=>12, 'day'=>31],
    ['id'=>0,      'name'=>'Daichi Sawamura',           'anime'=>'Haikyuu!!',                   'month'=>12, 'day'=>31],
];

// ── Parse request ──────────────────────────────────────────────
$today_flag = isset($_GET['today']);
$req_month  = intval($_GET['month'] ?? 0);
$req_day    = intval($_GET['day']   ?? 0);

$now_m = intval(date('n'));
$now_d = intval(date('j'));

try {
    if ($today_flag) {
        // Today's birthdays
        $chars = array_values(array_filter($BIRTHDAYS, fn($c) =>
            $c['month'] === $now_m && $c['day'] === $now_d
        ));
        echo json_encode(['ok' => true, 'date' => date('F j'), 'data' => $chars]);

    } elseif ($req_month && $req_day) {
        // Specific day
        $chars = array_values(array_filter($BIRTHDAYS, fn($c) =>
            $c['month'] === $req_month && $c['day'] === $req_day
        ));
        echo json_encode(['ok' => true, 'data' => $chars]);

    } elseif ($req_month) {
        // Full month — group by day
        $month_chars = array_filter($BIRTHDAYS, fn($c) => $c['month'] === $req_month);
        $by_day = [];
        foreach ($month_chars as $c) {
            $by_day[$c['day']][] = $c;
        }
        ksort($by_day);
        echo json_encode(['ok' => true, 'month' => $req_month, 'data' => $by_day]);

    } else {
        // All upcoming (next 30 days)
        $upcoming = [];
        for ($offset = 0; $offset <= 29; $offset++) {
            $ts = mktime(0, 0, 0, $now_m, $now_d + $offset);
            $m  = intval(date('n', $ts));
            $d  = intval(date('j', $ts));
            $chars = array_values(array_filter($BIRTHDAYS, fn($c) =>
                $c['month'] === $m && $c['day'] === $d
            ));
            if ($chars) {
                $upcoming[] = [
                    'date'       => date('F j', $ts),
                    'month'      => $m,
                    'day'        => $d,
                    'is_today'   => $offset === 0,
                    'characters' => $chars,
                ];
            }
        }
        echo json_encode(['ok' => true, 'data' => $upcoming]);
    }
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
