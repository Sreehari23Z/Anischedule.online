<?php
// ============================================================
//  API: /api/subscribe.php
//  POST endpoint for notification subscriptions
//  Body params: anime_id, anime_title, anime_cover, contact_type, contact_value, csrf
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/../includes/auth.php';
    require_once __DIR__ . '/../includes/db.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
    exit;
}

// Parse JSON body or form data
$input = [];
$raw   = file_get_contents('php://input');
if ($raw && ($decoded = json_decode($raw, true))) {
    $input = $decoded;
} else {
    $input = $_POST;
}

// CSRF check
$csrf_token = $input['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!csrf_verify($csrf_token)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid or missing CSRF token.']);
    exit;
}

// Validate inputs
$anime_id      = (int)($input['anime_id']     ?? 0);
$anime_title   = trim($input['anime_title']   ?? '');
$anime_cover   = trim($input['anime_cover']   ?? '');
$contact_type  = trim($input['contact_type']  ?? '');
$contact_value = trim($input['contact_value'] ?? '');

if ($anime_id <= 0) {
    echo json_encode(['ok' => false, 'error' => 'Invalid anime ID.']);
    exit;
}
if (empty($anime_title)) {
    echo json_encode(['ok' => false, 'error' => 'Anime title is required.']);
    exit;
}
if (!in_array($contact_type, ['email', 'whatsapp'], true)) {
    echo json_encode(['ok' => false, 'error' => 'contact_type must be email or whatsapp.']);
    exit;
}
if (empty($contact_value)) {
    echo json_encode(['ok' => false, 'error' => 'Contact value is required.']);
    exit;
}

// Validate format
if ($contact_type === 'email') {
    if (!filter_var($contact_value, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['ok' => false, 'error' => 'Invalid email address.']);
        exit;
    }
} elseif ($contact_type === 'whatsapp') {
    // Must start with + and contain only digits after that
    if (!preg_match('/^\+[1-9]\d{6,14}$/', $contact_value)) {
        echo json_encode(['ok' => false, 'error' => 'Invalid WhatsApp number. Use format: +12345678900']);
        exit;
    }
}

// Sanitise
$anime_title   = mb_substr($anime_title, 0, 255);
$anime_cover   = mb_substr($anime_cover, 0, 500);
$contact_value = mb_substr($contact_value, 0, 255);

try {
    $pdo = db();

    // Upsert into notification_subscriptions
    $stmt = $pdo->prepare("
        INSERT INTO notification_subscriptions
            (anime_id, anime_title, anime_cover, contact_type, contact_value)
        VALUES
            (:anime_id, :anime_title, :anime_cover, :contact_type, :contact_value)
        ON DUPLICATE KEY UPDATE
            anime_title  = VALUES(anime_title),
            anime_cover  = VALUES(anime_cover),
            created_at   = created_at
    ");
    $stmt->execute([
        ':anime_id'      => $anime_id,
        ':anime_title'   => $anime_title,
        ':anime_cover'   => $anime_cover,
        ':contact_type'  => $contact_type,
        ':contact_value' => $contact_value,
    ]);

    echo json_encode([
        'ok'      => true,
        'message' => "You'll be notified when {$anime_title} episode releases!",
    ]);

} catch (Throwable $e) {
    error_log('subscribe.php error: ' . $e->getMessage());
    echo json_encode(['ok' => false, 'error' => 'Database error. Please try again.']);
}
