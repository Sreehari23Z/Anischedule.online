<?php
// ============================================================
//  API: /api/seasonal.php
//  Returns JSON for seasonal anime grid
//  Query params: year, season (winter|spring|summer|fall)
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: public, max-age=1800');
require_once __DIR__ . '/anilist.php';

$year   = (int) ($_GET['year']   ?? date('Y'));
$season = strtolower(trim($_GET['season'] ?? ''));
$page   = max(1, (int)($_GET['page'] ?? 1));

$valid_seasons = ['winter', 'spring', 'summer', 'fall'];
if (!in_array($season, $valid_seasons)) {
    // Detect current season
    $month = (int) date('n');
    if ($month <= 3)       $season = 'winter';
    elseif ($month <= 6)   $season = 'spring';
    elseif ($month <= 9)   $season = 'summer';
    else                   $season = 'fall';
}

$raw = jikan_season($year, $season);

$anime = array_map(function($a) {
    return [
        'id'        => $a['mal_id'],
        'title'     => $a['title'],
        'title_en'  => $a['title_english'] ?? $a['title'],
        'cover'     => $a['images']['jpg']['large_image_url'] ?? $a['images']['jpg']['image_url'] ?? '',
        'type'      => $a['type'] ?? 'TV',
        'episodes'  => $a['episodes'] ?? null,
        'score'     => $a['score'] ?? null,
        'members'   => $a['members'] ?? 0,
        'genres'    => array_column($a['genres'] ?? [], 'name'),
        'studios'   => array_column($a['studios'] ?? [], 'name'),
        'status'    => $a['status'] ?? '',
        'airing'    => $a['airing'] ?? false,
        'synopsis'  => mb_substr($a['synopsis'] ?? '', 0, 200) . '…',
        'url'       => '/anime.php?id=' . $a['mal_id'],
        'streaming' => build_streaming_links($a),
    ];
}, $raw);

// Sort options
$sort = strtolower($_GET['sort'] ?? 'members');
usort($anime, function($a, $b) use ($sort) {
    return match($sort) {
        'score'  => ($b['score'] ?? 0) <=> ($a['score'] ?? 0),
        'title'  => strcmp($a['title'], $b['title']),
        default  => $b['members'] - $a['members'],
    };
});

echo json_encode([
    'ok'     => true,
    'year'   => $year,
    'season' => $season,
    'count'  => count($anime),
    'anime'  => $anime,
]);
