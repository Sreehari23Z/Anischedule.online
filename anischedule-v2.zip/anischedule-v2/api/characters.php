<?php
// ============================================================
//  API: /api/characters.php
//  Proxy for Jikan character search / detail
//  GET ?q=name  — search characters
//  GET ?id=mal_id — single character full detail
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

try {
    $id = (int)($_GET['id'] ?? 0);
    $q  = trim($_GET['q']  ?? '');

    if ($id > 0) {
        // Single character full detail
        $cacheKey = 'char_full_' . $id;
        $cached   = cache_get($cacheKey);
        if ($cached) {
            echo json_encode(['ok' => true, 'data' => $cached, 'source' => 'cache']);
            exit;
        }
        $body = http_get(JIKAN_API . "/characters/{$id}/full");
        if (!$body) {
            echo json_encode(['ok' => false, 'error' => 'Character not found.']);
            exit;
        }
        $json = json_decode($body, true);
        $data = $json['data'] ?? null;
        if (!$data) {
            echo json_encode(['ok' => false, 'error' => 'No data returned.']);
            exit;
        }
        cache_set($cacheKey, $data, CACHE_ANIME);
        echo json_encode(['ok' => true, 'data' => $data]);

    } elseif ($q !== '') {
        // Search characters
        $cacheKey = 'char_search_' . md5($q);
        $cached   = cache_get($cacheKey);
        if ($cached) {
            echo json_encode(['ok' => true, 'data' => $cached, 'source' => 'cache']);
            exit;
        }
        $body = http_get(JIKAN_API . '/characters?q=' . urlencode($q) . '&limit=20');
        if (!$body) {
            echo json_encode(['ok' => false, 'error' => 'Search failed.']);
            exit;
        }
        $json  = json_decode($body, true);
        $items = $json['data'] ?? [];
        $out   = [];
        foreach ($items as $c) {
            $out[] = [
                'id'       => $c['mal_id'],
                'name'     => $c['name'],
                'kanji'    => $c['name_kanji'] ?? '',
                'image'    => $c['images']['jpg']['image_url'] ?? '',
                'favorites'=> $c['favorites'] ?? 0,
                'url'      => '/character.php?id=' . $c['mal_id'],
            ];
        }
        cache_set($cacheKey, $out, 1800);
        echo json_encode(['ok' => true, 'data' => $out]);

    } else {
        echo json_encode(['ok' => false, 'error' => 'Provide ?id=<mal_id> or ?q=<search_term>']);
    }

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
