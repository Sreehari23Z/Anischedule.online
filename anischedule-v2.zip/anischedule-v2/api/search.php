<?php
// ============================================================
//  API: /api/search.php?q=&type=&status=&page=
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/anilist.php';

$q      = trim($_GET['q']      ?? '');
$type   = trim($_GET['type']   ?? '');
$status = trim($_GET['status'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));

if (strlen($q) < 1) {
    echo json_encode(['ok' => false, 'error' => 'Query too short']);
    exit;
}

$results = jikan_search($q, $page, $type, $status);
$anime   = array_map(fn($a) => [
    'id'       => $a['mal_id'],
    'title'    => $a['title'],
    'title_en' => $a['title_english'] ?? $a['title'],
    'cover'    => $a['images']['jpg']['large_image_url'] ?? $a['images']['jpg']['image_url'] ?? '',
    'type'     => $a['type'] ?? '',
    'episodes' => $a['episodes'] ?? null,
    'score'    => $a['score'] ?? null,
    'status'   => $a['status'] ?? '',
    'airing'   => $a['airing'] ?? false,
    'year'     => $a['year'] ?? null,
    'genres'   => array_column($a['genres'] ?? [], 'name'),
    'url'      => '/anime.php?id=' . $a['mal_id'],
], $results['data'] ?? []);

echo json_encode([
    'ok'         => true,
    'query'      => $q,
    'page'       => $page,
    'has_next'   => $results['pagination']['has_next_page'] ?? false,
    'total'      => $results['pagination']['items']['total'] ?? count($anime),
    'anime'      => $anime,
]);
