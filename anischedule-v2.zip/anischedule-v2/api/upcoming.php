<?php
// ============================================================
//  API: /api/upcoming.php
//  Returns next-season upcoming anime from Jikan
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

try {
    $cacheKey = 'api_upcoming_v1';
    $cached   = cache_get($cacheKey);
    if ($cached) {
        echo json_encode(['ok' => true, 'data' => $cached, 'source' => 'cache']);
        exit;
    }

    $body = http_get(JIKAN_API . '/seasons/upcoming?limit=25');
    if (!$body) {
        echo json_encode(['ok' => false, 'error' => 'Jikan API unavailable.']);
        exit;
    }

    $json  = json_decode($body, true);
    $items = $json['data'] ?? [];

    $out = [];
    foreach ($items as $a) {
        // Try to get premiere timestamp from aired.from
        $premiere_ts = null;
        if (!empty($a['aired']['from'])) {
            $ts = strtotime($a['aired']['from']);
            if ($ts && $ts > 0) $premiere_ts = $ts;
        }
        $out[] = [
            'id'           => $a['mal_id'],
            'title'        => $a['title'],
            'title_en'     => $a['title_english'] ?? $a['title'],
            'cover'        => $a['images']['jpg']['large_image_url'] ?? $a['images']['jpg']['image_url'] ?? '',
            'type'         => $a['type'] ?? 'TV',
            'episodes'     => $a['episodes'] ?? null,
            'score'        => $a['score'] ?? null,
            'genres'       => array_column($a['genres'] ?? [], 'name'),
            'studios'      => array_column($a['studios'] ?? [], 'name'),
            'synopsis'     => $a['synopsis'] ?? '',
            'premiere_ts'  => $premiere_ts,
            'aired_from'   => $a['aired']['from'] ?? null,
            'mal_url'      => $a['url'] ?? '',
        ];
    }

    // Sort by premiere date (earliest first)
    usort($out, function($a, $b) {
        $ta = $a['premiere_ts'] ?? PHP_INT_MAX;
        $tb = $b['premiere_ts'] ?? PHP_INT_MAX;
        return $ta - $tb;
    });

    cache_set($cacheKey, $out, CACHE_SEASONAL);
    echo json_encode(['ok' => true, 'data' => $out]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
