<?php
// ============================================================
//  API: /api/schedule.php
//  Returns JSON schedule grouped by weekday
//  Query params: day (optional) — monday…sunday
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *'); // allows local dev from different ports
set_time_limit(120); // allow up to 2 min when fetching all 7 days cold

// Catch ALL errors so we always return valid JSON
set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr", 'errno' => $errno]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

if (!extension_loaded('curl')) {
    echo json_encode(['ok' => false, 'error' => 'cURL extension is not enabled in PHP. Enable it in php.ini.']);
    exit;
}

$day          = strtolower(trim($_GET['day']    ?? ''));
$season_name  = strtolower(trim($_GET['season'] ?? ''));
$season_year  = intval($_GET['year'] ?? date('Y'));
$valid_days   = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
$valid_seasons= ['winter','spring','summer','fall'];

try {
    // ── Seasonal mode: fetch all anime for a season, group by broadcast day ──
    if ($season_name && in_array($season_name, $valid_seasons)) {
        $raw      = jikan_season($season_year, $season_name);
        $schedule = group_by_broadcast_day($raw);
        echo json_encode(['ok' => true, 'schedule' => $schedule, 'mode' => 'seasonal',
                          'season' => $season_name, 'year' => $season_year]);
        exit;
    }

    // ── Airing mode: fetch schedule by day ───────────────────────────────────
    if ($day && in_array($day, $valid_days)) {
        $raw = jikan_schedule($day);
        if (empty($raw)) {
            echo json_encode(['ok' => false, 'error' => "Jikan API returned no data for '$day'."]);
            exit;
        }
        $schedule = [$day => normalise_schedule_anime($raw)];
    } else {
        // All-days request — check single combined cache first
        $allCacheKey = 'schedule_all_days';
        $cached = cache_get($allCacheKey);
        if ($cached) {
            echo json_encode(['ok' => true, 'schedule' => $cached, 'mode' => 'airing']);
            exit;
        }
        $schedule = [];
        foreach ($valid_days as $d) {
            $raw = jikan_schedule($d);
            $schedule[$d] = normalise_schedule_anime($raw);
        }
        cache_set($allCacheKey, $schedule, CACHE_SCHEDULE);
    }
    echo json_encode(['ok' => true, 'schedule' => $schedule, 'mode' => 'airing']);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

// ── Group seasonal anime by broadcast weekday ────────────────────────────────
function group_by_broadcast_day(array $items): array {
    $days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    $out  = array_fill_keys($days, []);
    foreach ($items as $a) {
        $bday = strtolower($a['broadcast']['day'] ?? '');
        // Jikan returns e.g. "Mondays" — strip the trailing 's'
        $bday = rtrim($bday, 's');
        if (in_array($bday, $days)) {
            $out[$bday][] = $a;
        }
    }
    foreach ($out as $d => &$list) {
        $list = normalise_schedule_anime($list);
    }
    return $out;
}

// ─────────────────────────────────────────────────────────

function normalise_schedule_anime(array $items): array {
    $out = [];
    foreach ($items as $a) {
        $out[] = [
            'id'        => $a['mal_id'],
            'title'     => $a['title'],
            'title_en'  => $a['title_english'] ?? $a['title'],
            'title_jp'  => $a['title_japanese'] ?? '',
            'cover'     => $a['images']['jpg']['large_image_url'] ?? $a['images']['jpg']['image_url'] ?? '',
            'type'      => $a['type'] ?? 'TV',
            'episodes'  => $a['episodes'] ?? null,
            'score'     => $a['score'] ?? null,
            'members'   => $a['members'] ?? 0,
            'synopsis'  => $a['synopsis'] ?? '',
            'genres'    => array_column($a['genres'] ?? [], 'name'),
            'studios'   => array_column($a['studios'] ?? [], 'name'),
            'broadcast' => $a['broadcast'] ?? [],
            'streaming' => build_streaming_links($a),
            'url'       => '/anime.php?id=' . $a['mal_id'],
            'mal_url'   => $a['url'] ?? '',
            'status'     => $a['status'] ?? '',
            'airing'     => $a['airing'] ?? false,
            'aired_from' => $a['aired']['from'] ?? null,
            'country'    => 'JP',
        ];
    }
    usort($out, fn($a, $b) => $b['members'] - $a['members']);
    return $out;
}
