<?php
// ============================================================
//  API: /api/auth.php  (POST)
//  Actions: login, register, update_settings
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']);
    exit;
}

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';

// ── Login ─────────────────────────────────────────────────
if ($action === 'login') {
    $result = auth_login($body['email'] ?? '', $body['password'] ?? '');
    echo json_encode($result);
    exit;
}

// ── Register ──────────────────────────────────────────────
if ($action === 'register') {
    $result = auth_register(
        $body['username'] ?? '',
        $body['email']    ?? '',
        $body['password'] ?? ''
    );
    echo json_encode($result);
    exit;
}

// ── Update settings (requires auth) ──────────────────────
if ($action === 'update_settings') {
    $user = auth_user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Not logged in']);
        exit;
    }
    if (!csrf_verify($body['csrf'] ?? '')) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Invalid CSRF']);
        exit;
    }

    $fields  = [];
    $params  = [];
    $allowed = ['timezone' => 'string', 'theme' => ['dark', 'light']];

    if (isset($body['timezone'])) {
        $fields[] = 'timezone = ?';
        $params[] = substr($body['timezone'], 0, 60);
    }
    if (isset($body['theme']) && in_array($body['theme'], ['dark', 'light'])) {
        $fields[] = 'theme = ?';
        $params[] = $body['theme'];
    }

    if ($fields) {
        $params[] = $user['id'];
        db()->prepare('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?')->execute($params);
    }
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action']);
