<?php
// ============================================================
//  API: /api/episode-data.php
//  Uses AniList airingSchedules (the authoritative episode source) to:
//    1. Build an accurate episode map  (malId → {ep, airingAt})
//    2. Detect upcoming premieres      (episode=1 in next 35 days)
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');
set_time_limit(60);

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap: ' . $e->getMessage()]);
    exit;
}

try {
    $cacheKey = 'anilist_episode_data_v3';
    $cached   = cache_get($cacheKey);
    if ($cached) {
        echo json_encode(['ok' => true] + $cached);
        exit;
    }
    $result = fetch_episode_data();
    cache_set($cacheKey, $result, 1800);
    echo json_encode(['ok' => true] + $result);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

// ── Fetch airingSchedules ─────────────────────────────────────
function fetch_episode_data(): array {
    $now    = time();
    $cutoff = $now + 35 * 24 * 3600; // 35 days ahead

    // Fields included for every airing slot's media
    $mediaFields = 'id idMal
      title { romaji english native }
      coverImage { large medium }
      format episodes averageScore popularity
      description(asHtml: false)
      genres
      studios(isMain: true) { nodes { name } }
      externalLinks { site url }
      siteUrl
      countryOfOrigin
      status';

    // Build 8-page query in 2 batches (4 pages each) to stay under AniList complexity
    $schedFields = "airingAt episode media { $mediaFields }";

    $q1 = "query {
  p1: Page(page:1,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p2: Page(page:2,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p3: Page(page:3,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p4: Page(page:4,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
}";
    $q2 = "query {
  p5: Page(page:5,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p6: Page(page:6,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p7: Page(page:7,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
  p8: Page(page:8,perPage:50){ airingSchedules(airingAt_greater:$now,airingAt_lesser:$cutoff,sort:TIME){ $schedFields } }
}";

    $body1 = http_post_json(ANILIST_API, ['query' => $q1]);
    $data1 = $body1 ? (json_decode($body1, true)['data'] ?? []) : [];

    $body2 = http_post_json(ANILIST_API, ['query' => $q2]);
    $data2 = $body2 ? (json_decode($body2, true)['data'] ?? []) : [];

    // Merge all slots
    $allSlots = [];
    foreach (['p1','p2','p3','p4'] as $p) {
        foreach ($data1[$p]['airingSchedules'] ?? [] as $s) $allSlots[] = $s;
    }
    foreach (['p5','p6','p7','p8'] as $p) {
        foreach ($data2[$p]['airingSchedules'] ?? [] as $s) $allSlots[] = $s;
    }

    // ── Episode accuracy map: malId → soonest upcoming episode ──
    $episodes     = [];
    $premieres    = [];
    $seenPremiere = [];

    foreach ($allSlots as $slot) {
        $airingAt = (int)($slot['airingAt'] ?? 0);
        $ep       = (int)($slot['episode']  ?? 0);
        $media    = $slot['media'] ?? null;
        if (!$airingAt || !$ep || !$media) continue;

        $malId = $media['idMal'] ?? null;

        // Episode map: keep only the NEXT (soonest) episode per show
        if ($malId && (!isset($episodes[(string)$malId]) ||
                       $airingAt < $episodes[(string)$malId]['airingAt'])) {
            $episodes[(string)$malId] = [
                'ep'        => $ep,
                'airingAt'  => $airingAt,
                'anilistId' => (int)$media['id'],
            ];
        }

        // Premieres: episode 1 shows — deduplicated by AniList ID
        if ($ep === 1 && !isset($seenPremiere[$media['id']])) {
            $seenPremiere[$media['id']] = true;
            $broadcast   = airingAt_to_broadcast($airingAt);
            $premieres[] = normalise_premiere($media, $broadcast, $airingAt, $ep);
        }
    }

    usort($premieres, fn($a,$b) => $a['airingAt'] - $b['airingAt']);

    return ['episodes' => $episodes, 'premieres' => $premieres];
}

// ── Convert Unix timestamp → JST broadcast ────────────────────
function airingAt_to_broadcast(int $ts): array {
    $jst = $ts + 9 * 3600;
    $dow = [0=>'sunday',1=>'monday',2=>'tuesday',3=>'wednesday',4=>'thursday',5=>'friday',6=>'saturday'];
    return ['day' => $dow[(int)gmdate('w', $jst)], 'time' => gmdate('H:i', $jst), 'timezone' => 'Asia/Tokyo'];
}

// ── Normalise a premiere media entry ─────────────────────────
function normalise_premiere(array $m, array $broadcast, int $airingAt, int $ep): array {
    $title    = $m['title']['english']  ?? $m['title']['romaji'] ?? $m['title']['native'] ?? 'Unknown';
    $titleJp  = ($m['countryOfOrigin'] ?? 'JP') !== 'CN' ? ($m['title']['native'] ?? '') : '';
    $titleCn  = ($m['countryOfOrigin'] ?? '') === 'CN'   ? ($m['title']['native'] ?? '') : '';
    $isDonghua= ($m['countryOfOrigin'] ?? '') === 'CN';
    $score    = $m['averageScore'] ? round($m['averageScore'] / 10, 1) : null;

    $streaming = [];
    $known = ['crunchyroll','netflix','funimation','hidive','hulu','amazon',
              'disney','apple tv','youtube','bilibili','iqiyi','youku'];
    foreach ($m['externalLinks'] ?? [] as $link) {
        $sl = strtolower($link['site'] ?? '');
        foreach ($known as $s) {
            if (str_contains($sl, $s)) {
                $streaming[] = ['name'=>$link['site'],'url'=>$link['url']];
                break;
            }
        }
    }

    $url = $m['idMal'] ? '/anime.php?id='.(int)$m['idMal'] : ($m['siteUrl'] ?? '#');

    return [
        'id'           => 'al_'.$m['id'],
        'anilist_id'   => (int)$m['id'],
        'mal_id'       => $m['idMal'] ? (int)$m['idMal'] : null,
        'title'        => $m['title']['romaji'] ?? $title,
        'title_en'     => $title,
        'title_jp'     => $titleJp,
        'title_cn'     => $titleCn,
        'cover'        => $m['coverImage']['large'] ?? $m['coverImage']['medium'] ?? '',
        'type'         => format_type($m['format'] ?? 'TV'),
        'episodes'     => $m['episodes'] ?? null,
        'score'        => $score,
        'members'      => $m['popularity'] ?? 0,
        'synopsis'     => strip_tags($m['description'] ?? ''),
        'genres'       => $m['genres'] ?? [],
        'studios'      => array_column($m['studios']['nodes'] ?? [], 'name'),
        'broadcast'    => $broadcast,
        'streaming'    => $streaming,
        'url'          => $url,
        'mal_url'      => $m['idMal'] ? 'https://myanimelist.net/anime/'.(int)$m['idMal'] : '',
        'anilist_url'  => $m['siteUrl'] ?? '',
        'status'       => $m['status'] === 'NOT_YET_RELEASED' ? 'Not Yet Aired' : 'Currently Airing',
        'airing'       => true,
        'aired_from'   => date('Y-m-d\TH:i:sP', $airingAt),
        'next_episode' => $ep,
        'airingAt'     => $airingAt,
        'donghua'      => $isDonghua,
        'country'      => $m['countryOfOrigin'] ?? 'JP',
        'is_premiere'  => true,
        'source'       => 'anilist',
    ];
}

function format_type(string $f): string {
    return match(strtoupper($f)) {
        'TV_SHORT'=>'TV Short','MOVIE'=>'Movie','SPECIAL'=>'Special',
        'OVA'=>'OVA','ONA'=>'ONA','MUSIC'=>'Music',default=>'TV',
    };
}
