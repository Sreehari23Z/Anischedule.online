<?php
// ============================================================
//  API: /api/anime-detail.php?id=<mal_id>
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/anilist.php';

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid ID']);
    exit;
}

$data = jikan_anime($id);
if (!$data) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Anime not found']);
    exit;
}

$out = [
    'id'           => $data['mal_id'],
    'title'        => $data['title'],
    'title_en'     => $data['title_english'] ?? $data['title'],
    'title_jp'     => $data['title_japanese'] ?? '',
    'cover'        => $data['images']['jpg']['large_image_url'] ?? '',
    'banner'       => $data['images']['jpg']['large_image_url'] ?? '',
    'trailer'      => $data['trailer']['embed_url'] ?? null,
    'type'         => $data['type'] ?? '',
    'source'       => $data['source'] ?? '',
    'episodes'     => $data['episodes'] ?? null,
    'status'       => $data['status'] ?? '',
    'airing'       => $data['airing'] ?? false,
    'aired'        => $data['aired']['string'] ?? '',
    'duration'     => $data['duration'] ?? '',
    'rating'       => $data['rating'] ?? '',
    'score'        => $data['score'] ?? null,
    'scored_by'    => $data['scored_by'] ?? 0,
    'rank'         => $data['rank'] ?? null,
    'popularity'   => $data['popularity'] ?? null,
    'members'      => $data['members'] ?? 0,
    'favorites'    => $data['favorites'] ?? 0,
    'synopsis'     => $data['synopsis'] ?? '',
    'background'   => $data['background'] ?? '',
    'season'       => $data['season'] ?? '',
    'year'         => $data['year'] ?? null,
    'broadcast'    => $data['broadcast'] ?? [],
    'producers'    => array_column($data['producers'] ?? [], 'name'),
    'studios'      => array_column($data['studios'] ?? [], 'name'),
    'genres'       => array_column($data['genres'] ?? [], 'name'),
    'themes'       => array_column($data['themes'] ?? [], 'name'),
    'demographics' => array_column($data['demographics'] ?? [], 'name'),
    'streaming'    => build_streaming_links($data),
    'mal_url'      => $data['url'] ?? '',
    'relations'    => array_map(function($r) {
        return [
            'relation' => $r['relation'],
            'entries'  => array_map(fn($e) => [
                'id'   => $e['mal_id'],
                'type' => $e['type'],
                'name' => $e['name'],
                'url'  => '/anime.php?id=' . $e['mal_id'],
            ], $r['entry'] ?? [])
        ];
    }, $data['relations'] ?? []),
];

// Optionally include recommendations
$result = ['ok' => true, 'anime' => $out];
if (!empty($_GET['recs'])) {
    $raw_recs = jikan_anime_recommendations($id);
    $result['recs'] = array_map(fn($r) => [
        'id'    => $r['entry']['mal_id'] ?? 0,
        'title' => $r['entry']['title']  ?? '',
        'cover' => $r['entry']['images']['jpg']['image_url'] ?? '',
        'votes' => $r['votes'] ?? 0,
    ], array_slice($raw_recs, 0, 10));
}
echo json_encode($result);
