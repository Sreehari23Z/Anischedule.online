<?php
// ============================================================
//  API: /api/character.php
//  Actions: top | search (q) | detail (id)
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

$action = strtolower(trim($_GET['action'] ?? ''));
$id     = intval($_GET['id']     ?? 0);
$q      = trim($_GET['q']        ?? '');
$page   = max(1, intval($_GET['page'] ?? 1));

try {
    if ($id > 0) {
        // ── Character detail ─────────────────────────────────
        $char = jikan_character($id);
        if (!$char) {
            echo json_encode(['ok' => false, 'error' => 'Character not found']);
        } else {
            echo json_encode(['ok' => true, 'data' => $char]);
        }

    } elseif ($q !== '') {
        // ── Search ───────────────────────────────────────────
        $result = jikan_search_characters($q, $page);
        echo json_encode(['ok' => true, 'data' => $result['data'],
                          'pagination' => $result['pagination']]);

    } else {
        // ── Top characters (default) ─────────────────────────
        $result = jikan_top_characters($page);
        echo json_encode(['ok' => true, 'data' => $result['data'],
                          'pagination' => $result['pagination']]);
    }
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
