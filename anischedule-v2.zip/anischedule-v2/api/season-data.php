<?php
// ============================================================
//  API: /api/season-data.php
//  Proxy for Jikan /seasons/{year}/{season}
//  Used by season-calendar.php
//  Query params: year (int), season (winter|spring|summer|fall)
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

$valid_seasons = ['winter','spring','summer','fall'];
$year   = (int)($_GET['year'] ?? date('Y'));
$season = strtolower(trim($_GET['season'] ?? ''));

if (!in_array($season, $valid_seasons, true)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid season.']);
    exit;
}
if ($year < 1970 || $year > (int)date('Y') + 3) {
    echo json_encode(['ok' => false, 'error' => 'Invalid year.']);
    exit;
}

try {
    $data = jikan_season($year, $season);
    if (empty($data)) {
        echo json_encode(['ok' => false, 'error' => 'No data for this season.']);
        exit;
    }

    $out = [];
    foreach ($data as $a) {
        $out[] = [
            'id'       => $a['mal_id'],
            'title'    => $a['title'],
            'title_en' => $a['title_english'] ?? $a['title'],
            'cover'    => $a['images']['jpg']['image_url'] ?? '',
            'type'     => $a['type'] ?? 'TV',
            'score'    => $a['score'] ?? null,
            'members'  => $a['members'] ?? 0,
            'genres'   => array_column($a['genres'] ?? [], 'name'),
        ];
    }

    // Sort by members (popularity)
    usort($out, fn($a, $b) => $b['members'] - $a['members']);

    echo json_encode(['ok' => true, 'data' => $out, 'year' => $year, 'season' => $season]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
