<?php
// ============================================================
//  API: /api/top.php
//  Returns top anime from Jikan
//  Query params: filter (airing|bypopularity|''), page (int)
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

$allowed_filters = ['airing', 'bypopularity', 'favorite', ''];
$filter = strtolower(trim($_GET['filter'] ?? ''));
if (!in_array($filter, $allowed_filters, true)) $filter = '';
$page = max(1, (int)($_GET['page'] ?? 1));

try {
    $cacheKey = 'api_top_' . md5($filter . '_p' . $page);
    $cached   = cache_get($cacheKey);
    if ($cached) {
        echo json_encode(['ok' => true, 'data' => $cached['data'], 'pagination' => $cached['pagination'], 'source' => 'cache']);
        exit;
    }

    $url  = JIKAN_API . '/top/anime?limit=25&page=' . $page;
    if ($filter) $url .= '&filter=' . urlencode($filter);

    $body = http_get($url);
    if (!$body) {
        echo json_encode(['ok' => false, 'error' => 'Jikan API unavailable.']);
        exit;
    }

    $json       = json_decode($body, true);
    $items      = $json['data'] ?? [];
    $pagination = $json['pagination'] ?? [];

    $out = [];
    foreach ($items as $a) {
        $out[] = [
            'id'        => $a['mal_id'],
            'title'     => $a['title'],
            'title_en'  => $a['title_english'] ?? $a['title'],
            'cover'     => $a['images']['jpg']['large_image_url'] ?? $a['images']['jpg']['image_url'] ?? '',
            'type'      => $a['type'] ?? 'TV',
            'episodes'  => $a['episodes'] ?? null,
            'score'     => $a['score'] ?? null,
            'members'   => $a['members'] ?? 0,
            'rank'      => $a['rank'] ?? null,
            'genres'    => array_column($a['genres'] ?? [], 'name'),
            'synopsis'  => $a['synopsis'] ?? '',
            'status'    => $a['status'] ?? '',
            'year'      => $a['year'] ?? null,
            'mal_url'   => $a['url'] ?? '',
        ];
    }

    $payload = ['data' => $out, 'pagination' => $pagination];
    cache_set($cacheKey, $payload, 3600); // 1 hour
    echo json_encode(['ok' => true, 'data' => $out, 'pagination' => $pagination]);

} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
