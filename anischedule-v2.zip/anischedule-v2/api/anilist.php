<?php
// ============================================================
//  AniList + Jikan API wrapper with caching
// ============================================================
require_once __DIR__ . '/../includes/db.php';

// ── HTTP helper ───────────────────────────────────────────

function http_get(string $url, array $headers = []): ?string {
    // Try once with SSL verification ON (correct for production)
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER     => array_merge(['Accept: application/json'], $headers),
        CURLOPT_USERAGENT      => 'AniSchedule/1.0',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    // Use CA bundle if explicitly configured in php.ini (curl.cainfo)
    $cainfo = ini_get('curl.cainfo');
    if ($cainfo && file_exists($cainfo)) {
        curl_setopt($ch, CURLOPT_CAINFO, $cainfo);
    }

    $body  = curl_exec($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    curl_close($ch);

    if ($code === 200 && $body) {
        return $body;
    }

    // ── SSL failure fallback (common on Windows local dev) ───
    // errno 60 = SSL cert problem, errno 35 = SSL connect error, code 0 = connection failed
    $ssl_errors = [CURLE_SSL_CACERT, CURLE_SSL_CONNECT_ERROR, CURLE_COULDNT_CONNECT,
                   CURLE_SSL_CERTPROBLEM, CURLE_SSL_CIPHER, CURLE_SSL_PEER_CERTIFICATE];
    if ($errno === 0 || in_array($errno, $ssl_errors) || $code === 0) {
        $ch2 = curl_init($url);
        curl_setopt_array($ch2, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER     => array_merge(['Accept: application/json'], $headers),
            CURLOPT_USERAGENT      => 'AniSchedule/1.0',
            CURLOPT_SSL_VERIFYPEER => false,   // disabled only as fallback
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $body2 = curl_exec($ch2);
        $code2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        if ($code2 === 200 && $body2) return $body2;
    }

    return null;
}

function http_post_json(string $url, array $payload): ?string {
    $json    = json_encode($payload);
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
        'Content-Length: ' . strlen($json),
    ];

    // First attempt: SSL verification ON
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $json,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_USERAGENT      => 'AniSchedule/1.0',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $cainfo = ini_get('curl.cainfo');
    if ($cainfo && file_exists($cainfo)) {
        curl_setopt($ch, CURLOPT_CAINFO, $cainfo);
    }
    $body  = curl_exec($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    curl_close($ch);

    if ($code === 200 && $body) return $body;

    // SSL fallback (common on Windows local dev)
    $ssl_errors = [CURLE_SSL_CACERT, CURLE_SSL_CONNECT_ERROR, CURLE_COULDNT_CONNECT,
                   CURLE_SSL_CERTPROBLEM, CURLE_SSL_CIPHER, CURLE_SSL_PEER_CERTIFICATE];
    if ($errno === 0 || in_array($errno, $ssl_errors) || $code === 0) {
        $ch2 = curl_init($url);
        curl_setopt_array($ch2, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $json,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_USERAGENT      => 'AniSchedule/1.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $body2 = curl_exec($ch2);
        $code2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        if ($code2 === 200 && $body2) return $body2;
    }

    return null;
}

// ── Jikan v4 helpers ──────────────────────────────────────

/**
 * Get schedule for a specific day (or all days)
 * $day: monday|tuesday|wednesday|thursday|friday|saturday|sunday|unknown|other
 */
function jikan_schedule(string $day = ''): array {
    $cacheKey = 'jikan_schedule_' . ($day ?: 'all');
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $url  = JIKAN_API . '/schedules' . ($day ? '?filter=' . urlencode($day) : '');
    $body = http_get($url);
    if (!$body) return [];

    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    cache_set($cacheKey, $data, CACHE_SCHEDULE);
    return $data;
}

/**
 * Get currently airing anime (seasonal)
 */
function jikan_season_now(int $page = 1): array {
    $cacheKey = "jikan_season_now_p{$page}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/seasons/now?page={$page}");
    if (!$body) return [];

    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    cache_set($cacheKey, $data, CACHE_SEASONAL);
    return $data;
}

/**
 * Get a specific season
 */
function jikan_season(int $year, string $season): array {
    $cacheKey = "jikan_season_{$year}_{$season}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/seasons/{$year}/{$season}");
    if (!$body) return [];

    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    cache_set($cacheKey, $data, CACHE_SEASONAL);
    return $data;
}

/**
 * Get full anime details by MAL ID
 */
function jikan_anime(int $id): ?array {
    $cacheKey = "jikan_anime_{$id}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/anime/{$id}/full");
    if (!$body) return null;

    $json = json_decode($body, true);
    $data = $json['data'] ?? null;

    if ($data) cache_set($cacheKey, $data, CACHE_ANIME);
    return $data;
}

/**
 * Search anime
 */
function jikan_search(string $q, int $page = 1, string $type = '', string $status = ''): array {
    $params = ['q' => urlencode($q), 'page' => $page, 'limit' => 24, 'sfw' => 'true'];
    if ($type)   $params['type']   = $type;
    if ($status) $params['status'] = $status;

    $query    = http_build_query($params);
    $cacheKey = "jikan_search_" . md5($query);
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/anime?{$query}");
    if (!$body) return ['data' => [], 'pagination' => []];

    $json = json_decode($body, true);
    $out  = ['data' => $json['data'] ?? [], 'pagination' => $json['pagination'] ?? []];

    cache_set($cacheKey, $out, 600); // 10 min cache for searches
    return $out;
}

/**
 * Get available seasons list
 */
function jikan_seasons_list(): array {
    $cacheKey = 'jikan_seasons_list';
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . '/seasons');
    if (!$body) return [];

    $json = json_decode($body, true);
    $data = $json['data'] ?? [];

    cache_set($cacheKey, $data, 86400); // 24h
    return $data;
}

/**
 * Get anime recommendations (similar anime)
 */
function jikan_anime_recommendations(int $id): array {
    $cacheKey = "jikan_recs_{$id}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/anime/{$id}/recommendations");
    if (!$body) return [];

    $json = json_decode($body, true);
    $data = array_slice($json['data'] ?? [], 0, 10);

    cache_set($cacheKey, $data, CACHE_ANIME);
    return $data;
}

/**
 * Get top characters by favourites
 */
function jikan_top_characters(int $page = 1): array {
    $cacheKey = "jikan_top_chars_p{$page}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/top/characters?page={$page}");
    if (!$body) return ['data' => [], 'pagination' => []];

    $json = json_decode($body, true);
    $out  = ['data' => $json['data'] ?? [], 'pagination' => $json['pagination'] ?? []];

    cache_set($cacheKey, $out, 3600);
    return $out;
}

/**
 * Get full character details (includes voices + anime/manga appearances)
 */
function jikan_character(int $id): ?array {
    $cacheKey = "jikan_char_{$id}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/characters/{$id}/full");
    if (!$body) return null;

    $json = json_decode($body, true);
    $data = $json['data'] ?? null;

    if ($data) cache_set($cacheKey, $data, 3600);
    return $data;
}

/**
 * Search characters by name
 */
function jikan_search_characters(string $q, int $page = 1): array {
    $cacheKey = "jikan_char_search_" . md5($q . $page);
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $url  = JIKAN_API . '/characters?q=' . urlencode($q)
          . '&page=' . $page . '&limit=24&order_by=favorites&sort=desc';
    $body = http_get($url);
    if (!$body) return ['data' => [], 'pagination' => []];

    $json = json_decode($body, true);
    $out  = ['data' => $json['data'] ?? [], 'pagination' => $json['pagination'] ?? []];

    cache_set($cacheKey, $out, 600);
    return $out;
}

/**
 * Get full voice actor / person details
 */
function jikan_person(int $id): ?array {
    $cacheKey = "jikan_person_{$id}";
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $body = http_get(JIKAN_API . "/people/{$id}/full");
    if (!$body) return null;

    $json = json_decode($body, true);
    $data = $json['data'] ?? null;

    if ($data) cache_set($cacheKey, $data, 3600);
    return $data;
}

// ── Normalise helpers ─────────────────────────────────────

/**
 * Map day-of-week integer (0=Sun … 6=Sat) to Jikan filter name
 */
function dow_to_jikan(int $dow): string {
    return match($dow) {
        0 => 'sunday', 1 => 'monday', 2 => 'tuesday',
        3 => 'wednesday', 4 => 'thursday', 5 => 'friday',
        6 => 'saturday', default => 'other',
    };
}

/**
 * Build a streaming links array from Jikan's external_links + streaming fields
 */
function build_streaming_links(array $anime): array {
    $links = [];
    $streaming = $anime['streaming'] ?? [];
    foreach ($streaming as $s) {
        $links[] = ['name' => $s['name'], 'url' => $s['url']];
    }
    return $links;
}
