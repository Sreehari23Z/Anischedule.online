<?php
// ============================================================
//  API: /api/donghua.php
//  Fetches currently-airing Donghua (Chinese anime) from
//  AniList GraphQL (countryOfOrigin: CN) and returns a
//  schedule grouped by weekday, in the same shape as
//  /api/schedule.php so the frontend can merge them.
// ============================================================
header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

set_error_handler(function($errno, $errstr) {
    echo json_encode(['ok' => false, 'error' => "PHP Error: $errstr"]);
    exit;
});

try {
    require_once __DIR__ . '/anilist.php';
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Bootstrap failed: ' . $e->getMessage()]);
    exit;
}

if (!extension_loaded('curl')) {
    echo json_encode(['ok' => false, 'error' => 'cURL extension not enabled']);
    exit;
}

try {
    $raw      = fetch_donghua_airing();
    $schedule = group_donghua_by_day($raw);
    echo json_encode(['ok' => true, 'schedule' => $schedule, 'mode' => 'donghua', 'count' => array_sum(array_map('count', $schedule))]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

// ── Fetch from AniList ────────────────────────────────────────
function fetch_donghua_airing(): array {
    $cacheKey = 'anilist_donghua_airing_v2';
    $cached   = cache_get($cacheKey);
    if ($cached) return $cached;

    $query = 'query {
  p1: Page(page: 1, perPage: 50) {
    media(status: RELEASING, countryOfOrigin: "CN", type: ANIME, sort: POPULARITY_DESC) {
      id idMal
      title { romaji english native }
      coverImage { large medium }
      format episodes averageScore popularity
      description(asHtml: false)
      genres
      studios(isMain: true) { nodes { name } }
      nextAiringEpisode { airingAt episode timeUntilAiring }
      externalLinks { site url }
      siteUrl countryOfOrigin
    }
  }
  p2: Page(page: 2, perPage: 50) {
    media(status: RELEASING, countryOfOrigin: "CN", type: ANIME, sort: POPULARITY_DESC) {
      id idMal
      title { romaji english native }
      coverImage { large medium }
      format episodes averageScore popularity
      description(asHtml: false)
      genres
      studios(isMain: true) { nodes { name } }
      nextAiringEpisode { airingAt episode timeUntilAiring }
      externalLinks { site url }
      siteUrl countryOfOrigin
    }
  }
}';

    $body = http_post_json(ANILIST_API, ['query' => $query]);
    if (!$body) return [];

    $json = json_decode($body, true);
    $p1   = $json['data']['p1']['media'] ?? [];
    $p2   = $json['data']['p2']['media'] ?? [];

    // Deduplicate by id
    $seen = [];
    $all  = [];
    foreach (array_merge($p1, $p2) as $item) {
        if (!isset($seen[$item['id']])) {
            $seen[$item['id']] = true;
            $all[] = $item;
        }
    }

    cache_set($cacheKey, $all, CACHE_SCHEDULE);
    return $all;
}

// ── Group by weekday (using JST from airingAt timestamp) ──────
function group_donghua_by_day(array $items): array {
    $days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    $out  = array_fill_keys($days, []);

    foreach ($items as $a) {
        $airingAt = $a['nextAiringEpisode']['airingAt'] ?? null;
        if (!$airingAt) continue;  // skip if no upcoming episode scheduled

        $broadcast = airingAt_to_broadcast((int) $airingAt);
        $day       = $broadcast['day'];
        if (in_array($day, $days)) {
            $out[$day][] = normalise_donghua($a, $broadcast);
        }
    }

    // Sort each day by popularity desc (same as Jikan normalise)
    foreach ($out as $d => &$list) {
        usort($list, fn($a, $b) => $b['members'] - $a['members']);
    }

    return $out;
}

// ── Convert Unix timestamp → JST day + time ──────────────────
// We store broadcast time in JST (same convention as Jikan)
// so the existing frontend timezone-conversion code works unchanged.
function airingAt_to_broadcast(int $ts): array {
    $jst = $ts + 9 * 3600;   // UTC → JST (UTC+9)
    $dow_map = [
        0 => 'sunday', 1 => 'monday', 2 => 'tuesday',
        3 => 'wednesday', 4 => 'thursday', 5 => 'friday', 6 => 'saturday',
    ];
    return [
        'day'      => $dow_map[(int) gmdate('w', $jst)],
        'time'     => gmdate('H:i', $jst),
        'timezone' => 'Asia/Tokyo',
    ];
}

// ── Normalise AniList item → same shape as Jikan normalise ───
function normalise_donghua(array $a, array $broadcast): array {
    $title    = $a['title']['romaji']
             ?? $a['title']['english']
             ?? $a['title']['native']
             ?? 'Unknown';
    $title_en = $a['title']['english'] ?? $title;
    $title_jp = $a['title']['native']  ?? '';

    // Score: AniList uses 0-100, convert to 0-10 like MAL
    $score = $a['averageScore'] ? round($a['averageScore'] / 10, 1) : null;

    // Streaming links from externalLinks
    $streaming = [];
    $known_streaming = ['crunchyroll','netflix','funimation','hidive','hulu','amazon',
                        'disney+','apple tv','youtube','bilibili','iqiyi','youku'];
    foreach ($a['externalLinks'] ?? [] as $link) {
        $siteLower = strtolower($link['site'] ?? '');
        foreach ($known_streaming as $s) {
            if (str_contains($siteLower, $s)) {
                $streaming[] = ['name' => $link['site'], 'url' => $link['url']];
                break;
            }
        }
    }

    // URL: if we have a MAL ID use our local anime page, else AniList
    $url = $a['idMal']
        ? '/anime.php?id=' . (int) $a['idMal']
        : ($a['siteUrl'] ?? '#');

    return [
        'id'           => 'al_' . $a['id'],   // prefix to avoid MAL ID collision
        'anilist_id'   => $a['id'],
        'mal_id'       => $a['idMal'] ?? null,
        'title'        => $title,
        'title_en'     => $title_en,
        'title_jp'     => $title_jp,
        'cover'        => $a['coverImage']['large'] ?? $a['coverImage']['medium'] ?? '',
        'type'         => format_to_type($a['format'] ?? 'TV'),
        'episodes'     => $a['episodes'] ?? null,
        'score'        => $score,
        'members'      => $a['popularity'] ?? 0,
        'synopsis'     => strip_tags($a['description'] ?? ''),
        'genres'       => $a['genres'] ?? [],
        'studios'      => array_column($a['studios']['nodes'] ?? [], 'name'),
        'broadcast'    => $broadcast,
        'streaming'    => $streaming,
        'url'          => $url,
        'mal_url'      => $a['idMal'] ? 'https://myanimelist.net/anime/' . (int) $a['idMal'] : '',
        'anilist_url'  => $a['siteUrl'] ?? '',
        'status'       => 'Currently Airing',
        'airing'       => true,
        'donghua'      => true,     // ← key flag consumed by frontend filter
        'country'      => 'CN',
        'next_episode' => $a['nextAiringEpisode']['episode'] ?? null,
        'source'       => 'anilist',
    ];
}

function format_to_type(string $format): string {
    return match(strtoupper($format)) {
        'TV'          => 'TV',
        'TV_SHORT'    => 'TV Short',
        'MOVIE'       => 'Movie',
        'SPECIAL'     => 'Special',
        'OVA'         => 'OVA',
        'ONA'         => 'ONA',
        'MUSIC'       => 'Music',
        default       => 'TV',
    };
}
