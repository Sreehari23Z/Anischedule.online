<?php
// ============================================================
//  API: /api/push.php  (POST)
//  Actions: subscribe, unsubscribe, add_anime, remove_anime
// ============================================================
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false]);
    exit;
}

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';
$user   = auth_user(); // may be null (guest)

// ── Subscribe ─────────────────────────────────────────────
if ($action === 'subscribe') {
    $endpoint = trim($body['endpoint'] ?? '');
    $p256dh   = trim($body['p256dh']   ?? '');
    $auth_key = trim($body['auth']     ?? '');

    if (!$endpoint || !$p256dh || !$auth_key) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing subscription data']);
        exit;
    }

    $uid = $user ? $user['id'] : null;
    $stmt = db()->prepare(
        'INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE p256dh = VALUES(p256dh), auth = VALUES(auth)'
    );
    // Use first 500 chars of endpoint as partial key (endpoint can be long)
    $stmt->execute([$uid, $endpoint, $p256dh, $auth_key]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Unsubscribe ───────────────────────────────────────────
if ($action === 'unsubscribe') {
    $endpoint = $body['endpoint'] ?? '';
    db()->prepare('DELETE FROM push_subscriptions WHERE endpoint = ?')->execute([$endpoint]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Add anime to notification list ───────────────────────
if ($action === 'add_anime') {
    $endpoint = $body['endpoint'] ?? '';
    $anime_id = (int)($body['anime_id'] ?? 0);

    $stmt = db()->prepare('SELECT id, anime_ids FROM push_subscriptions WHERE endpoint = ?');
    $stmt->execute([$endpoint]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['ok' => false, 'error' => 'Subscription not found']);
        exit;
    }
    $ids = json_decode($row['anime_ids'] ?? '[]', true) ?: [];
    if (!in_array($anime_id, $ids)) {
        $ids[] = $anime_id;
    }
    db()->prepare('UPDATE push_subscriptions SET anime_ids = ? WHERE id = ?')
        ->execute([json_encode($ids), $row['id']]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Remove anime from notification list ──────────────────
if ($action === 'remove_anime') {
    $endpoint = $body['endpoint'] ?? '';
    $anime_id = (int)($body['anime_id'] ?? 0);

    $stmt = db()->prepare('SELECT id, anime_ids FROM push_subscriptions WHERE endpoint = ?');
    $stmt->execute([$endpoint]);
    $row = $stmt->fetch();
    if ($row) {
        $ids = json_decode($row['anime_ids'] ?? '[]', true) ?: [];
        $ids = array_values(array_filter($ids, fn($id) => $id !== $anime_id));
        db()->prepare('UPDATE push_subscriptions SET anime_ids = ? WHERE id = ?')
            ->execute([json_encode($ids), $row['id']]);
    }
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action']);
