<?php
// ============================================================
//  Dynamic Sitemap — /sitemap.xml
//  Serves as sitemap.xml via router
// ============================================================
require_once __DIR__ . '/config.php';
header('Content-Type: application/xml; charset=UTF-8');

$base = rtrim(SITE_URL, '/');
$today = date('Y-m-d');

// Current + nearby seasons
$month = (int) date('n');
$curSeason  = $month <= 3 ? 'winter' : ($month <= 6 ? 'spring' : ($month <= 9 ? 'summer' : 'fall'));
$curYear    = (int) date('Y');
$seasons    = ['winter','spring','summer','fall'];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

  <!-- ── High-priority static pages ── -->
  <url>
    <loc><?= $base ?>/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
    <lastmod><?= $today ?></lastmod>
  </url>
  <url>
    <loc><?= $base ?>/upcoming.php</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
    <lastmod><?= $today ?></lastmod>
  </url>
  <url>
    <loc><?= $base ?>/top.php</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
    <lastmod><?= $today ?></lastmod>
  </url>
  <url>
    <loc><?= $base ?>/seasonal.php</loc>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
    <lastmod><?= $today ?></lastmod>
  </url>
  <url>
    <loc><?= $base ?>/watchorder.php</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $base ?>/season-calendar.php</loc>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $base ?>/characters.php</loc>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc><?= $base ?>/birthdays.php</loc>
    <changefreq>daily</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc><?= $base ?>/search.php</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc><?= $base ?>/about.php</loc>
    <changefreq>monthly</changefreq>
    <priority>0.4</priority>
  </url>

  <!-- ── Seasonal chart pages (current year ± 1) ── -->
  <?php for ($y = $curYear - 1; $y <= $curYear + 1; $y++): ?>
    <?php foreach ($seasons as $s): ?>
  <url>
    <loc><?= $base ?>/seasonal.php?season=<?= $s ?>&amp;year=<?= $y ?></loc>
    <changefreq>weekly</changefreq>
    <priority><?= ($y === $curYear && $s === $curSeason) ? '0.9' : '0.6' ?></priority>
    <lastmod><?= $today ?></lastmod>
  </url>
    <?php endforeach; ?>
  <?php endfor; ?>

  <!-- ── Currently airing anime detail pages ── -->
  <?php
  try {
      require_once __DIR__ . '/api/anilist.php';
      foreach (['monday','tuesday','wednesday','thursday','friday','saturday','sunday'] as $day) {
          $items = jikan_schedule($day);
          foreach ($items as $a) {
              $mid   = (int)($a['mal_id'] ?? 0);
              $cover = $a['images']['jpg']['large_image_url'] ?? '';
              $name  = htmlspecialchars($a['title'] ?? '');
              if (!$mid) continue;
  ?>
  <url>
    <loc><?= $base ?>/anime.php?id=<?= $mid ?></loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
    <lastmod><?= $today ?></lastmod>
    <?php if ($cover): ?>
    <image:image>
      <image:loc><?= htmlspecialchars($cover) ?></image:loc>
      <image:title><?= $name ?></image:title>
    </image:image>
    <?php endif; ?>
  </url>
  <?php
          }
      }
  } catch (\Throwable $e) { /* skip dynamic entries if API unavailable */ }
  ?>

</urlset>
