<?php
require_once __DIR__ . '/config.php';
$page_title = 'Privacy Notice — ' . SITE_NAME;
$page_desc  = 'AniSchedule Privacy Notice — how we collect, use, and protect your information.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">
  <div class="legal-hero">
    <i class="fa-solid fa-shield-halved legal-hero-icon"></i>
    <h1>Privacy Notice</h1>
    <p class="legal-updated">Last updated March 09, 2026</p>
  </div>

  <div class="legal-toc">
    <h2>Table of Contents</h2>
    <ol>
      <li><a href="#s1">What Information Do We Collect?</a></li>
      <li><a href="#s2">How Do We Use Your Information?</a></li>
      <li><a href="#s3">Will Your Information Be Shared With Anyone?</a></li>
      <li><a href="#s4">Who Will Your Information Be Shared With?</a></li>
      <li><a href="#s5">Do We Use Cookies and Other Tracking Technologies?</a></li>
      <li><a href="#s6">Is Your Information Transferred Internationally?</a></li>
      <li><a href="#s7">What Is Our Stance on Third-Party Websites?</a></li>
      <li><a href="#s8">How Long Do We Keep Your Information?</a></li>
      <li><a href="#s9">How Do We Keep Your Information Safe?</a></li>
      <li><a href="#s10">Do We Collect Information From Minors?</a></li>
      <li><a href="#s11">What Are Your Privacy Rights?</a></li>
      <li><a href="#s12">Controls for Do-Not-Track Features</a></li>
      <li><a href="#s13">Do California Residents Have Specific Privacy Rights?</a></li>
      <li><a href="#s14">Do We Make Updates to This Notice?</a></li>
      <li><a href="#s15">How Can You Contact Us About This Notice?</a></li>
      <li><a href="#s16">How Can You Review, Update or Delete the Data We Collect From You?</a></li>
    </ol>
  </div>

  <div class="legal-body">

    <p>Thank you for choosing to be part of our community at AniSchedule ("we", "us", "our"). We are committed to protecting your personal information and your right to privacy. If you have any questions or concerns about this privacy notice, or our practices with regards to your personal information, please contact us at <a href="mailto:contact@anischedule.net">contact@anischedule.net</a>.</p>

    <p>When you visit our website and more generally use any of our services (the "Services", which include the Website), we appreciate that you are trusting us with your personal information. We take your privacy very seriously. In this privacy notice, we seek to explain to you in the clearest way possible what information we collect, how we use it and what rights you have in relation to it. We hope you take some time to read through it carefully, as it is important. If there are any terms in this privacy notice that you do not agree with, please discontinue use of our Services immediately.</p>

    <p>This privacy notice applies to all information collected through our Services (which, as described above, includes our Website), as well as any related services, sales, marketing or events.</p>

    <p><strong>Please read this privacy notice carefully as it will help you understand what we do with the information that we collect.</strong></p>

    <h2 id="s1">1. What Information Do We Collect?</h2>
    <h3>Personal information you disclose to us</h3>
    <p><em>In Short: We collect personal information that you provide to us.</em></p>
    <p>We collect personal information that you voluntarily provide to us when you register on the Website, express an interest in obtaining information about us or our products and Services, participate in activities on the Website (such as posting messages in our forums or entering contests), or otherwise contact us.</p>
    <p>The personal information we collect may include the following:</p>
    <ul>
      <li>Email addresses</li>
      <li>Usernames</li>
      <li>Passwords</li>
      <li>The last five IP addresses used to log into your account, retained for security purposes</li>
    </ul>
    <p>All personal information that you provide to us must be true, complete, and accurate, and you must notify us of any changes to such personal information.</p>

    <h3>Information automatically collected</h3>
    <p><em>In Short: Some information — such as your Internet Protocol (IP) address and/or browser and device characteristics — is collected automatically when you visit our Website.</em></p>
    <p>We automatically collect certain information when you visit, use, or navigate the Website. This information does not reveal your specific identity (like your name or contact information) but may include device and usage information, such as your IP address, browser and device characteristics, operating system, language preferences, referring URLs, device name, country, location, information about how and when you use our Website and other technical information. This information is primarily needed to maintain the security and operation of our Website and for our internal analytics and reporting purposes.</p>
    <p>Like many businesses, we also collect information through cookies and similar technologies. The information we collect includes:</p>
    <ul>
      <li><strong>Log and Usage Data.</strong> Log and usage data is service-related, diagnostic, usage, and performance information our servers automatically collect when you access or use our Website and which we record in log files. Depending on how you interact with us, this log data may include your IP address, device information, browser type and settings, and information about your activity on the Website (such as the date/time stamps associated with your usage, pages and files viewed, searches, and other actions you take such as which features you use), device event information (such as system activity, error reports, and hardware settings).</li>
      <li><strong>Device Data.</strong> We collect device data such as information about your computer, phone, tablet, or other device you use to access the Website. Depending on the device used, this device data may include information such as your IP address (or proxy server), device and application identification numbers, location, browser type, hardware model, Internet service provider and/or mobile carrier, operating system, and system configuration information.</li>
      <li><strong>Location Data.</strong> We collect location data such as information about your device's location, which can be either precise or imprecise. How much information we collect depends on the type and settings of the device you use to access the Website. For example, we may use GPS and other technologies to collect geolocation data that tells us your current location (based on your IP address). You can opt out of allowing us to collect this information either by refusing access to the information or by disabling your Location setting on your device. Note, however, if you choose to opt out, you may not be able to use certain aspects of the Services.</li>
    </ul>

    <h2 id="s2">2. How Do We Use Your Information?</h2>
    <p><em>In Short: We process your information for purposes based on legitimate business interests, the fulfillment of our contract with you, compliance with our legal obligations, and/or your consent.</em></p>
    <p>We use personal information collected via our Website for a variety of business purposes described below. We use the information we collect or receive:</p>
    <ul>
      <li><strong>To facilitate account creation and logon process.</strong> If you choose to link your account with us to a third-party account (such as your Google or Facebook account), we use the information you allowed us to collect from those third parties to facilitate account creation and logon process for the performance of the contract.</li>
      <li><strong>Request feedback.</strong> We may use your information to request feedback and to contact you about your use of our Website.</li>
      <li><strong>To enable user-to-user communications.</strong> We may use your information in order to enable user-to-user communications with each user's consent.</li>
      <li><strong>To manage user accounts.</strong> We may use your information for the purposes of managing our account and keeping it in working order.</li>
      <li><strong>To send administrative information to you.</strong> We may use your personal information to send you product, service and new feature information and/or information about changes to our terms, conditions, and policies.</li>
      <li><strong>To protect our Services.</strong> We may use your information as part of our efforts to keep our Website safe and secure (for example, for fraud monitoring and prevention).</li>
      <li><strong>To enforce our terms, conditions and policies</strong> for business purposes, to comply with legal and regulatory requirements or in connection with our contract.</li>
      <li><strong>To respond to legal requests and prevent harm.</strong> If we receive a subpoena or other legal request, we may need to inspect the data we hold to determine how to respond.</li>
      <li><strong>To deliver and facilitate delivery of services to the user.</strong> We may use your information to provide you with the requested service.</li>
      <li><strong>To respond to user inquiries/offer support to users.</strong> We may use your information to respond to your inquiries and solve any potential issues you might have with the use of our Services.</li>
      <li><strong>For other business purposes.</strong> We may use your information for other business purposes, such as data analysis, identifying usage trends, determining the effectiveness of our promotional campaigns and to evaluate and improve our Website, products, marketing and your experience. We may use and store this information in aggregated and anonymized form so that it is not associated with individual end users and does not include personal information. We will not use identifiable personal information without your consent.</li>
    </ul>

    <h2 id="s3">3. Will Your Information Be Shared With Anyone?</h2>
    <p><em>In Short: We only share information with your consent, to comply with laws, to provide you with services, to protect your rights, or to fulfill business obligations.</em></p>
    <p>We may process or share your data that we hold based on the following legal basis:</p>
    <ul>
      <li><strong>Consent:</strong> We may process your data if you have given us specific consent to use your personal information for a specific purpose.</li>
      <li><strong>Legitimate Interests:</strong> We may process your data when it is reasonably necessary to achieve our legitimate business interests.</li>
      <li><strong>Performance of a Contract:</strong> Where we have entered into a contract with you, we may process your personal information to fulfill the terms of our contract.</li>
      <li><strong>Legal Obligations:</strong> We may disclose your information where we are legally required to do so in order to comply with applicable law, governmental requests, a judicial proceeding, court order, or legal process, such as in response to a court order or a subpoena (including in response to public authorities to meet national security or law enforcement requirements).</li>
      <li><strong>Vital Interests:</strong> We may disclose your information where we believe it is necessary to investigate, prevent, or take action regarding potential violations of our policies, suspected fraud, situations involving potential threats to the safety of any person and illegal activities, or as evidence in litigation in which we are involved.</li>
    </ul>
    <p>More specifically, we may need to process your data or share your personal information in the following situations:</p>
    <ul>
      <li><strong>Business Transfers.</strong> We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.</li>
      <li><strong>Vendors, Consultants and Other Third-Party Service Providers.</strong> We may share your data with third-party vendors, service providers, contractors or agents who perform services for us or on our behalf and require access to such information to do that work. Examples include: payment processing, data analysis, email delivery, hosting services, customer service and marketing efforts. We may allow selected third parties to use tracking technology on the Website, which will enable them to collect data on our behalf about how you interact with our Website over time. Unless described in this notice, we do not share, sell, rent or trade any of your information with third parties for their promotional purposes.</li>
      <li><strong>Business Partners.</strong> We may share your information with our business partners to offer you certain products, services or promotions.</li>
    </ul>

    <h2 id="s4">4. Who Will Your Information Be Shared With?</h2>
    <p><em>In Short: We only share information with the following third parties.</em></p>
    <p>We only share and disclose your information with the following third parties. We have categorized each party so that you may easily understand the purpose of our data collection and processing practices. If you wish to revoke your consent, please contact us using the contact details provided in section 15.</p>
    <ul>
      <li><strong>Advertising, Direct Marketing, and Lead Generation:</strong> Third-party advertising networks and affiliate programme providers</li>
      <li><strong>Content Optimization:</strong> Google Fonts</li>
      <li><strong>Functionality and Infrastructure Optimization:</strong> Cloud hosting and content delivery providers</li>
      <li><strong>Web and Mobile Analytics:</strong> Analytics service providers</li>
    </ul>

    <h2 id="s5">5. Do We Use Cookies and Other Tracking Technologies?</h2>
    <p><em>In Short: We may use cookies and other tracking technologies to collect and store your information.</em></p>
    <p>We may use cookies and similar tracking technologies (like web beacons and pixels) to access or store information. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.</p>
    <p>We use Google AdSense to display advertisements on this site. Google uses cookies, including the DoubleClick cookie, to serve ads based on your prior visits to this site or other sites on the internet. You may opt out of personalised advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener">https://www.google.com/settings/ads</a>.</p>
    <p>This site also participates in the Apple Services Performance Partners Programme and the Amazon Associates Programme. When you click affiliate links, the respective third parties may set cookies on your device to track the referral, governed by their own privacy policies.</p>

    <h2 id="s6">6. Is Your Information Transferred Internationally?</h2>
    <p><em>In Short: We may transfer, store, and process your information in countries other than your own.</em></p>
    <p>Our servers may be located in countries other than your own. By using the Website, you acknowledge that your data may be transferred to and processed in countries outside your country of residence, including countries outside the European Economic Area (EEA).</p>
    <p>Where personal data is transferred outside the EEA, we take appropriate measures to ensure it remains protected in accordance with applicable data protection law. Our infrastructure and service providers maintain compliance with applicable data protection frameworks.</p>

    <h2 id="s7">7. What Is Our Stance on Third-Party Websites?</h2>
    <p><em>In Short: We are not responsible for the safety of any information that you share with third-party providers who advertise, but are not affiliated with, our Website.</em></p>
    <p>The Website may contain advertisements from third parties that are not affiliated with us and which may link to other websites, online services or mobile applications. We cannot guarantee the safety and privacy of data you provide to any third parties. Any data collected by third parties is not covered by this privacy notice. We are not responsible for the content or privacy and security practices and policies of any third parties, including other websites, services or applications that may be linked to or from the Website.</p>

    <h2 id="s8">8. How Long Do We Keep Your Information?</h2>
    <p><em>In Short: We keep your information for as long as necessary to fulfill the purposes outlined in this privacy notice unless otherwise required by law.</em></p>
    <p>We will only keep your personal information for as long as it is necessary for the purposes set out in this privacy notice, unless a longer retention period is required or permitted by law. No purpose in this notice will require us keeping your personal information for longer than the period of time in which users have an account with us.</p>
    <p>When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize such information, or, if this is not possible (for example, because your personal information has been stored in backup archives), then we will securely store your personal information and isolate it from any further processing until deletion is possible.</p>

    <h2 id="s9">9. How Do We Keep Your Information Safe?</h2>
    <p><em>In Short: We aim to protect your personal information through a system of organizational and technical security measures.</em></p>
    <p>We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security, and improperly collect, access, steal, or modify your information. Although we will do our best to protect your personal information, transmission of personal information to and from our Website is at your own risk. You should only access the Website within a secure environment.</p>

    <h2 id="s10">10. Do We Collect Information From Minors?</h2>
    <p><em>In Short: We do not knowingly collect data from or market to children under 13 years of age.</em></p>
    <p>We do not knowingly solicit data from or market to children under 13 years of age. By using the Website, you represent that you are at least 13 or that you are the parent or guardian of such a minor and consent to such minor dependent's use of the Website. If we learn that personal information from users less than 13 years of age has been collected, we will deactivate the account and take reasonable measures to promptly delete such data from our records. If you become aware of any data we may have collected from children under age 13, please contact us at <a href="mailto:contact@anischedule.net">contact@anischedule.net</a>.</p>

    <h2 id="s11">11. What Are Your Privacy Rights?</h2>
    <p><em>In Short: In some regions, such as the European Economic Area, you have rights that allow you greater access to and control over your personal information. You may review, change, or terminate your account at any time.</em></p>
    <p>In some regions (like the European Economic Area), you have certain rights under applicable data protection laws. These may include the right (i) to request access and obtain a copy of your personal information, (ii) to request rectification or erasure; (iii) to restrict the processing of your personal information; and (iv) if applicable, to data portability. In certain circumstances, you may also have the right to object to the processing of your personal information. To make such a request, please use the contact details provided below. We will consider and act upon any request in accordance with applicable data protection laws.</p>
    <p>If you are a resident in the European Economic Area and you believe we are unlawfully processing your personal information, you also have the right to complain to your local data protection supervisory authority. You can find their contact details here: <a href="http://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm" target="_blank" rel="noopener">http://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm</a>.</p>
    <p>If you have questions or comments about your privacy rights, you may email us at <a href="mailto:contact@anischedule.net">contact@anischedule.net</a>.</p>
    <h3>Account Information</h3>
    <p>If you would at any time like to review or change the information in your account or terminate your account, you can log in to your account settings and update your user account, or contact us using the contact information provided.</p>
    <p>Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, we may retain some information in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of Use and/or comply with applicable legal requirements.</p>
    <h3>Cookies and similar technologies</h3>
    <p>Most Web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove cookies and to reject cookies. If you choose to remove cookies or reject cookies, this could affect certain features or services of our Website. To opt-out of interest-based advertising by advertisers on our Website visit <a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener">https://www.aboutads.info/choices/</a> and <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener">https://www.google.com/settings/ads</a>.</p>

    <h2 id="s12">12. Controls for Do-Not-Track Features</h2>
    <p>Most web browsers and some mobile operating systems and mobile applications include a Do-Not-Track ("DNT") feature or setting you can activate to signal your privacy preference not to have data about your online browsing activities monitored and collected. At this stage no uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals or any other mechanism that automatically communicates your choice not to be tracked online. If a standard for online tracking is adopted that we must follow in the future, we will inform you about that practice in a revised version of this privacy notice.</p>

    <h2 id="s13">13. Do California Residents Have Specific Privacy Rights?</h2>
    <p><em>In Short: Yes, if you are a resident of California, you are granted specific rights regarding access to your personal information.</em></p>
    <p>California Civil Code Section 1798.83, also known as the "Shine The Light" law, permits our users who are California residents to request and obtain from us, once a year and free of charge, information about categories of personal information (if any) we disclosed to third parties for direct marketing purposes and the names and addresses of all third parties with which we shared personal information in the immediately preceding calendar year. If you are a California resident and would like to make such a request, please submit your request in writing to us using the contact information provided below.</p>
    <h3>CCPA Privacy Notice</h3>
    <p>The California Code of Regulations defines a "resident" as: (1) every individual who is in the State of California for other than a temporary or transitory purpose and (2) every individual who is domiciled in the State of California who is outside the State of California for a temporary or transitory purpose. All other individuals are defined as "non-residents."</p>
    <h4>What categories of personal information do we collect?</h4>
    <p>We have collected the following categories of personal information in the past twelve (12) months:</p>
    <ul>
      <li><strong>Identifiers.</strong> Examples: Online identifier, Internet Protocol address, email address and account name.</li>
      <li><strong>Personal information categories listed in the California Customer Records statute.</strong> Examples: Contact information.</li>
    </ul>
    <p>We may also collect other personal information outside of these categories in instances where you interact with us in-person, online, or by phone or mail in the context of: receiving help through our customer support channels; participation in customer surveys or contests; and facilitation in the delivery of our Services and to respond to your inquiries.</p>
    <h4>Your rights with respect to your personal data</h4>
    <ul>
      <li><strong>Right to request deletion of the data.</strong> You can ask for the deletion of your personal information. If you ask us to delete your personal information, we will respect your request and delete your personal information, subject to certain exceptions provided by law.</li>
      <li><strong>Right to be informed.</strong> Depending on the circumstances, you have a right to know whether we collect and use your personal information; the categories of personal information that we collect; the purposes for which the collected personal information is used; whether we sell your personal information to third parties; and the categories of third parties to whom the personal information was sold or disclosed for a business purpose.</li>
      <li><strong>Right to Non-Discrimination.</strong> We will not discriminate against you if you exercise your privacy rights.</li>
    </ul>
    <p>To exercise these rights, please contact us using the details in section 15.</p>

    <h2 id="s14">14. Do We Make Updates to This Notice?</h2>
    <p><em>In Short: Yes, we will update this notice as necessary to stay compliant with relevant laws.</em></p>
    <p>We may update this privacy notice from time to time. The updated version will be effective as soon as it is accessible. If we make material changes to this privacy notice, we may notify you either by prominently posting a notice of such changes or by directly sending you a notification. We encourage you to review this privacy notice frequently to be informed of how we are protecting your information.</p>

    <h2 id="s15">15. How Can You Contact Us About This Notice?</h2>
    <p>If you have questions or comments about this notice, you may email us at <a href="mailto:contact@anischedule.net">contact@anischedule.net</a> or reach us via the <a href="<?= $base ?>/contact.php">contact page</a>.</p>

    <h2 id="s16">16. How Can You Review, Update, or Delete the Data We Collect From You?</h2>
    <p>Based on the applicable laws of your country, you may have the right to request access to the personal information we collect from you, change that information, or delete it in some circumstances. To request to review, update, or delete your personal information, please contact us using the details in section 15 or visit your account settings if you have a registered account.</p>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
