<?php
// ============================================================
//  Upcoming Anime — /upcoming.php
//  Shows next season's upcoming anime with premiere countdowns
// ============================================================
require_once __DIR__ . '/config.php';
$month = (int) date('n');
$nextSeason = $month <= 3 ? 'Spring' : ($month <= 6 ? 'Summer' : ($month <= 9 ? 'Fall' : 'Winter'));
$nextYear   = $month === 12 ? (int)date('Y') + 1 : date('Y');
$page_title    = 'Upcoming Anime ' . $nextSeason . ' ' . $nextYear . ' | Premiere Dates & Countdowns — AniSchedule';
$page_desc     = 'Upcoming anime for ' . $nextSeason . ' ' . $nextYear . '. See premiere dates, countdown timers, trailers, and early details for all announced new anime series.';
$page_keywords = 'upcoming anime, new anime ' . $nextYear . ', ' . strtolower($nextSeason) . ' ' . $nextYear . ' anime, anime premiere dates, next season anime, upcoming anime list';
$active_nav = 'upcoming';
include __DIR__ . '/includes/header.php';
?>

<div class="page-upcoming">

  <!-- ── Hero ───────────────────────────────────────────── -->
  <section class="upcoming-hero">
    <div class="upcoming-hero-inner">
      <h1 class="hero-title">Coming <span class="gradient-text">Soon</span></h1>
      <p class="hero-sub">Upcoming anime premiering next season. Mark your calendars!</p>
    </div>
  </section>

  <!-- ── Grid ───────────────────────────────────────────── -->
  <div class="container" style="padding-top:2rem;padding-bottom:2rem">
    <div id="upcomingGrid" class="anime-grid">
      <div class="loading-state" style="grid-column:1/-1">
        <div class="spinner"></div>
        <p>Loading upcoming anime…</p>
      </div>
    </div>
  </div>

</div>

<script>
(function(){
  const base = window.SITE?.base ?? '';
  const grid = document.getElementById('upcomingGrid');

  fetch(base + '/api/upcoming.php')
    .then(r => r.json())
    .then(json => {
      if (!json.ok || !json.data?.length) {
        grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1"><i class="fa-solid fa-calendar-xmark"></i><p>No upcoming anime found.</p></div>';
        return;
      }
      grid.innerHTML = json.data.map(a => buildCard(a)).join('');
      // kick off countdowns
      if (window.Countdown) window.Countdown.initUpcoming();
    })
    .catch(() => {
      grid.innerHTML = '<div class="error-state" style="grid-column:1/-1"><i class="fa-solid fa-triangle-exclamation"></i><p>Failed to load upcoming anime.</p></div>';
    });

  function buildCard(a) {
    const title   = a.title_en || a.title;
    const cover   = a.cover || '';
    const genres  = (a.genres || []).slice(0,2).join(', ');
    const premiere = a.premiere_ts ? a.premiere_ts * 1000 : 0;
    const now      = Date.now();
    const diffDays = premiere > now ? Math.ceil((premiere - now) / 86400000) : 0;
    const premiereBadge = premiere > now
      ? `<span class="upcoming-premiere-badge">Premieres in ${diffDays} day${diffDays !== 1 ? 's' : ''}</span>`
      : `<span class="upcoming-premiere-badge upcoming-soon">Coming Soon</span>`;

    return `
      <div class="anime-card upcoming-card">
        <a href="${base}/anime.php?id=${a.id}" class="card-cover-link">
          <div class="card-cover-wrap">
            ${cover ? `<img src="${cover}" alt="${escHtml(title)}" class="card-cover" loading="lazy">` : '<div class="card-cover-placeholder"></div>'}
            <div class="card-overlay">
              <span class="card-score"><i class="fa-solid fa-star"></i> ${a.score ?? 'N/A'}</span>
            </div>
          </div>
        </a>
        <div class="card-info">
          ${premiereBadge}
          <div class="card-title"><a href="${base}/anime.php?id=${a.id}">${escHtml(title)}</a></div>
          <div class="card-meta">
            <span class="badge badge-type">${a.type || 'TV'}</span>
            ${genres ? `<span class="card-genres">${escHtml(genres)}</span>` : ''}
          </div>
          ${premiere > now ? `<div class="card-countdown countdown-live" data-premiere="${a.premiere_ts}">Loading…</div>` : ''}
        </div>
      </div>`;
  }

  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
