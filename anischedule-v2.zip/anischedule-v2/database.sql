-- AniSchedule Database Schema
-- Run this in your Hostinger MySQL panel (phpMyAdmin)
-- Database: anischedule (create this database first)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `timezone` VARCHAR(60) NOT NULL DEFAULT 'UTC',
  `theme` ENUM('dark','light') NOT NULL DEFAULT 'dark',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: watchlist
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `watchlist` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `anime_id` INT UNSIGNED NOT NULL,
  `anime_title` VARCHAR(255) NOT NULL,
  `anime_cover` VARCHAR(500) DEFAULT NULL,
  `anime_format` VARCHAR(30) DEFAULT NULL,
  `status` ENUM('watching','plan_to_watch','completed','on_hold','dropped') NOT NULL DEFAULT 'plan_to_watch',
  `progress` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `score` TINYINT UNSIGNED DEFAULT NULL COMMENT '1-10 rating',
  `notes` TEXT DEFAULT NULL,
  `added_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_anime` (`user_id`, `anime_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  CONSTRAINT `watchlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: push_subscriptions
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `push_subscriptions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL COMMENT 'NULL = guest subscription',
  `endpoint` TEXT NOT NULL,
  `p256dh` VARCHAR(255) NOT NULL,
  `auth` VARCHAR(255) NOT NULL,
  `anime_ids` TEXT DEFAULT NULL COMMENT 'JSON array of anime IDs to notify',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `push_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: api_cache
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `api_cache` (
  `cache_key` VARCHAR(255) NOT NULL,
  `data` LONGTEXT NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  PRIMARY KEY (`cache_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: sessions (for PHP session storage)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` VARCHAR(128) NOT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `data` TEXT DEFAULT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: notification_subscriptions
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notification_subscriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `anime_id` INT NOT NULL,
  `anime_title` VARCHAR(255) NOT NULL,
  `anime_cover` VARCHAR(500) DEFAULT NULL,
  `contact_type` ENUM('email','whatsapp') NOT NULL,
  `contact_value` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_sub` (`anime_id`, `contact_type`, `contact_value`),
  KEY `anime_id` (`anime_id`),
  KEY `contact_type` (`contact_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: notification_sent_log
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notification_sent_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `subscription_id` INT NOT NULL,
  `episode_aired_at` DATETIME NOT NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_sent` (`subscription_id`, `episode_aired_at`),
  KEY `subscription_id` (`subscription_id`),
  CONSTRAINT `fk_sent_sub` FOREIGN KEY (`subscription_id`)
    REFERENCES `notification_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
