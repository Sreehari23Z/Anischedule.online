<?php
require_once __DIR__ . '/config.php';
$page_title = 'Copyright Policy — ' . SITE_NAME;
$page_desc  = 'AniSchedule copyright and DMCA takedown policy. How to report infringing content.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">

  <div class="legal-hero">
    <i class="fa-solid fa-scale-balanced legal-hero-icon"></i>
    <h1>Copyright Policy</h1>
    <p class="legal-updated">Last updated March 09, 2026</p>
    <p>How we handle intellectual property and how to submit a takedown request.</p>
  </div>

  <div class="legal-body">

    <h2>Overview</h2>
    <p>AniSchedule is an anime schedule and discovery service. We do not host, distribute, or stream any anime content. We display publicly available metadata — including titles, synopses, key visuals, and broadcast information — sourced from third-party databases (<a href="https://jikan.moe/" target="_blank" rel="noopener">Jikan/MAL</a> and <a href="https://anilist.co/" target="_blank" rel="noopener">AniList</a>) for the purpose of informing viewers about currently airing and upcoming anime.</p>
    <p>We respect the intellectual property rights of all creators, studios, publishers, and distributors. If you believe that content appearing on AniSchedule infringes your copyright, please follow the process below.</p>

    <h2>What We Display</h2>
    <p>Content on AniSchedule falls into two categories:</p>
    <ul>
      <li><strong>Site-owned content:</strong> Our source code, original UI design, text we have written, and the AniSchedule logo and brand assets. These are our proprietary property.</li>
      <li><strong>Third-party content:</strong> Anime titles, synopses, key visual images, promotional poster images, studio names, genre metadata, broadcast schedules, and score data. This content is the property of the respective rights holders — studios, publishers, licensors, and distributors — and is displayed here for informational purposes only under the principle of fair use and informational reference.</li>
    </ul>
    <p>We do not claim ownership of any anime-related intellectual property. All third-party trademarks, service marks, and logos remain the property of their respective owners.</p>

    <h2>DMCA Takedown Requests</h2>
    <p>If you are a copyright holder or an authorised agent and you believe that content on AniSchedule infringes your copyright under the Digital Millennium Copyright Act (DMCA), you may submit a takedown notice to us.</p>

    <h3>Your notice must include:</h3>
    <ol>
      <li>Your full legal name, company name (if applicable), address, telephone number, and email address.</li>
      <li>A description of the copyrighted work you claim has been infringed — including title, original URL, or a copy of the work.</li>
      <li>The specific URL(s) on AniSchedule where the allegedly infringing content appears.</li>
      <li>A statement that you have a good faith belief that the use of the material in the manner complained of is not authorised by the copyright owner, its agent, or the law.</li>
      <li>A statement made under penalty of perjury that the information in your notice is accurate and that you are the copyright owner or are authorised to act on the copyright owner's behalf.</li>
      <li>Your physical or electronic signature.</li>
    </ol>

    <div class="copyright-contact-box">
      <i class="fa-solid fa-envelope-open-text"></i>
      <div>
        <h3>Submit a Takedown Notice</h3>
        <p>Send your complete DMCA notice to:</p>
        <a href="mailto:copyright@anischedule.net" class="copyright-email">copyright@anischedule.net</a>
        <p class="copyright-alt-note">Or use the <a href="<?= $base ?>/contact.php?reason=Copyright+%2F+Takedown">contact form</a> and select "Copyright / Takedown" as the reason.</p>
      </div>
    </div>

    <h2>Counter-Notification</h2>
    <p>If you believe content was removed in error, you may submit a counter-notification. Your counter-notice must include:</p>
    <ol>
      <li>Your full name, address, telephone number, and email address.</li>
      <li>Identification of the content that was removed and the location where it appeared before removal.</li>
      <li>A statement under penalty of perjury that you have a good faith belief the content was removed as a result of a mistake or misidentification.</li>
      <li>A statement that you consent to the jurisdiction of the Federal District Court for the judicial district in which your address is located.</li>
      <li>Your physical or electronic signature.</li>
    </ol>
    <p>Counter-notifications should be sent to the same email address: <a href="mailto:copyright@anischedule.net">copyright@anischedule.net</a>.</p>

    <h2>Response Time</h2>
    <p>We aim to acknowledge all valid takedown requests within <strong>3 business days</strong> and to act on them within <strong>10 business days</strong>. Complex cases or counter-notification disputes may take longer.</p>

    <h2>Repeat Infringers</h2>
    <p>AniSchedule has a policy of terminating accounts of users who are repeat copyright infringers, in appropriate circumstances. If you are a registered user and repeatedly post content that infringes third-party intellectual property, your account may be permanently disabled.</p>

    <h2>Fair Use</h2>
    <p>We believe our use of anime promotional images and metadata constitutes fair use under copyright law because:</p>
    <ul>
      <li>Images are used for informational and identification purposes only, not for entertainment or as a substitute for the original work.</li>
      <li>We display low-resolution promotional images that are already publicly distributed by studios and publishers for promotional purposes.</li>
      <li>Our use does not harm the market for or value of the original works — in fact, it directs users to legal streaming platforms where they can watch the content.</li>
      <li>We do not monetise individual anime images or metadata directly.</li>
    </ul>
    <p>That said, we take all legitimate takedown requests seriously and will act promptly when required.</p>

    <h2>Contact for Licensing</h2>
    <p>If you are a rights holder interested in licensing your content to AniSchedule or in establishing a formal content partnership, please <a href="<?= $base ?>/contact.php">contact us</a>. We are always open to working with studios, publishers, and distributors to ensure our service complies with your requirements.</p>

    <div class="legal-contact-box">
      <p>Copyright questions? Email <a href="mailto:copyright@anischedule.net">copyright@anischedule.net</a> or visit our <a href="<?= $base ?>/contact.php">contact page</a>.</p>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
