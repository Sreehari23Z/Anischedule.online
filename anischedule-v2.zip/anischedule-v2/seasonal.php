<?php
// ============================================================
//  Seasonal Chart Page
// ============================================================
require_once __DIR__ . '/config.php';

$month = (int) date('n');
$curSeason = $month <= 3 ? 'winter' : ($month <= 6 ? 'spring' : ($month <= 9 ? 'summer' : 'fall'));
$curYear   = (int) date('Y');

$season = strtolower($_GET['season'] ?? $curSeason);
$year   = (int)($_GET['year'] ?? $curYear);
$valid_seasons = ['winter','spring','summer','fall'];
if (!in_array($season, $valid_seasons)) $season = $curSeason;

$page_title    = ucfirst($season) . ' ' . $year . ' Anime Season Chart | All New Anime — AniSchedule';
$page_desc     = 'Complete ' . ucfirst($season) . ' ' . $year . ' anime season chart. Browse all new anime with scores, genres, streaming links, and air schedules. Updated daily.';
$page_keywords = strtolower($season) . ' ' . $year . ' anime, ' . $year . ' anime season, new anime ' . ucfirst($season) . ' ' . $year . ', seasonal anime chart, anime season lineup';
$json_ld = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'BreadcrumbList',
    'itemListElement' => [
        ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>SITE_URL.'/'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Seasonal Chart','item'=>SITE_URL.'/seasonal.php'],
        ['@type'=>'ListItem','position'=>3,'name'=>ucfirst($season).' '.$year,'item'=>SITE_URL.'/seasonal.php?season='.$season.'&year='.$year],
    ]
]);
$active_nav = 'seasonal';
include __DIR__ . '/includes/header.php';
?>

<div class="page-seasonal">

  <!-- Season selector bar -->
  <div class="season-bar">
    <div class="container season-bar-inner">
      <h1 class="season-title">
        <i class="fa-solid <?= match($season) {
          'winter' => 'fa-snowflake',
          'spring' => 'fa-seedling',
          'summer' => 'fa-sun',
          'fall'   => 'fa-leaf',
        } ?>"></i>
        <?= ucfirst($season) ?> <span class="season-year"><?= $year ?></span>
      </h1>

      <!-- Season picker -->
      <div class="season-nav">
        <?php
        $prevSeason = ['winter'=>'fall','spring'=>'winter','summer'=>'spring','fall'=>'summer'];
        $nextSeason = ['winter'=>'spring','spring'=>'summer','summer'=>'fall','fall'=>'winter'];
        $prevYear   = $season === 'winter' ? $year - 1 : $year;
        $nextYear   = $season === 'fall'   ? $year + 1 : $year;
        ?>
        <a href="?year=<?= $prevYear ?>&season=<?= $prevSeason[$season] ?>" class="btn btn-ghost btn-sm">
          <i class="fa-solid fa-chevron-left"></i> <?= ucfirst($prevSeason[$season]) ?>
        </a>

        <select id="seasonJump" class="season-jump-select">
          <?php foreach (['winter','spring','summer','fall'] as $s): ?>
            <option value="?year=<?= $year ?>&season=<?= $s ?>"
              <?= $s === $season ? 'selected' : '' ?>><?= ucfirst($s) ?> <?= $year ?></option>
          <?php endforeach; ?>
          <?php for ($y = $curYear; $y >= $curYear - 3; $y--): ?>
            <?php foreach (['fall','summer','spring','winter'] as $s): ?>
              <?php if ($y === $year && $s === $season) continue; ?>
              <option value="?year=<?= $y ?>&season=<?= $s ?>"><?= ucfirst($s) ?> <?= $y ?></option>
            <?php endforeach; ?>
          <?php endfor; ?>
        </select>

        <?php if ("$year-$season" < "$curYear-$curSeason"): ?>
        <a href="?year=<?= $nextYear ?>&season=<?= $nextSeason[$season] ?>" class="btn btn-ghost btn-sm">
          <?= ucfirst($nextSeason[$season]) ?> <i class="fa-solid fa-chevron-right"></i>
        </a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="container">
    <!-- Filters + Sort -->
    <div class="seasonal-controls">
      <div class="filter-chips" id="seasonTypeFilter">
        <button class="chip active" data-type="">All</button>
        <button class="chip" data-type="TV">TV</button>
        <button class="chip" data-type="Movie">Movie</button>
        <button class="chip" data-type="OVA">OVA</button>
        <button class="chip" data-type="ONA">ONA</button>
        <button class="chip" data-type="Special">Special</button>
      </div>
      <div class="sort-group">
        <label>Sort:</label>
        <select id="seasonSort" class="sort-select">
          <option value="members">Popularity</option>
          <option value="score">Score</option>
          <option value="title">Title A–Z</option>
        </select>
      </div>
      <div class="view-toggle">
        <button class="view-btn active" data-view="grid" title="Grid view"><i class="fa-solid fa-grip"></i></button>
        <button class="view-btn" data-view="list" title="List view"><i class="fa-solid fa-list"></i></button>
      </div>
    </div>

    <!-- Results count -->
    <p class="results-count" id="seasonCount"></p>

    <!-- Grid -->
    <div id="seasonalGrid" class="anime-grid">
      <div class="loading-state">
        <div class="spinner"></div>
        <p>Loading <?= ucfirst($season) ?> <?= $year ?> anime…</p>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  // Jump on select change
  document.getElementById('seasonJump').addEventListener('change', function() {
    window.location.href = this.value;
  });

  const API = `${window.SITE.base}/api/seasonal.php?year=<?= $year ?>&season=<?= $season ?>`;
  let allAnime = [];

  const base = window.SITE?.base || '';
  function renderGrid(anime, view = 'grid') {
    const grid = document.getElementById('seasonalGrid');
    document.getElementById('seasonCount').textContent = `${anime.length} anime this season`;

    if (!anime.length) {
      grid.innerHTML = '<div class="empty-state"><i class="fa-solid fa-film"></i><p>No anime found.</p></div>';
      return;
    }

    grid.className = `anime-grid ${view === 'list' ? 'list-view' : ''}`;
    grid.innerHTML = anime.map(a => `
      <article class="anime-card" data-type="${a.type}" data-id="${a.id}">
        <a href="${base}${a.url}" class="card-cover-link">
          <div class="card-cover-wrap">
            <img src="${a.cover}" alt="${a.title_en}" class="card-cover" loading="lazy">
            <div class="card-overlay">
              <div class="card-score">${a.score ? '★ '+a.score : 'N/A'}</div>
              <div class="card-actions">
                <button class="card-action-btn wl-btn" data-id="${a.id}" data-title="${escHtml(a.title_en)}" data-cover="${a.cover}" data-format="${a.type}" title="Add to watchlist">
                  <i class="fa-solid fa-plus"></i>
                </button>
                <button class="card-action-btn notif-btn" data-id="${a.id}" title="Get notifications">
                  <i class="fa-solid fa-bell"></i>
                </button>
              </div>
            </div>
          </div>
        </a>
        <div class="card-info">
          <h3 class="card-title"><a href="${base}${a.url}">${a.title_en}</a></h3>
          <div class="card-meta">
            <span class="badge badge-type">${a.type}</span>
            ${a.episodes ? `<span class="card-ep">${a.episodes} eps</span>` : ''}
            ${a.airing ? '<span class="badge badge-airing">Airing</span>' : ''}
          </div>
          <p class="card-genres">${(a.genres||[]).slice(0,3).join(' · ')}</p>
          ${view === 'list' ? `<p class="card-synopsis">${a.synopsis}</p>` : ''}
          <div class="card-streaming">
            ${(a.streaming||[]).slice(0,3).map(s =>
              `<a href="${s.url}" target="_blank" rel="noopener" class="stream-link" title="${s.name}">
                 <img src="/assets/img/stream-${s.name.toLowerCase().replace(/[^a-z]/g,'')}.svg"
                      onerror="this.style.display='none'" alt="${s.name}" class="stream-icon">
               </a>`
            ).join('')}
          </div>
        </div>
      </article>
    `).join('');

    // Attach watchlist + notif buttons
    grid.querySelectorAll('.wl-btn').forEach(b => b.addEventListener('click', e => {
      e.preventDefault();
      window.App.openWatchlistModal({
        id: b.dataset.id, title: b.dataset.title,
        cover: b.dataset.cover, format: b.dataset.format
      });
    }));
    grid.querySelectorAll('.notif-btn').forEach(b => b.addEventListener('click', e => {
      e.preventDefault();
      window.Push.toggleAnime(parseInt(b.dataset.id));
    }));
  }

  function applyFilters() {
    const type = document.querySelector('#seasonTypeFilter .chip.active')?.dataset.type || '';
    const sort = document.getElementById('seasonSort').value;
    const view = document.querySelector('.view-btn.active')?.dataset.view || 'grid';

    let filtered = allAnime.filter(a => !type || a.type === type);
    filtered.sort((a, b) => sort === 'score'
      ? (b.score || 0) - (a.score || 0)
      : sort === 'title'
      ? a.title.localeCompare(b.title)
      : b.members - a.members
    );
    renderGrid(filtered, view);
  }

  // Fetch data
  fetch(API)
    .then(r => r.json())
    .then(d => {
      allAnime = d.anime || [];
      applyFilters();
    })
    .catch(() => {
      document.getElementById('seasonalGrid').innerHTML =
        '<div class="error-state"><i class="fa-solid fa-triangle-exclamation"></i><p>Failed to load. Please try again.</p></div>';
    });

  // Controls
  document.getElementById('seasonTypeFilter').addEventListener('click', e => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    document.querySelectorAll('#seasonTypeFilter .chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    applyFilters();
  });
  document.getElementById('seasonSort').addEventListener('change', applyFilters);
  document.querySelectorAll('.view-btn').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.view-btn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    applyFilters();
  }));
});

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
