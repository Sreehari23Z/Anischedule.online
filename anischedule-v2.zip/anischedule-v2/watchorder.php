﻿<?php
// ============================================================
//  Watch Order Guides — /watchorder.php
//  Curated franchise watch orders
// ============================================================
require_once __DIR__ . '/config.php';
$page_title = 'Anime Watch Order Guides — ' . SITE_NAME;
$page_desc  = 'Curated watch order guides for popular anime franchises: Fate, Monogatari, Gundam, JoJo, and more.';
$active_nav = 'watchorder';

// ── Data ────────────────────────────────────────────────────
$franchises = [
  'Fate' => [
    'color' => '#c084fc',
    'icon'  => '⚔️',
    'desc'  => "The Holy Grail War saga — Servants, Masters, and ancient legends collide.",
    'entries' => [
      ['title' => 'Fate/Zero',                                    'type' => 'TV',      'year' => 2011, 'eps' => 13, 'synopsis' => "The brutal Fourth Holy Grail War, years before the main story.",            'mal_id' => 10087],
      ['title' => 'Fate/Zero Season 2',                          'type' => 'TV',      'year' => 2012, 'eps' => 12, 'synopsis' => "Conclusion of the Fourth Grail War.",                                       'mal_id' => 11741],
      ['title' => 'Fate/stay night (2006)',                       'type' => 'TV',      'year' => 2006, 'eps' => 24, 'synopsis' => "The original adaptation following Shiro Emiya.",                           'mal_id' => 356],
      ['title' => 'Fate/stay night: Unlimited Blade Works (TV)',  'type' => 'TV',      'year' => 2014, 'eps' => 13, 'synopsis' => "Rin Tosaka's route — superior adaptation of UBW.",                        'mal_id' => 22297],
      ['title' => "Fate/stay night: Heaven's Feel I",             'type' => 'Movie',   'year' => 2017, 'eps' => 1,  'synopsis' => "First film of the darkest route.",                                        'mal_id' => 33050],
      ['title' => "Fate/stay night: Heaven's Feel II",            'type' => 'Movie',   'year' => 2019, 'eps' => 1,  'synopsis' => "The darkest chapter of the Grail War.",                                   'mal_id' => 35790],
      ['title' => "Fate/stay night: Heaven's Feel III",           'type' => 'Movie',   'year' => 2020, 'eps' => 1,  'synopsis' => "Conclusion of the Heaven's Feel arc.",                                    'mal_id' => 33054],
      ['title' => 'Fate/Grand Order: First Order',                'type' => 'Special', 'year' => 2016, 'eps' => 1,  'synopsis' => "Introduction to the FGO timeline.",                                       'mal_id' => 33510],
    ],
  ],
  'Monogatari' => [
    'color' => '#f472b6',
    'icon'  => '📚',
    'desc'  => "Supernatural oddities, wordplay, and emotional depth in Shaft's unique visual style.",
    'entries' => [
      ['title' => 'Bakemonogatari',                  'type' => 'TV',   'year' => 2009, 'eps' => 15, 'synopsis' => "Koyomi Araragi encounters girls afflicted by oddities.",                       'mal_id' => 5081],
      ['title' => 'Nisemonogatari',                  'type' => 'TV',   'year' => 2012, 'eps' => 11, 'synopsis' => "Araragi's sisters face their own oddities.",                                    'mal_id' => 11597],
      ['title' => 'Nekomonogatari: Kuro',            'type' => 'TV',   'year' => 2012, 'eps' => 4,  'synopsis' => "Tsubasa Hanekawa's cat oddity backstory.",                                     'mal_id' => 15689],
      ['title' => 'Monogatari Series: Second Season','type' => 'TV',   'year' => 2013, 'eps' => 26, 'synopsis' => "Multiple arcs focusing on each heroine's story.",                             'mal_id' => 17074],
      ['title' => 'Hanamonogatari',                  'type' => 'TV',   'year' => 2014, 'eps' => 5,  'synopsis' => "Suruga Kanbaru after graduating.",                                             'mal_id' => 22319],
      ['title' => 'Tsukimonogatari',                 'type' => 'TV',   'year' => 2014, 'eps' => 4,  'synopsis' => "Araragi confronts his growing vampiric nature.",                               'mal_id' => 28701],
      ['title' => 'Owarimonogatari',                 'type' => 'TV',   'year' => 2015, 'eps' => 13, 'synopsis' => "The final arc begins — Araragi's first encounter with oddities.",              'mal_id' => 32287],
      ['title' => 'Kizumonogatari I-III',            'type' => 'Movie','year' => 2016, 'eps' => 3,  'synopsis' => "How Araragi became a half-vampire.",                                          'mal_id' => 9260],
      ['title' => 'Owarimonogatari Season 2',        'type' => 'TV',   'year' => 2017, 'eps' => 7,  'synopsis' => "The finale of Araragi's story.",                                               'mal_id' => 35247],
      ['title' => 'Zoku Owarimonogatari',            'type' => 'TV',   'year' => 2018, 'eps' => 6,  'synopsis' => "Epilogue — Araragi's return from the underworld.",                            'mal_id' => 36999],
    ],
  ],
  'Gundam' => [
    'color' => '#60a5fa',
    'icon'  => '🤖',
    'desc'  => "The iconic mecha franchise. Start with the Universal Century before branching out.",
    'entries' => [
      ['title' => 'Mobile Suit Gundam (0079)',                   'type' => 'TV',    'year' => 1979, 'eps' => 43, 'synopsis' => "The original — the White Base crew during the One Year War.",             'mal_id' => 80],
      ['title' => 'Mobile Suit Zeta Gundam',                    'type' => 'TV',    'year' => 1985, 'eps' => 50, 'synopsis' => "Sequel set 7 years later with darker themes.",                             'mal_id' => 85],
      ['title' => 'Mobile Suit Gundam ZZ',                      'type' => 'TV',    'year' => 1986, 'eps' => 47, 'synopsis' => "Continues from Zeta — lighter tone initially.",                            'mal_id' => 86],
      ['title' => "Mobile Suit Gundam: Char's Counterattack",   'type' => 'Movie', 'year' => 1988, 'eps' => 1,  'synopsis' => "The final confrontation between Amuro and Char.",                         'mal_id' => 82],
      ['title' => 'Mobile Suit Gundam 0080: War in the Pocket', 'type' => 'OVA',   'year' => 1989, 'eps' => 6,  'synopsis' => "A boy's perspective of the One Year War.",                               'mal_id' => 87],
      ['title' => 'Mobile Suit Gundam: The 08th MS Team',       'type' => 'OVA',   'year' => 1996, 'eps' => 12, 'synopsis' => "Ground-level warfare in Southeast Asia.",                                 'mal_id' => 92],
      ['title' => 'Gundam Wing',                                'type' => 'TV',    'year' => 1995, 'eps' => 49, 'synopsis' => "Alternate Universe — five Gundam pilots fight OZ.",                      'mal_id' => 77],
      ['title' => 'Mobile Suit Gundam SEED',                    'type' => 'TV',    'year' => 2002, 'eps' => 50, 'synopsis' => "ZAFT vs EA — another great entry point.",                                'mal_id' => 80],
      ['title' => 'Mobile Suit Gundam: Iron-Blooded Orphans',   'type' => 'TV',    'year' => 2015, 'eps' => 25, 'synopsis' => "Child soldiers reclaim their humanity — standalone, modern.",             'mal_id' => 31592],
    ],
  ],
  'Dragon Ball' => [
    'color' => '#fbbf24',
    'icon'  => '🐉',
    'desc'  => "Goku's journey from child martial artist to universe-defending warrior.",
    'entries' => [
      ['title' => 'Dragon Ball',                               'type' => 'TV',      'year' => 1986, 'eps' => 153, 'synopsis' => "Young Goku collects Dragon Balls, trains under Master Roshi.",            'mal_id' => 223],
      ['title' => 'Dragon Ball Z',                             'type' => 'TV',      'year' => 1989, 'eps' => 291, 'synopsis' => "Saiyans, Namek, Androids, Cell, Majin Buu — the classic saga.",          'mal_id' => 813],
      ['title' => 'Dragon Ball Z: Bardock - The Father of Goku','type' => 'Special','year' => 1990, 'eps' => 1,   'synopsis' => "Goku's father's final stand against Frieza.",                           'mal_id' => 2903],
      ['title' => 'Dragon Ball GT',                            'type' => 'TV',      'year' => 1996, 'eps' => 64,  'synopsis' => "Non-canonical sequel — Goku turned child again.",                        'mal_id' => 878],
      ['title' => 'Dragon Ball Super',                         'type' => 'TV',      'year' => 2015, 'eps' => 131, 'synopsis' => "After the defeat of Majin Buu — Gods of Destruction appear.",            'mal_id' => 30694],
      ['title' => 'Dragon Ball Super: Broly',                  'type' => 'Movie',   'year' => 2018, 'eps' => 1,   'synopsis' => "Canonical origin of Broly — stunning animation.",                       'mal_id' => 37779],
      ['title' => 'Dragon Ball Super: Super Hero',             'type' => 'Movie',   'year' => 2022, 'eps' => 1,   'synopsis' => "Gohan and Piccolo face the Red Ribbon Army.",                           'mal_id' => 41074],
    ],
  ],
  "JoJo's Bizarre Adventure" => [
    'color' => '#34d399',
    'icon'  => '✨',
    'desc'  => "The Joestar bloodline's generations-spanning battle against supernatural evil.",
    'entries' => [
      ['title' => "JoJo's Bizarre Adventure (2012) — Phantom Blood", 'type' => 'TV', 'year' => 2012, 'eps' => 9,  'synopsis' => "Jonathan Joestar vs the vampire Dio Brando in Victorian England.",    'mal_id' => 14719],
      ['title' => "JoJo's Bizarre Adventure — Battle Tendency",      'type' => 'TV', 'year' => 2012, 'eps' => 17, 'synopsis' => "Joseph Joestar battles the ancient Pillar Men.",                       'mal_id' => 14719],
      ['title' => "JoJo's Bizarre Adventure: Stardust Crusaders",    'type' => 'TV', 'year' => 2014, 'eps' => 24, 'synopsis' => "Jotaro and crew journey to Egypt to defeat DIO.",                      'mal_id' => 20899],
      ['title' => "JoJo's Bizarre Adventure: Diamond is Unbreakable",'type' => 'TV', 'year' => 2016, 'eps' => 39, 'synopsis' => "Josuke Higashikata investigates Stand users in Morioh.",               'mal_id' => 31933],
      ['title' => "JoJo's Bizarre Adventure: Golden Wind",           'type' => 'TV', 'year' => 2018, 'eps' => 39, 'synopsis' => "Giorno Giovanna joins the Italian mob to change it from within.",      'mal_id' => 37991],
      ['title' => "JoJo's Bizarre Adventure: Stone Ocean",           'type' => 'TV', 'year' => 2021, 'eps' => 38, 'synopsis' => "Jolyne Cujoh fights to escape a Florida prison.",                      'mal_id' => 48661],
    ],
  ],
  'Bleach' => [
    'color' => '#f97316',
    'icon'  => '⚡',
    'desc'  => "Soul Reaper Ichigo Kurosaki defends the living world and the Soul Society.",
    'entries' => [
      ['title' => 'Bleach (2004)',                   'type' => 'TV', 'year' => 2004, 'eps' => 366, 'synopsis' => "The complete original run — includes filler arcs.",                       'mal_id' => 269],
      ['title' => 'Bleach: Thousand-Year Blood War', 'type' => 'TV', 'year' => 2022, 'eps' => 13,  'synopsis' => "The manga's final arc, faithfully adapted at last.",                      'mal_id' => 41467],
      ['title' => 'Bleach: TYBW - The Separation',  'type' => 'TV', 'year' => 2023, 'eps' => 13,  'synopsis' => "Part 2 of the Quincy war.",                                               'mal_id' => 52299],
      ['title' => 'Bleach: TYBW - The Conflict',    'type' => 'TV', 'year' => 2023, 'eps' => 13,  'synopsis' => "Part 3 — battles escalate.",                                             'mal_id' => 55791],
    ],
  ],
  'Naruto' => [
    'color' => '#fb923c',
    'icon'  => '🍥',
    'desc'  => "A young ninja's dream to become Hokage and protect his village.",
    'entries' => [
      ['title' => 'Naruto',                          'type' => 'TV',    'year' => 2002, 'eps' => 220, 'synopsis' => "Young Naruto's early ninja career — part 1 of the saga.",                   'mal_id' => 20],
      ['title' => 'Naruto: Shippuden',               'type' => 'TV',    'year' => 2007, 'eps' => 500, 'synopsis' => "Naruto returns 2.5 years later, stronger, to rescue Sasuke.",               'mal_id' => 1735],
      ['title' => 'The Last: Naruto the Movie',      'type' => 'Movie', 'year' => 2014, 'eps' => 1,   'synopsis' => "Canon film set after the war — Naruto and Hinata's love story.",            'mal_id' => 23311],
      ['title' => 'Boruto: Naruto the Movie',        'type' => 'Movie', 'year' => 2015, 'eps' => 1,   'synopsis' => "Naruto's son steals the spotlight at the Chunin Exams.",                   'mal_id' => 28855],
      ['title' => 'Boruto: Naruto Next Generations', 'type' => 'TV',    'year' => 2017, 'eps' => 293, 'synopsis' => "The next generation of ninja — Boruto's story.",                           'mal_id' => 34566],
    ],
  ],
];

include __DIR__ . '/includes/header.php';
?>

<div class="page-watchorder">

  <!-- ── Hero ───────────────────────────────────────────── -->
  <section class="upcoming-hero">
    <div class="upcoming-hero-inner">
      <h1 class="hero-title">Watch Order <span class="gradient-text">Guides</span></h1>
      <p class="hero-sub">The definitive guide to watching popular anime franchises in the right order.</p>
    </div>
  </section>

  <!-- ── Search/Filter ──────────────────────────────────── -->
  <div class="container" style="padding-top:1.5rem">
    <div class="wo-search-bar">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" id="woSearch" placeholder="Filter franchises…" autocomplete="off">
    </div>
  </div>

  <!-- ── Franchise list ─────────────────────────────────── -->
  <div class="container" style="padding-top:1.5rem;padding-bottom:3rem">
    <?php foreach ($franchises as $name => $franchise): ?>
    <div class="wo-franchise" data-name="<?= htmlspecialchars(strtolower($name)) ?>">
      <div class="wo-franchise-header" style="--wo-color:<?= $franchise['color'] ?>">
        <span class="wo-icon"><?= $franchise['icon'] ?></span>
        <div class="wo-franchise-title">
          <h2><?= htmlspecialchars($name) ?></h2>
          <p><?= htmlspecialchars($franchise['desc']) ?></p>
        </div>
        <button class="wo-toggle btn btn-ghost btn-sm" aria-expanded="true">
          <i class="fa-solid fa-chevron-up"></i>
        </button>
      </div>
      <div class="wo-entries">
        <?php foreach ($franchise['entries'] as $idx => $entry): ?>
        <div class="watch-order-card">
          <div class="wo-num"><?= $idx + 1 ?></div>
          <div class="wo-entry-info">
            <div class="wo-entry-title">
              <a href="https://myanimelist.net/anime/<?= $entry['mal_id'] ?>" target="_blank" rel="noopener">
                <?= htmlspecialchars($entry['title']) ?>
                <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.65rem;margin-left:.3rem"></i>
              </a>
            </div>
            <div class="wo-entry-meta">
              <span class="badge badge-type"><?= htmlspecialchars($entry['type']) ?></span>
              <span class="card-ep"><?= $entry['year'] ?></span>
              <?php if (!empty($entry['eps']) && $entry['type'] !== 'Movie'): ?>
              <span class="card-ep"><?= $entry['eps'] ?> eps</span>
              <?php endif; ?>
            </div>
            <p class="wo-entry-synopsis"><?= htmlspecialchars($entry['synopsis']) ?></p>
          </div>
          <a href="<?= $base ?>/anime.php?id=<?= $entry['mal_id'] ?>" class="btn btn-ghost btn-sm wo-detail-btn">
            Details
          </a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <div id="woNoResults" class="empty-state" style="display:none">
      <i class="fa-solid fa-magnifying-glass"></i>
      <p>No franchises match your search.</p>
    </div>
  </div>

</div>

<script>
(function(){
  const input      = document.getElementById('woSearch');
  const franchises = document.querySelectorAll('.wo-franchise');
  const noResults  = document.getElementById('woNoResults');

  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    let visible = 0;
    franchises.forEach(f => {
      const match = !q || f.dataset.name.includes(q);
      f.style.display = match ? '' : 'none';
      if (match) visible++;
    });
    noResults.style.display = visible === 0 ? 'flex' : 'none';
  });

  // Toggle collapse
  document.querySelectorAll('.wo-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const card    = btn.closest('.wo-franchise');
      const entries = card.querySelector('.wo-entries');
      const icon    = btn.querySelector('i');
      const open    = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', !open);
      entries.style.display = open ? 'none' : '';
      icon.className = open ? 'fa-solid fa-chevron-down' : 'fa-solid fa-chevron-up';
    });
  });
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
