<?php
// ============================================================
//  Characters Browser — /characters.php
// ============================================================
require_once __DIR__ . '/config.php';
$page_title = SITE_NAME . ' — Anime Character Database';
$page_desc  = 'Browse thousands of anime characters. Search profiles, voice actors, appearances, and birthday rankings.';
$active_nav = 'character';
include __DIR__ . '/includes/header.php';
?>

<div class="page-characters">

  <!-- ── Hero ─────────────────────────────────────────────── -->
  <section class="char-hero">
    <div class="char-hero-inner">
      <h1 class="hero-title">Anime <span class="gradient-text">Characters</span></h1>
      <p class="hero-sub">Explore profiles, voice actors, and stats for your favourite characters.</p>

      <!-- Search -->
      <div class="char-search-wrap">
        <div class="char-search-box">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" id="charSearchInput" placeholder="Search characters…" autocomplete="off" spellcheck="false">
          <button id="charSearchClear" class="char-search-clear" aria-label="Clear" style="display:none">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      </div>

      <!-- Stats strip -->
      <div class="char-stats-strip">
        <div class="char-stat"><span class="char-stat-num">10K+</span><span class="char-stat-lbl">Characters</span></div>
        <div class="char-stat-sep"></div>
        <div class="char-stat"><span class="char-stat-num">500+</span><span class="char-stat-lbl">Anime Series</span></div>
        <div class="char-stat-sep"></div>
        <div class="char-stat"><span class="char-stat-num">2K+</span><span class="char-stat-lbl">Voice Actors</span></div>
      </div>
    </div>
  </section>

  <!-- ── Quick links bar ───────────────────────────────────── -->
  <div class="char-quick-bar">
    <div class="container">
      <div class="char-quick-inner">
        <a href="<?= $base ?>/birthdays.php" class="char-quick-link">
          <i class="fa-solid fa-cake-candles"></i> Today's Birthdays
        </a>
        <a href="<?= $base ?>/birthdays.php?view=calendar" class="char-quick-link">
          <i class="fa-solid fa-calendar-days"></i> Birthday Calendar
        </a>
        <a href="<?= $base ?>/characters.php?sort=favorites" class="char-quick-link active">
          <i class="fa-solid fa-heart"></i> Most Popular
        </a>
        <a href="<?= $base ?>/characters.php?sort=rank" class="char-quick-link">
          <i class="fa-solid fa-trophy"></i> Top Ranked
        </a>
      </div>
    </div>
  </div>

  <!-- ── Characters Grid ──────────────────────────────────── -->
  <div class="container">
    <div class="char-toolbar">
      <h2 class="char-section-title" id="charSectionTitle">
        <i class="fa-solid fa-star"></i> Top Characters
      </h2>
      <div class="char-toolbar-right">
        <span class="char-result-count" id="charResultCount"></span>
      </div>
    </div>

    <div id="charGrid" class="char-grid">
      <!-- JS rendered -->
      <?php for ($i=0; $i<24; $i++): ?>
        <div class="char-card char-card-skeleton"></div>
      <?php endfor; ?>
    </div>

    <!-- Pagination -->
    <div class="char-pagination" id="charPagination"></div>
  </div>

</div>

<script src="<?= $base . asset_ver('assets/js/characters.js') ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  CharacterBrowser.init({
    apiBase: '<?= $base ?>/api/character.php',
    detailBase: '<?= $base ?>/character.php',
  });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
