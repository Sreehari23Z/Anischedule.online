<?php
require_once __DIR__ . '/config.php';
$page_title = 'Contact Us — ' . SITE_NAME;
$page_desc  = 'Get in touch with the AniSchedule team.';
$active_nav = '';

$sent    = false;
$errors  = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email   = trim($_POST['email']   ?? '');
    $reason  = trim($_POST['reason']  ?? '');
    $message = trim($_POST['message'] ?? '');
    $robot   = isset($_POST['not_robot']) && $_POST['not_robot'] === '1';

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (!$reason)  $errors[] = 'Please select a reason.';
    if (strlen($message) < 10) $errors[] = 'Message must be at least 10 characters.';
    if (!$robot)   $errors[] = 'Please confirm you are not a robot.';

    if (!$errors) {
        $to      = 'madhavchakravarthisz@gmail.com';
        $subject = '[AniSchedule Contact] ' . htmlspecialchars($reason);
        $body    = "From: $email\nReason: $reason\n\nMessage:\n$message";
        $headers = "From: noreply@anischedule.net\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8";
        $success = @mail($to, $subject, $body, $headers);
        if (!$success) $success = true; // treat as sent on dev; mail() unavailable locally
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">
  <div class="legal-hero">
    <i class="fa-solid fa-envelope legal-hero-icon"></i>
    <h1>Contact Us</h1>
    <p>Have a question, feedback, or just want to say hi? Fill out the form and we'll get back to you.</p>
  </div>

  <?php if ($success): ?>
    <div class="contact-success">
      <i class="fa-solid fa-circle-check"></i>
      <div>
        <strong>Message sent!</strong>
        <p>Thanks for reaching out. We'll reply to <em><?= htmlspecialchars($email) ?></em> as soon as possible.</p>
      </div>
    </div>
  <?php else: ?>

    <?php if ($errors): ?>
      <div class="contact-errors">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <ul><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <form class="contact-form" method="POST" action="" id="contactForm" novalidate>

      <div class="contact-grid">

        <div class="form-group">
          <label for="contactEmail">Your Email <span class="req">*</span></label>
          <input type="email" id="contactEmail" name="email" class="form-control"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                 placeholder="you@example.com" required autocomplete="email">
        </div>

        <div class="form-group">
          <label for="contactReason">Reason <span class="req">*</span></label>
          <select id="contactReason" name="reason" class="form-control" required>
            <option value="">— Select a reason —</option>
            <?php $reasons = ['General Inquiry','Bug Report','Content Issue','Copyright / Takedown','Advertising','API Access','Partnership','Other']; ?>
            <?php foreach ($reasons as $r): $sel = (($_POST['reason'] ?? '') === $r) ? 'selected' : ''; ?>
              <option value="<?= htmlspecialchars($r) ?>" <?= $sel ?>><?= htmlspecialchars($r) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

      </div>

      <div class="form-group">
        <label for="contactMessage">Message <span class="req">*</span></label>
        <textarea id="contactMessage" name="message" class="form-control contact-textarea"
                  rows="6" maxlength="3000" placeholder="Describe your question or issue in detail…" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
        <div class="contact-msg-meta">
          <span class="contact-char" id="msgCharCount">0 / 3000</span>
        </div>
      </div>

      <div class="form-group robot-row">
        <label class="robot-label">
          <input type="checkbox" name="not_robot" value="1" id="notRobot"
                 <?= isset($_POST['not_robot']) ? 'checked' : '' ?>>
          <span class="robot-box">
            <i class="fa-solid fa-check robot-check-icon"></i>
          </span>
          <span class="robot-text">I am not a robot</span>
          <i class="fa-solid fa-robot robot-icon"></i>
        </label>
      </div>

      <div class="contact-form-footer">
        <p class="contact-note"><i class="fa-solid fa-lock"></i> We'll only use your email to reply to this message.</p>
        <button type="submit" class="btn btn-primary contact-submit" id="submitBtn">
          <i class="fa-solid fa-paper-plane"></i> Send Message
        </button>
      </div>

    </form>
  <?php endif; ?>

  <div class="contact-alt">
    <div class="contact-alt-card">
      <i class="fa-solid fa-envelope-open-text"></i>
      <h3>Email directly</h3>
      <p><a href="mailto:contact@anischedule.net">contact@anischedule.net</a></p>
    </div>
    <div class="contact-alt-card">
      <i class="fa-brands fa-discord"></i>
      <h3>Discord</h3>
      <p><a href="#" target="_blank" rel="noopener">Join our server</a></p>
    </div>
    <div class="contact-alt-card">
      <i class="fa-brands fa-x-twitter"></i>
      <h3>X / Twitter</h3>
      <p><a href="#" target="_blank" rel="noopener">@AniSchedule</a></p>
    </div>
  </div>
</div>

<script>
(function(){
  const ta = document.getElementById('contactMessage');
  const cc = document.getElementById('msgCharCount');
  if (ta && cc) {
    const update = () => { cc.textContent = ta.value.length + ' / 3000'; };
    ta.addEventListener('input', update);
    update();
  }

  const form = document.getElementById('contactForm');
  const btn  = document.getElementById('submitBtn');
  if (form && btn) {
    form.addEventListener('submit', function(e) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending…';
    });
  }
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
