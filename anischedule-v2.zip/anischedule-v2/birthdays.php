<?php
// ============================================================
//  Anime Character Birthdays — /birthdays.php
// ============================================================
require_once __DIR__ . '/config.php';

$view  = $_GET['view']  ?? 'today';   // today | calendar
$month = intval($_GET['month'] ?? date('n'));
$month = max(1, min(12, $month));

$month_names = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];
$current_month = intval(date('n'));
$current_day   = intval(date('j'));
$today_label   = date('F j, Y');

$page_title = 'Anime Character Birthdays — ' . SITE_NAME;
$page_desc  = "Today's anime character birthdays and the full birthday calendar. Find out which anime characters share your birthday!";
$active_nav = 'character';
include __DIR__ . '/includes/header.php';
?>

<div class="page-birthdays">

  <!-- ── Hero ─────────────────────────────────────────────── -->
  <section class="bday-hero">
    <div class="bday-hero-inner">
      <div class="bday-hero-icon">
        <i class="fa-solid fa-cake-candles"></i>
      </div>
      <h1 class="hero-title">Anime <span class="gradient-text">Birthdays</span></h1>
      <p class="hero-sub">Discover which anime characters celebrate their birthday today and throughout the year.</p>
      <p class="bday-date-badge"><i class="fa-solid fa-calendar-day"></i> <?= $today_label ?></p>
    </div>
  </section>

  <!-- ── View tabs ─────────────────────────────────────────── -->
  <div class="bday-view-tabs">
    <div class="container">
      <div class="bday-view-inner">
        <a href="<?= $base ?>/birthdays.php?view=today"    class="bday-view-tab <?= $view !== 'calendar' ? 'active' : '' ?>">
          <i class="fa-solid fa-star"></i> Today &amp; Upcoming
        </a>
        <a href="<?= $base ?>/birthdays.php?view=calendar" class="bday-view-tab <?= $view === 'calendar' ? 'active' : '' ?>">
          <i class="fa-solid fa-calendar-days"></i> Calendar View
        </a>
      </div>
    </div>
  </div>

  <div class="container bday-main">

    <?php if ($view === 'calendar'): ?>
    <!-- ═══════════════════════════════════════════════ CALENDAR VIEW -->

      <!-- Month selector -->
      <div class="bday-month-nav">
        <?php
        $prev_m = $month === 1 ? 12 : $month - 1;
        $next_m = $month === 12 ? 1 : $month + 1;
        ?>
        <a href="?view=calendar&month=<?= $prev_m ?>" class="bday-month-arrow">
          <i class="fa-solid fa-chevron-left"></i>
        </a>
        <h2 class="bday-month-title"><?= $month_names[$month - 1] ?></h2>
        <a href="?view=calendar&month=<?= $next_m ?>" class="bday-month-arrow">
          <i class="fa-solid fa-chevron-right"></i>
        </a>
      </div>

      <!-- Month pills: jump to any month -->
      <div class="bday-month-pills">
        <?php for ($m = 1; $m <= 12; $m++): ?>
          <a href="?view=calendar&month=<?= $m ?>"
             class="bday-month-pill <?= $m === $month ? 'active' : '' ?> <?= $m === $current_month ? 'current' : '' ?>">
            <?= substr($month_names[$m-1], 0, 3) ?>
          </a>
        <?php endfor; ?>
      </div>

      <!-- Birthday entries loaded by JS -->
      <div id="bdayCalendarGrid" class="bday-calendar-grid">
        <div class="loading-state">
          <div class="spinner"></div>
          <p>Loading birthdays…</p>
        </div>
      </div>

    <?php else: ?>
    <!-- ═══════════════════════════════════════════════ TODAY + UPCOMING -->

      <!-- Today's birthdays -->
      <section class="bday-section">
        <div class="bday-section-header">
          <h2 class="bday-section-title">
            <i class="fa-solid fa-birthday-cake"></i> Today's Birthdays
            <span class="bday-section-date"><?= date('F j') ?></span>
          </h2>
        </div>
        <div id="bdayToday" class="bday-today-grid">
          <div class="loading-state"><div class="spinner"></div></div>
        </div>
      </section>

      <!-- Upcoming birthdays -->
      <section class="bday-section" style="margin-top:2.5rem">
        <div class="bday-section-header">
          <h2 class="bday-section-title">
            <i class="fa-solid fa-forward"></i> Upcoming Birthdays
            <span class="bday-section-date">Next 30 days</span>
          </h2>
        </div>
        <div id="bdayUpcoming" class="bday-upcoming-list">
          <div class="loading-state"><div class="spinner"></div></div>
        </div>
      </section>

    <?php endif; ?>
  </div>

</div><!-- /page-birthdays -->

<script>
(function(){
  const base       = '<?= $base ?>';
  const apiBase    = base + '/api/birthdays.php';
  const detailBase = base + '/character.php';
  const view       = '<?= $view === 'calendar' ? 'calendar' : 'today' ?>';
  const month      = <?= $month ?>;

  // ── Helpers ──────────────────────────────────────────────
  function placeholderSvg(name) {
    const initials = name.split(' ').map(w => w[0]).slice(0,2).join('').toUpperCase();
    const hue = (name.charCodeAt(0) * 37) % 360;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="hsl(${hue},60%,30%)"/><text x="40" y="54" font-size="26" text-anchor="middle" fill="#fff" font-family="sans-serif">${initials}</text></svg>`;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
  }

  function charImg(c) {
    return c.id > 0
      ? `https://api.jikan.moe/v4/characters/${c.id}/images` // We'll use placeholder if no real image
      : placeholderSvg(c.name);
  }

  function charLink(c) {
    return c.id > 0 ? `${detailBase}?id=${c.id}` : '#';
  }

  function renderCharCard(c, featured=false) {
    const cls  = featured ? 'bday-char-featured' : 'bday-char-card';
    const img  = placeholderSvg(c.name); // Will be replaced by real image when available
    const link = charLink(c);
    return `
      <a href="${link}" class="${cls}" data-id="${c.id}" data-name="${c.name}">
        <div class="bday-char-img-wrap">
          <img src="${img}" alt="${c.name}" class="bday-char-img" loading="lazy"
               onerror="this.src='${placeholderSvg(c.name)}'">
          <div class="bday-char-img-overlay"></div>
        </div>
        <div class="bday-char-info">
          <span class="bday-char-name">${c.name}</span>
          <span class="bday-char-anime">${c.anime}</span>
          ${featured ? `<span class="bday-char-today-tag"><i class="fa-solid fa-cake-candles"></i> Birthday Today!</span>` : ''}
        </div>
      </a>`;
  }

  // Fetch real image for characters that have a MAL id
  function loadRealImages(container) {
    container.querySelectorAll('[data-id]').forEach(async el => {
      const id = parseInt(el.dataset.id || '0');
      if (id <= 0) return;
      try {
        const r  = await fetch(`${base}/api/character.php?id=${id}`);
        const j  = await r.json();
        if (j.ok && j.data?.images?.jpg?.image_url) {
          const img = el.querySelector('img');
          if (img) img.src = j.data.images.jpg.image_url;
        }
      } catch(e) {}
    });
  }

  // ── Today / upcoming ─────────────────────────────────────
  async function loadToday() {
    const todayEl    = document.getElementById('bdayToday');
    const upcomingEl = document.getElementById('bdayUpcoming');
    if (!todayEl) return;

    try {
      // Today
      const r1 = await fetch(`${apiBase}?today=1`);
      const j1 = await r1.json();
      if (j1.ok && j1.data?.length) {
        todayEl.innerHTML = `<div class="bday-today-cards">${j1.data.map(c => renderCharCard(c, true)).join('')}</div>`;
        loadRealImages(todayEl);
      } else {
        todayEl.innerHTML = `
          <div class="bday-empty">
            <i class="fa-solid fa-calendar-xmark"></i>
            <p>No character birthdays recorded for today — check back tomorrow!</p>
            <a href="?view=calendar" class="btn btn-outline btn-sm">View Calendar</a>
          </div>`;
      }

      // Upcoming (skip today)
      const r2 = await fetch(`${apiBase}`);
      const j2 = await r2.json();
      if (j2.ok && j2.data?.length) {
        const upcoming = j2.data.filter(d => !d.is_today);
        if (upcoming.length) {
          upcomingEl.innerHTML = upcoming.map(day => `
            <div class="bday-upcoming-day">
              <div class="bday-upcoming-date">
                <span class="bday-upcoming-date-day">${day.date}</span>
              </div>
              <div class="bday-upcoming-chars">
                ${day.characters.map(c => `
                  <a href="${charLink(c)}" class="bday-upcoming-char" data-id="${c.id}" data-name="${c.name}">
                    <img src="${placeholderSvg(c.name)}" alt="${c.name}" class="bday-upcoming-img" loading="lazy">
                    <div class="bday-upcoming-info">
                      <span class="bday-upcoming-name">${c.name}</span>
                      <span class="bday-upcoming-anime">${c.anime}</span>
                    </div>
                  </a>`).join('')}
              </div>
            </div>`).join('');
          loadRealImages(upcomingEl);
        } else {
          upcomingEl.innerHTML = '<p style="color:var(--text3)">No upcoming birthdays in the next 30 days.</p>';
        }
      }
    } catch(e) {
      todayEl.innerHTML = '<p style="color:var(--danger)">Failed to load birthday data.</p>';
    }
  }

  // ── Calendar ──────────────────────────────────────────────
  async function loadCalendar() {
    const grid = document.getElementById('bdayCalendarGrid');
    if (!grid) return;

    try {
      const r = await fetch(`${apiBase}?month=${month}`);
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'API error');

      const byDay = j.data; // {day: [chars...]}
      const keys  = Object.keys(byDay).map(Number).sort((a,b)=>a-b);

      if (!keys.length) {
        grid.innerHTML = '<p style="color:var(--text3);text-align:center;padding:2rem">No birthday data for this month yet.</p>';
        return;
      }

      grid.innerHTML = keys.map(day => {
        const chars = byDay[day];
        const dt    = new Date(new Date().getFullYear(), month-1, day);
        const label = dt.toLocaleDateString('en-US', {month:'long', day:'numeric'});
        const isToday = month === <?= $current_month ?> && day === <?= $current_day ?>;
        return `
          <div class="bday-cal-row ${isToday ? 'bday-cal-today' : ''}">
            <div class="bday-cal-date">
              <span class="bday-cal-day-num">${day}</span>
              <span class="bday-cal-month-abbr">${label.split(' ')[0].slice(0,3)}</span>
              ${isToday ? '<span class="bday-cal-today-tag">TODAY</span>' : ''}
            </div>
            <div class="bday-cal-chars">
              ${chars.map(c => `
                <a href="${charLink(c)}" class="bday-cal-char" data-id="${c.id}" data-name="${c.name}">
                  <img src="${placeholderSvg(c.name)}" alt="${c.name}" class="bday-cal-char-img" loading="lazy">
                  <div class="bday-cal-char-info">
                    <span class="bday-cal-char-name">${c.name}</span>
                    <span class="bday-cal-char-anime">${c.anime}</span>
                  </div>
                </a>`).join('')}
            </div>
          </div>`;
      }).join('');

      loadRealImages(grid);
    } catch(e) {
      grid.innerHTML = `<p style="color:var(--danger)">Failed to load calendar: ${e.message}</p>`;
    }
  }

  // ── Init ─────────────────────────────────────────────────
  if (view === 'calendar') {
    loadCalendar();
  } else {
    loadToday();
  }
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
