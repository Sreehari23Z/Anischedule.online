<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
$user = auth_user();
if (!$user) { header('Location: /login.php'); exit; }
$tab = $_GET['tab'] ?? 'watching';
$page_title = $user['username'] . "'s Watchlist — " . SITE_NAME;
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>
<div class="page-profile container">
  <div class="profile-header">
    <div class="profile-avatar">
      <?php if ($user['avatar']): ?>
        <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="Avatar">
      <?php else: ?>
        <div class="avatar-placeholder"><?= strtoupper($user['username'][0]) ?></div>
      <?php endif; ?>
    </div>
    <div class="profile-info">
      <h1><?= htmlspecialchars($user['username']) ?></h1>
      <p><?= htmlspecialchars($user['email']) ?></p>
    </div>
  </div>

  <!-- Watchlist tabs -->
  <div class="watchlist-tabs">
    <?php foreach (['watching'=>'Watching','plan_to_watch'=>'Plan to Watch','completed'=>'Completed','on_hold'=>'On Hold','dropped'=>'Dropped'] as $k=>$label): ?>
      <button class="wl-tab <?= $tab===$k?'active':'' ?>" data-status="<?= $k ?>"><?= $label ?></button>
    <?php endforeach; ?>
    <button class="wl-tab" data-status="settings">⚙ Settings</button>
  </div>

  <!-- Watchlist content -->
  <div id="watchlistContent">
    <div class="loading-state"><div class="spinner"></div><p>Loading…</p></div>
  </div>

  <!-- Settings panel (hidden initially) -->
  <div id="settingsPanel" class="settings-panel" style="display:none">
    <h2>Settings</h2>
    <form id="settingsForm" class="settings-form">
      <div class="form-group">
        <label for="tzSelect">Timezone</label>
        <select id="tzSelect" name="timezone" class="form-control"></select>
      </div>
      <div class="form-group">
        <label>Theme</label>
        <div class="theme-options">
          <label class="radio-label">
            <input type="radio" name="theme" value="dark" <?= $user['theme']==='dark'?'checked':'' ?>> Dark
          </label>
          <label class="radio-label">
            <input type="radio" name="theme" value="light" <?= $user['theme']==='light'?'checked':'' ?>> Light
          </label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div>
</div>

<script>
(function(){
  const content = document.getElementById('watchlistContent');
  const settings = document.getElementById('settingsPanel');
  let currentStatus = '<?= $tab ?>';

  // Populate timezone select
  const tzSelect = document.getElementById('tzSelect');
  const timezones = Intl.supportedValuesOf ? Intl.supportedValuesOf('timeZone') : [];
  timezones.forEach(tz => {
    const opt = document.createElement('option');
    opt.value = tz; opt.textContent = tz;
    if (tz === '<?= htmlspecialchars($user['timezone']) ?>') opt.selected = true;
    tzSelect.appendChild(opt);
  });

  function loadList(status) {
    if (status === 'settings') {
      content.style.display = 'none';
      settings.style.display = 'block';
      return;
    }
    content.style.display = 'block';
    settings.style.display = 'none';
    content.innerHTML = '<div class="loading-state"><div class="spinner"></div><p>Loading…</p></div>';

    fetch(`${window.SITE.base}/api/watchlist.php?status=${status}`)
      .then(r => r.json())
      .then(d => {
        if (!d.list.length) {
          content.innerHTML = '<div class="empty-state"><i class="fa-solid fa-list-check"></i><p>Nothing here yet.</p></div>';
          return;
        }
        content.innerHTML = `<div class="wl-grid">${d.list.map(a => `
          <div class="wl-card" data-id="${a.anime_id}">
            <img src="${a.anime_cover||''}" alt="${escHtml(a.anime_title)}" class="wl-cover">
            <div class="wl-info">
              <h4><a href="/anime.php?id=${a.anime_id}">${escHtml(a.anime_title)}</a></h4>
              <span class="badge badge-type">${a.anime_format||''}</span>
              <div class="wl-progress">Ep ${a.progress||0}</div>
              ${a.score ? `<div class="wl-score">★ ${a.score}</div>` : ''}
            </div>
            <button class="wl-remove-btn" data-id="${a.anime_id}" title="Remove">✕</button>
          </div>
        `).join('')}</div>`;

        content.querySelectorAll('.wl-remove-btn').forEach(btn => {
          btn.addEventListener('click', async () => {
            if (!confirm('Remove from watchlist?')) return;
            await fetch((window.SITE.base||'') + '/api/watchlist.php', {
              method: 'DELETE',
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ anime_id: parseInt(btn.dataset.id), csrf: window.SITE.csrf })
            });
            loadList(currentStatus);
          });
        });
      });
  }

  document.querySelectorAll('.wl-tab').forEach(t => {
    t.addEventListener('click', () => {
      document.querySelectorAll('.wl-tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      currentStatus = t.dataset.status;
      loadList(currentStatus);
    });
  });

  document.getElementById('settingsForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const res = await fetch((window.SITE.base||'') + '/api/auth.php', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ action:'update_settings', timezone: fd.get('timezone'), theme: fd.get('theme'), csrf: window.SITE.csrf })
    });
    const json = await res.json();
    if (json.ok) { window.App.toast('Settings saved!','success'); document.documentElement.dataset.theme = fd.get('theme'); }
  });

  loadList(currentStatus);

  function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
