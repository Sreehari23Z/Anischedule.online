/**
 * notify.js — 3-step notification subscription modal
 * Hooks into .notif-btn elements on anime cards.
 * Steps: 1) Channel choice (Email/WhatsApp)  2) Contact input  3) Confirmation
 */
(function () {
  'use strict';

  const base = window.SITE?.base ?? '';
  const csrf = window.SITE?.csrf ?? document.querySelector('meta[name="csrf-token"]')?.content ?? '';

  // ── Modal HTML ──────────────────────────────────────────────────────────────
  const MODAL_ID = 'notifyModal';

  function ensureModal() {
    if (document.getElementById(MODAL_ID)) return;
    const el = document.createElement('div');
    el.id = MODAL_ID;
    el.className = 'notify-modal';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    el.setAttribute('aria-labelledby', 'notifyModalTitle');
    el.innerHTML = `
      <div class="notify-modal-overlay" id="notifyModalOverlay"></div>
      <div class="notify-modal-box">
        <div class="notify-modal-header">
          <h3 id="notifyModalTitle">🔔 Get Notified</h3>
          <button class="notify-modal-close" id="notifyModalClose" aria-label="Close">&times;</button>
        </div>
        <div class="notify-progress" id="notifyProgress">
          <span class="notify-step-dot active" data-step="1"></span>
          <span class="notify-step-dot" data-step="2"></span>
          <span class="notify-step-dot" data-step="3"></span>
        </div>
        <div class="notify-modal-body" id="notifyModalBody"></div>
      </div>`;
    document.body.appendChild(el);

    // Close handlers
    document.getElementById('notifyModalClose').addEventListener('click', closeModal);
    document.getElementById('notifyModalOverlay').addEventListener('click', closeModal);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
  }

  // ── State ───────────────────────────────────────────────────────────────────
  let currentAnime = { id: 0, title: '', cover: '' };
  let selectedType = '';

  // ── Open / Close ────────────────────────────────────────────────────────────
  function openModal(animeId, animeTitle, animeCover) {
    ensureModal();
    currentAnime = { id: animeId, title: animeTitle, cover: animeCover };
    selectedType = '';
    showStep(1);
    document.getElementById(MODAL_ID).classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    const modal = document.getElementById(MODAL_ID);
    if (modal) modal.classList.remove('open');
    document.body.style.overflow = '';
  }

  // ── Step rendering ──────────────────────────────────────────────────────────
  function setProgress(step) {
    document.querySelectorAll('.notify-step-dot').forEach(dot => {
      const n = parseInt(dot.dataset.step);
      dot.classList.toggle('active', n <= step);
      dot.classList.toggle('done', n < step);
    });
  }

  function showStep(step) {
    setProgress(step);
    const body = document.getElementById('notifyModalBody');
    if (step === 1) {
      body.innerHTML = `
        <div class="notify-anime-preview">
          ${currentAnime.cover ? `<img src="${escHtml(currentAnime.cover)}" alt="${escHtml(currentAnime.title)}" class="notify-anime-cover">` : ''}
          <p class="notify-anime-title">${escHtml(currentAnime.title)}</p>
        </div>
        <p class="notify-label">How would you like to be notified?</p>
        <div class="notify-channel-buttons">
          <button class="notify-channel-btn" id="notifyChooseEmail">
            <span class="notify-channel-icon">✉️</span>
            <span class="notify-channel-name">Email</span>
            <span class="notify-channel-desc">Get an email when the episode airs</span>
          </button>
          <button class="notify-channel-btn" id="notifyChooseWA">
            <span class="notify-channel-icon">💬</span>
            <span class="notify-channel-name">WhatsApp</span>
            <span class="notify-channel-desc">Get a WhatsApp message</span>
          </button>
        </div>`;
      document.getElementById('notifyChooseEmail').addEventListener('click', () => {
        selectedType = 'email';
        showStep(2);
      });
      document.getElementById('notifyChooseWA').addEventListener('click', () => {
        selectedType = 'whatsapp';
        showStep(2);
      });

    } else if (step === 2) {
      const isEmail = selectedType === 'email';
      body.innerHTML = `
        <p class="notify-label">
          ${isEmail ? 'Enter your email address:' : 'Enter your WhatsApp number (with country code):'}
        </p>
        <div class="notify-input-group">
          <input
            type="${isEmail ? 'email' : 'tel'}"
            id="notifyContactInput"
            class="notify-input"
            placeholder="${isEmail ? 'you@example.com' : '+12345678900'}"
            autocomplete="${isEmail ? 'email' : 'tel'}"
            autofocus>
        </div>
        <div class="notify-error" id="notifyError" style="display:none"></div>
        <div class="notify-step-actions">
          <button class="btn btn-ghost btn-sm" id="notifyBack">← Back</button>
          <button class="btn btn-primary" id="notifySubmit">
            <i class="fa-solid fa-bell"></i> Notify Me
          </button>
        </div>`;
      document.getElementById('notifyBack').addEventListener('click', () => showStep(1));
      document.getElementById('notifyContactInput').addEventListener('keydown', e => {
        if (e.key === 'Enter') document.getElementById('notifySubmit').click();
      });
      document.getElementById('notifySubmit').addEventListener('click', submitSubscription);

    } else if (step === 3) {
      body.innerHTML = `
        <div class="notify-success">
          <div class="notify-success-icon">🎉</div>
          <h4>You're all set!</h4>
          <p>You'll be notified when <strong>${escHtml(currentAnime.title)}</strong> airs its next episode.</p>
          <button class="btn btn-primary" id="notifyDone" style="margin-top:1.25rem">Done</button>
        </div>`;
      document.getElementById('notifyDone').addEventListener('click', closeModal);
    }
  }

  // ── Submit ──────────────────────────────────────────────────────────────────
  function submitSubscription() {
    const input   = document.getElementById('notifyContactInput');
    const errEl   = document.getElementById('notifyError');
    const btn     = document.getElementById('notifySubmit');
    const value   = input ? input.value.trim() : '';

    errEl.style.display = 'none';

    // Client-side validation
    if (!value) {
      showError(errEl, 'Please enter a valid ' + (selectedType === 'email' ? 'email address' : 'phone number') + '.');
      return;
    }
    if (selectedType === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      showError(errEl, 'Please enter a valid email address.');
      return;
    }
    if (selectedType === 'whatsapp' && !/^\+[1-9]\d{6,14}$/.test(value)) {
      showError(errEl, 'Please enter a valid phone number starting with + and country code (e.g. +12345678900).');
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending…';

    fetch(base + '/api/subscribe.php', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'X-CSRF-Token':  csrf,
      },
      body: JSON.stringify({
        anime_id:      currentAnime.id,
        anime_title:   currentAnime.title,
        anime_cover:   currentAnime.cover,
        contact_type:  selectedType,
        contact_value: value,
        csrf:          csrf,
      }),
    })
      .then(r => r.json())
      .then(json => {
        if (json.ok) {
          showStep(3);
        } else {
          showError(errEl, json.error || 'Subscription failed. Please try again.');
          btn.disabled = false;
          btn.innerHTML = '<i class="fa-solid fa-bell"></i> Notify Me';
        }
      })
      .catch(() => {
        showError(errEl, 'Network error. Please check your connection and try again.');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-bell"></i> Notify Me';
      });
  }

  function showError(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
  }

  // ── Hook into .notif-btn buttons (delegation) ──────────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.notif-btn');
    if (!btn) return;
    e.preventDefault();
    const id    = parseInt(btn.dataset.id    ?? btn.closest('[data-id]')?.dataset.id    ?? 0);
    const title = btn.dataset.title ?? btn.closest('[data-title]')?.dataset.title ?? '';
    const cover = btn.dataset.cover ?? btn.closest('[data-cover]')?.dataset.cover ?? '';
    if (id) openModal(id, title, cover);
  });

  // ── Utility ─────────────────────────────────────────────────────────────────
  function escHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Expose globally so schedule.js etc. can call openModal if needed
  window.NotifyModal = { open: openModal, close: closeModal };
})();
