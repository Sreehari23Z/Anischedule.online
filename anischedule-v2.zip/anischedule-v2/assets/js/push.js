// ============================================================
//  AniSchedule — Web Push Notifications
//  Uses the Web Push API with VAPID keys
// ============================================================
window.Push = (function() {
  'use strict';

  let subscription = null;
  let notifiedAnime = new Set(JSON.parse(localStorage.getItem('notif_anime') || '[]'));

  // ── Init: request permission button ─────────────────────
  const notifBtn = document.getElementById('notifBtn');

  function updateBtnState() {
    if (!notifBtn) return;
    const perm = Notification.permission;
    if (perm === 'granted') {
      notifBtn.innerHTML = '<i class="fa-solid fa-bell" style="color:var(--accent2)"></i>';
      notifBtn.title = 'Notifications enabled';
    } else if (perm === 'denied') {
      notifBtn.innerHTML = '<i class="fa-solid fa-bell-slash"></i>';
      notifBtn.title = 'Notifications blocked — check browser settings';
    } else {
      notifBtn.innerHTML = '<i class="fa-solid fa-bell"></i>';
      notifBtn.title = 'Enable notifications';
    }
  }

  updateBtnState();

  notifBtn?.addEventListener('click', async () => {
    if (Notification.permission === 'denied') {
      window.App?.toast('Notifications are blocked. Please allow them in browser settings.', 'error');
      return;
    }
    await requestPermissionAndSubscribe();
  });

  // ── Subscribe ─────────────────────────────────────────────
  async function requestPermissionAndSubscribe() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      window.App?.toast('Push notifications not supported in this browser.', 'error');
      return;
    }

    const perm = await Notification.requestPermission();
    updateBtnState();

    if (perm !== 'granted') {
      window.App?.toast('Notification permission denied.', 'error');
      return;
    }

    try {
      const sw = await navigator.serviceWorker.ready;
      const vapidKey = urlBase64ToUint8Array(window.SITE?.vapidPublic || '');

      subscription = await sw.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: vapidKey,
      });

      await fetch('/api/push.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action:   'subscribe',
          endpoint: subscription.endpoint,
          p256dh:   btoa(String.fromCharCode(...new Uint8Array(subscription.getKey('p256dh')))),
          auth:     btoa(String.fromCharCode(...new Uint8Array(subscription.getKey('auth')))),
        }),
      });

      window.App?.toast('Notifications enabled! Click the bell on any anime to get alerts.', 'success');
    } catch(e) {
      console.error('Push subscribe error:', e);
      window.App?.toast('Could not enable notifications.', 'error');
    }
  }

  async function getSubscription() {
    if (subscription) return subscription;
    try {
      const sw = await navigator.serviceWorker.ready;
      subscription = await sw.pushManager.getSubscription();
    } catch(e) {}
    return subscription;
  }

  // ── Toggle anime notification ─────────────────────────────
  async function toggleAnime(animeId) {
    if (Notification.permission !== 'granted') {
      await requestPermissionAndSubscribe();
      if (Notification.permission !== 'granted') return;
    }

    const sub = await getSubscription();
    if (!sub) {
      await requestPermissionAndSubscribe();
      return;
    }

    const isOn = notifiedAnime.has(animeId);

    await fetch('/api/push.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action:    isOn ? 'remove_anime' : 'add_anime',
        endpoint:  sub.endpoint,
        anime_id:  animeId,
      }),
    });

    if (isOn) {
      notifiedAnime.delete(animeId);
      window.App?.toast('Notification removed.', 'info');
    } else {
      notifiedAnime.add(animeId);
      window.App?.toast('You\'ll be notified when this airs!', 'success');
    }

    localStorage.setItem('notif_anime', JSON.stringify([...notifiedAnime]));
    updateAnimeNotifButtons();
  }

  function isNotified(animeId) {
    return notifiedAnime.has(animeId);
  }

  function updateAnimeNotifButtons() {
    document.querySelectorAll('.notif-btn').forEach(btn => {
      const id = parseInt(btn.dataset.id);
      const on = notifiedAnime.has(id);
      btn.style.color = on ? 'var(--accent2)' : '';
      btn.title = on ? 'Remove notification' : 'Get notified when this airs';
    });
  }

  // ── Register Service Worker ───────────────────────────────
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(reg => {
      console.log('[SW] Registered:', reg.scope);
    }).catch(e => console.warn('[SW] Registration failed:', e));
  }

  // ── Utility ───────────────────────────────────────────────
  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw     = window.atob(base64);
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
  }

  return { toggleAnime, isNotified, requestPermissionAndSubscribe };
})();
