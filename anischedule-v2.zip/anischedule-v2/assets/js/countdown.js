// ============================================================
//  AniSchedule — Countdown Timers  (enhanced)
//  Targets:
//    .card-countdown[data-broadcast]  — schedule cards (broadcast-based)
//    .countdown-live[data-premiere]   — upcoming page (unix timestamp)
//  Live X days Y hrs Z min countdown, ticks every second
// ============================================================
window.Countdown = (function () {
  'use strict';

  const timers = new Map(); // element → intervalId

  // ── Public: init all broadcast-based countdowns ─────────────────────────────
  function initAll() {
    timers.forEach(id => clearInterval(id));
    timers.clear();

    document.querySelectorAll('.card-countdown[data-broadcast]').forEach(el => {
      // Tick every second for live X d Y h Z m display
      _tick(el);
      const id = setInterval(() => _tick(el), 1000);
      timers.set(el, id);
    });
  }

  // ── Public: init upcoming-page premiere countdowns ────────────────────────
  function initUpcoming() {
    document.querySelectorAll('.countdown-live[data-premiere]').forEach(el => {
      if (timers.has(el)) clearInterval(timers.get(el));
      _tickPremiere(el);
      const id = setInterval(() => _tickPremiere(el), 1000);
      timers.set(el, id);
    });
  }

  // ── Internal tick for broadcast countdowns ─────────────────────────────────
  function _tick(el) {
    try {
      const broadcast = JSON.parse(el.dataset.broadcast || '{}');
      if (!broadcast?.time) return;
      const ms = msUntilNextBroadcast(broadcast);
      if (ms === null) return;
      if (ms <= 0) {
        el.innerHTML = `<span class="airing-now"><i class="fa-solid fa-circle-dot fa-beat"></i> Airing now!</span>`;
      } else {
        el.innerHTML = `<i class="fa-regular fa-clock"></i> ${formatMs(ms)}`;
      }
    } catch (e) { /* ignore */ }
  }

  // ── Internal tick for premiere (unix timestamp) countdowns ────────────────
  function _tickPremiere(el) {
    try {
      const ts = parseInt(el.dataset.premiere, 10);
      if (!ts) { el.textContent = ''; return; }
      const ms = ts * 1000 - Date.now();
      if (ms <= 0) {
        el.innerHTML = `<span class="airing-now"><i class="fa-solid fa-circle-dot fa-beat"></i> Airing now!</span>`;
      } else {
        el.textContent = `⏳ ${formatMs(ms, true)}`;
      }
    } catch (e) { /* ignore */ }
  }

  // ── Calculate ms until next broadcast (in user local time, using JST source) ─
  function msUntilNextBroadcast(broadcast) {
    if (!broadcast?.time || !broadcast?.day) return null;

    const dayMap = {
      'Mondays': 1, 'Tuesdays': 2, 'Wednesdays': 3,
      'Thursdays': 4, 'Fridays': 5, 'Saturdays': 6, 'Sundays': 0,
    };
    const targetDow = dayMap[broadcast.day] ?? -1;
    if (targetDow < 0) return null;

    const [h, m] = broadcast.time.split(':').map(Number);
    const now = new Date();

    // Get current time in JST (UTC+9)
    const nowJst = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Tokyo' }));
    let diff = (targetDow - nowJst.getDay() + 7) % 7;

    if (diff === 0) {
      const nowMin    = nowJst.getHours() * 60 + nowJst.getMinutes();
      const targetMin = h * 60 + m;
      if (nowMin > targetMin + 30) {
        diff = 7; // past it by >30 min — next week
      } else if (nowMin >= targetMin - 5) {
        return -1; // within 5 min — "airing now"
      }
    }

    // Build next broadcast DateTime in JST, then get its UTC ms value
    const nextJst = new Date(nowJst);
    nextJst.setDate(nextJst.getDate() + diff);
    nextJst.setHours(h, m, 0, 0);

    // Offset trick: reconstruct UTC timestamp
    const utcStr   = nextJst.toLocaleString('en-US', { timeZone: 'UTC' });
    const jstStr   = nextJst.toLocaleString('en-US', { timeZone: 'Asia/Tokyo' });
    const utcMs    = Date.parse(utcStr + ' UTC');
    const jstMs    = Date.parse(jstStr + ' UTC');
    const offsetMs = jstMs - utcMs; // should be +9h
    const nextUtcMs = nextJst.getTime() - offsetMs;

    return nextUtcMs - now.getTime();
  }

  // ── Format milliseconds as "X days Y hrs Z min" ───────────────────────────
  function formatMs(ms, showSeconds) {
    if (ms <= 0) return '< 1 min';
    const totalSec = Math.floor(ms / 1000);
    const days  = Math.floor(totalSec / 86400);
    const hours = Math.floor((totalSec % 86400) / 3600);
    const mins  = Math.floor((totalSec % 3600) / 60);
    const secs  = totalSec % 60;

    if (days > 0) {
      return showSeconds
        ? `${days}d ${hours}h ${mins}m`
        : `${days}d ${hours}h ${mins}m`;
    }
    if (hours > 0) {
      return showSeconds
        ? `${hours}h ${mins}m ${secs}s`
        : `${hours}h ${mins}m`;
    }
    if (mins > 0) {
      return showSeconds
        ? `${mins}m ${secs}s`
        : `${mins}m`;
    }
    return `${secs}s`;
  }

  // ── Expose liveCountdown for anime detail page ────────────────────────────
  function liveCountdown(targetTimestamp, el) {
    function update() {
      const ms = targetTimestamp * 1000 - Date.now();
      if (ms <= 0) {
        el.textContent = 'Aired!';
        clearInterval(intervalId);
        return;
      }
      el.textContent = formatMs(ms, true);
    }
    update();
    const intervalId = setInterval(update, 1000);
    return intervalId;
  }

  return { initAll, initUpcoming, liveCountdown, formatMs, msUntilNextBroadcast };
})();

// Auto-init on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.Countdown.initAll();
  window.Countdown.initUpcoming();
});
