// ============================================================
//  AniSchedule — Core App JS
//  Handles: navbar, theme, user dropdown, toast, watchlist modal
// ============================================================
(function() {
  'use strict';

  // ── Navbar ──────────────────────────────────────────────
  const navbar   = document.getElementById('navbar');
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('navLinks');
  const searchToggle = document.getElementById('searchToggle');
  const navSearchBar = document.getElementById('navSearchBar');
  const userMenuBtn  = document.getElementById('userMenuBtn');
  const userMenu     = document.getElementById('userMenu');
  const themeToggle  = document.getElementById('themeToggle');
  const themeIcon    = document.getElementById('themeIcon');

  // Mobile hamburger — toggle menu + animate to X
  hamburger?.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = navLinks?.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
  });

  // Close mobile menu on outside click
  document.addEventListener('click', (e) => {
    if (navLinks?.classList.contains('open') &&
        !navbar?.contains(e.target)) {
      navLinks.classList.remove('open');
      hamburger?.classList.remove('open');
    }
  });

  // Close mobile menu when a nav link is clicked
  navLinks?.addEventListener('click', (e) => {
    if (e.target.closest('a')) {
      navLinks.classList.remove('open');
      hamburger?.classList.remove('open');
    }
  });

  // Mobile search toggle
  searchToggle?.addEventListener('click', () => {
    navSearchBar?.classList.toggle('open');
    if (navSearchBar?.classList.contains('open')) {
      navSearchBar.querySelector('input')?.focus();
    }
  });

  // User dropdown
  userMenuBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    userMenu?.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!userMenu?.contains(e.target)) {
      userMenu?.classList.remove('open');
    }
  });

  // ── Theme ────────────────────────────────────────────────
  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('theme', theme);
    if (themeIcon) {
      themeIcon.className = theme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
    }
  }

  // Load saved theme
  const savedTheme = localStorage.getItem('theme') || document.documentElement.dataset.theme || 'dark';
  applyTheme(savedTheme);

  themeToggle?.addEventListener('click', () => {
    const current = document.documentElement.dataset.theme || 'dark';
    const next    = current === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    // Save to server if logged in
    if (window.SITE?.user) {
      fetch('/api/auth.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_settings', theme: next, csrf: window.SITE.csrf })
      }).catch(() => {});
    }
  });

  // ── Timezone Selector ────────────────────────────────────
  function populateTimezoneSelect() {
    const sel = document.getElementById('timezoneSelect');
    if (!sel) return;

    let zones = [];
    try { zones = Intl.supportedValuesOf('timeZone'); } catch(e) {}

    const userTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const saved  = localStorage.getItem('tz') || userTz;

    zones.forEach(tz => {
      const opt = document.createElement('option');
      opt.value = tz;
      opt.textContent = tz.replace(/_/g, ' ');
      if (tz === saved) opt.selected = true;
      sel.appendChild(opt);
    });

    // Set auto-detect option
    const autoOpt = sel.querySelector('[value="auto"]');
    if (autoOpt) autoOpt.textContent = `Auto (${userTz})`;

    sel.addEventListener('change', () => {
      const tz = sel.value === 'auto' ? userTz : sel.value;
      localStorage.setItem('tz', tz);
      window.dispatchEvent(new CustomEvent('tzChanged', { detail: tz }));
    });
  }
  populateTimezoneSelect();

  // ── Toast notifications ──────────────────────────────────
  function toast(message, type = 'info', duration = 3500) {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `
      <i class="fa-solid ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-circle-xmark' : 'fa-circle-info'}"></i>
      <span>${message}</span>
    `;
    container.appendChild(el);

    setTimeout(() => {
      el.style.animation = 'slideIn .3s ease reverse forwards';
      setTimeout(() => el.remove(), 300);
    }, duration);
  }

  // ── Watchlist Modal ──────────────────────────────────────
  const wlModal        = document.getElementById('watchlistModal');
  const wlModalOverlay = document.getElementById('watchlistModalOverlay');
  const wlModalClose   = document.getElementById('wlModalClose');
  const wlModalBody    = document.getElementById('wlModalBody');
  const wlModalTitle   = document.getElementById('wlModalTitle');

  let currentAnime = null;

  function openWatchlistModal(anime) {
    if (!window.SITE?.user) {
      toast('Sign in to use the watchlist.', 'info');
      setTimeout(() => window.location.href = '/login.php', 1200);
      return;
    }
    currentAnime = anime;
    if (wlModalTitle) wlModalTitle.textContent = anime.title || 'Add to Watchlist';
    if (wlModalBody) {
      wlModalBody.innerHTML = `
        <select id="wlStatusSel" class="form-control">
          <option value="plan_to_watch">Plan to Watch</option>
          <option value="watching">Watching</option>
          <option value="completed">Completed</option>
          <option value="on_hold">On Hold</option>
          <option value="dropped">Dropped</option>
        </select>
        <div class="form-group" style="margin:0">
          <label>Progress (episode)</label>
          <input type="number" id="wlProgress" class="form-control" min="0" value="0" placeholder="0">
        </div>
        <div class="form-group" style="margin:0">
          <label>Score (1–10, optional)</label>
          <select id="wlScore" class="form-control">
            <option value="">— No score —</option>
            ${Array.from({length:10},(_,i)=>`<option value="${10-i}">${10-i}</option>`).join('')}
          </select>
        </div>
        <div style="display:flex;gap:.6rem;margin-top:.25rem">
          <button id="wlSaveBtn" class="btn btn-primary" style="flex:1">Save</button>
          <button id="wlRemoveBtn" class="btn btn-ghost">Remove</button>
        </div>
      `;
    }

    // Load existing entry
    fetch(`/api/watchlist.php?status=`)
      .then(r => r.json())
      .then(d => {
        const entry = (d.list || []).find(x => String(x.anime_id) === String(anime.id));
        if (entry) {
          document.getElementById('wlStatusSel').value  = entry.status || 'plan_to_watch';
          document.getElementById('wlProgress').value   = entry.progress || 0;
          document.getElementById('wlScore').value      = entry.score || '';
        }
      }).catch(() => {});

    document.getElementById('wlSaveBtn')?.addEventListener('click', saveToWatchlist);
    document.getElementById('wlRemoveBtn')?.addEventListener('click', removeFromWatchlist);

    wlModal?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  async function saveToWatchlist() {
    if (!currentAnime) return;
    const status   = document.getElementById('wlStatusSel')?.value;
    const progress = parseInt(document.getElementById('wlProgress')?.value || '0');
    const score    = document.getElementById('wlScore')?.value || null;

    const btn = document.getElementById('wlSaveBtn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>'; }

    try {
      const res = await fetch('/api/watchlist.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          anime_id: currentAnime.id,
          title:    currentAnime.title,
          cover:    currentAnime.cover,
          format:   currentAnime.format,
          status, progress,
          score: score ? parseInt(score) : null,
          csrf: window.SITE.csrf,
        })
      });
      const json = await res.json();
      if (json.ok) {
        toast('Watchlist updated!', 'success');
        closeWatchlistModal();
      } else {
        toast(json.error || 'Failed to update.', 'error');
      }
    } catch {
      toast('Network error.', 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = 'Save'; }
    }
  }

  async function removeFromWatchlist() {
    if (!currentAnime) return;
    try {
      await fetch('/api/watchlist.php', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ anime_id: currentAnime.id, csrf: window.SITE.csrf })
      });
      toast('Removed from watchlist.', 'info');
      closeWatchlistModal();
    } catch {
      toast('Error removing.', 'error');
    }
  }

  function closeWatchlistModal() {
    wlModal?.classList.remove('open');
    document.body.style.overflow = '';
    currentAnime = null;
  }

  wlModalClose?.addEventListener('click', closeWatchlistModal);
  wlModalOverlay?.addEventListener('click', closeWatchlistModal);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeWatchlistModal();
  });

  // ── Expose global API ─────────────────────────────────────
  window.App = {
    toast,
    openWatchlistModal,
    closeWatchlistModal,
    applyTheme,
    getCurrentTz: () => localStorage.getItem('tz') || Intl.DateTimeFormat().resolvedOptions().timeZone,
  };

})();
