/* ============================================================
   Character Browser — characters.js
   ============================================================ */
window.CharacterBrowser = (function() {
  'use strict';

  let cfg       = {};
  let page      = 1;
  let lastQ     = '';
  let loading   = false;
  let debounceT = null;

  // ── Init ───────────────────────────────────────────────────
  function init(options) {
    cfg = options;

    const searchInput = document.getElementById('charSearchInput');
    const clearBtn    = document.getElementById('charSearchClear');
    const pagination  = document.getElementById('charPagination');

    // Initial load
    loadChars('', 1);

    // Search input
    if (searchInput) {
      searchInput.addEventListener('input', () => {
        const q = searchInput.value.trim();
        clearBtn.style.display = q ? '' : 'none';
        clearTimeout(debounceT);
        debounceT = setTimeout(() => {
          if (q !== lastQ) {
            page  = 1;
            lastQ = q;
            loadChars(q, 1);
          }
        }, 380);
      });

      searchInput.addEventListener('keydown', e => {
        if (e.key === 'Enter') {
          clearTimeout(debounceT);
          const q = searchInput.value.trim();
          page  = 1;
          lastQ = q;
          loadChars(q, 1);
        }
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        searchInput.value = '';
        clearBtn.style.display = 'none';
        page  = 1;
        lastQ = '';
        loadChars('', 1);
      });
    }
  }

  // ── Load characters ────────────────────────────────────────
  async function loadChars(q, p) {
    if (loading) return;
    loading = true;

    const grid    = document.getElementById('charGrid');
    const title   = document.getElementById('charSectionTitle');
    const count   = document.getElementById('charResultCount');
    const pagEl   = document.getElementById('charPagination');

    // Show skeleton
    grid.innerHTML = Array(24).fill('<div class="char-card char-card-skeleton"></div>').join('');
    if (count) count.textContent = '';

    try {
      const url  = q
        ? `${cfg.apiBase}?q=${encodeURIComponent(q)}&page=${p}`
        : `${cfg.apiBase}?action=top&page=${p}`;

      const res  = await fetch(url);
      const json = await res.json();

      if (!json.ok) throw new Error(json.error || 'API error');

      const chars = json.data || [];
      const pag   = json.pagination || {};

      // Update heading
      if (title) {
        title.innerHTML = q
          ? `<i class="fa-solid fa-magnifying-glass"></i> Results for "${escHtml(q)}"`
          : '<i class="fa-solid fa-star"></i> Top Characters';
      }

      // Count
      if (count && pag.items) {
        count.textContent = `${pag.items.total?.toLocaleString() || chars.length} characters`;
      }

      // Render grid
      if (!chars.length) {
        grid.innerHTML = `
          <div class="char-empty-state">
            <i class="fa-solid fa-user-slash"></i>
            <p>No characters found${q ? ` for "${escHtml(q)}"` : ''}.</p>
          </div>`;
      } else {
        grid.innerHTML = chars.map((c, i) => renderCard(c, i + 1 + (p-1)*24)).join('');
      }

      // Pagination
      renderPagination(pagEl, pag, q, p);

    } catch(err) {
      grid.innerHTML = `
        <div class="char-empty-state">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <p>Failed to load characters: ${escHtml(err.message)}</p>
          <button class="btn btn-outline btn-sm" onclick="CharacterBrowser.retry()">Retry</button>
        </div>`;
    } finally {
      loading = false;
    }
  }

  // ── Render card ────────────────────────────────────────────
  function renderCard(c, rank) {
    const img      = c.images?.jpg?.image_url || '';
    const name     = c.name || 'Unknown';
    const nameKanji= c.name_kanji || '';
    const favorites= c.favorites ? `<span class="char-card-fav"><i class="fa-solid fa-heart"></i> ${fmtNum(c.favorites)}</span>` : '';
    const animes   = (c.anime || []).slice(0, 2).map(a => escHtml(a.anime?.title || '')).join(', ');
    const link     = `${cfg.detailBase}?id=${c.mal_id}`;

    return `
      <a href="${link}" class="char-card">
        <div class="char-card-img-wrap">
          ${img
            ? `<img src="${escHtml(img)}" alt="${escHtml(name)}" class="char-card-img" loading="lazy"
                    onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
            : ''}
          <div class="char-card-img-ph" ${img ? 'style="display:none"' : ''}>
            <span>${name.slice(0,2).toUpperCase()}</span>
          </div>
          <div class="char-card-overlay">
            ${favorites}
          </div>
          ${rank <= 24 ? `<div class="char-card-rank">#${rank}</div>` : ''}
        </div>
        <div class="char-card-body">
          <span class="char-card-name">${escHtml(name)}</span>
          ${nameKanji ? `<span class="char-card-kanji">${escHtml(nameKanji)}</span>` : ''}
          ${animes ? `<span class="char-card-from">${animes}</span>` : ''}
        </div>
      </a>`;
  }

  // ── Pagination ─────────────────────────────────────────────
  function renderPagination(el, pag, q, current) {
    if (!el) return;
    const last = pag.last_visible_page || 1;
    if (last <= 1) { el.innerHTML = ''; return; }

    const pages = [];
    for (let p = Math.max(1, current-2); p <= Math.min(last, current+2); p++) pages.push(p);

    el.innerHTML = `
      <button class="char-pag-btn" ${current<=1?'disabled':''} data-q="${escHtml(q)}" data-p="${current-1}">
        <i class="fa-solid fa-chevron-left"></i>
      </button>
      ${pages.map(p => `
        <button class="char-pag-btn ${p===current?'active':''}" data-q="${escHtml(q)}" data-p="${p}">${p}</button>
      `).join('')}
      <button class="char-pag-btn" ${current>=last?'disabled':''} data-q="${escHtml(q)}" data-p="${current+1}">
        <i class="fa-solid fa-chevron-right"></i>
      </button>`;

    el.querySelectorAll('.char-pag-btn:not([disabled])').forEach(btn => {
      btn.addEventListener('click', () => {
        page = parseInt(btn.dataset.p);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        loadChars(btn.dataset.q, page);
      });
    });
  }

  // ── Helpers ────────────────────────────────────────────────
  function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function fmtNum(n) {
    return n >= 1000 ? (n/1000).toFixed(1) + 'k' : n.toString();
  }

  return { init, retry: () => loadChars(lastQ, page) };
})();
