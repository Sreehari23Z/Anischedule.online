// ============================================================
//  AniSchedule — Schedule Page JS
//  Features: card view, week-grid view, season tabs, week nav,
//            mobile accordion, scroll-to-today
// ============================================================
window.SchedulePage = (function () {
  'use strict';

  // ── State ────────────────────────────────────────────────
  let config           = {};
  let fullSchedule     = {};       // { monday:[...], tuesday:[...], ... }  — Jikan/MAL
  let donghuaSchedule  = {};       // same shape, from AniList CN
  let episodeMap       = {};       // malId(str) → {ep, airingAt, anilistId}  — AniList accurate
  let premiereList     = [];       // upcoming Ep-1 shows not yet in Jikan
  let activeDay        = '';
  let activeType       = '';
  let activeSort       = 'members';
  let activeLayout     = localStorage.getItem('scheduleLayout') || 'rows';

  // Season / week state
  let weekOffset   = 0;        // 0 = this week, -1 = last week, +1 = next week
  let viewMode     = 'airing'; // 'airing' | 'seasonal'
  let viewSeason   = getCurrentSeason();
  let viewYear     = new Date().getFullYear();
  let seasonNavYear= new Date().getFullYear(); // year shown in season tabs

  const DAYS     = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
  const SEASONS  = ['winter','spring','summer','fall'];
  const MON_ABBR = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];

  // ── Init ────────────────────────────────────────────────
  function init(cfg) {
    config    = cfg;
    activeDay = cfg.defaultDay || strtolower(new Date().toLocaleDateString('en', { weekday: 'long' }));

    initSeasonBar();
    applyLayoutUI();
    bindDayTabs();
    bindTypeFilter();
    bindSortSelect();
    bindLayoutToggle();
    bindWeekNav();
    bindSeasonNav();

    if (activeLayout !== 'card') {
      loadAllAndRender();
    } else {
      loadDay(activeDay === 'all' ? '' : activeDay);
    }
  }

  // ── Season helpers ────────────────────────────────────────
  function getCurrentSeason(date) {
    const m = (date || new Date()).getMonth();
    if (m < 3)  return 'winter';
    if (m < 6)  return 'spring';
    if (m < 9)  return 'summer';
    return 'fall';
  }

  function seasonLabel(season, year) {
    return capitalize(season) + ' \'' + String(year).slice(2);
  }

  // ── Season bar ────────────────────────────────────────────
  function initSeasonBar() {
    renderSeasonTabs();
    document.getElementById('seasonYearPrev')?.addEventListener('click', () => {
      seasonNavYear--;
      renderSeasonTabs();
    });
    document.getElementById('seasonYearNext')?.addEventListener('click', () => {
      seasonNavYear++;
      renderSeasonTabs();
    });
  }

  function renderSeasonTabs() {
    const container = document.getElementById('schedSeasonTabs');
    if (!container) return;

    const nowSeason = getCurrentSeason();
    const nowYear   = new Date().getFullYear();

    container.innerHTML = SEASONS.map(s => {
      const isCurrent = s === nowSeason && seasonNavYear === nowYear;
      const isActive  = s === viewSeason && seasonNavYear === viewYear;
      return `<button class="sched-season-tab ${isActive ? 'active' : ''}"
                data-season="${s}" data-year="${seasonNavYear}">
        ${seasonLabel(s, seasonNavYear)}
        ${isCurrent ? '<span class="sched-season-now">NOW</span>' : ''}
      </button>`;
    }).join('');

    container.querySelectorAll('.sched-season-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        const s = btn.dataset.season;
        const y = parseInt(btn.dataset.year);
        selectSeason(s, y);
      });
    });

    // Show the year in a label
    const yearEl = document.getElementById('schedSeasonYearLabel');
    if (yearEl) yearEl.textContent = seasonNavYear;
  }

  function selectSeason(season, year) {
    // Navigate to the Seasonal Chart page for any season click
    const base = (window.SITE && window.SITE.base) ? window.SITE.base : '';
    window.location.href = base + '/seasonal.php?season=' + season + '&year=' + year;
  }

  // ── Week navigation ───────────────────────────────────────
  function bindWeekNav() {
    document.getElementById('weekPrevBtn')?.addEventListener('click', () => {
      weekOffset--;
      updateWeekNavLabel();
      if (activeLayout !== 'card') renderGrid();
    });
    document.getElementById('weekNextBtn')?.addEventListener('click', () => {
      weekOffset++;
      updateWeekNavLabel();
      if (activeLayout !== 'card') renderGrid();
    });
  }

  function bindSeasonNav() {
    // Already bound inside initSeasonBar / renderSeasonTabs
  }

  function updateWeekNavLabel() {
    const el = document.getElementById('weekNavLabel');
    if (!el) return;
    if (viewMode === 'seasonal') {
      el.textContent = seasonLabel(viewSeason, viewYear);
      return;
    }
    if (weekOffset === 0) { el.textContent = 'This Week'; return; }
    const dates = getWeekDates();
    const mon = dates.monday;
    const sun = dates.sunday;
    el.textContent = `${mon.dateNum} ${mon.monthStr} – ${sun.dateNum} ${sun.monthStr}`;
  }

  // ── Data loading ──────────────────────────────────────────
  function loadDay(day) {
    const container = document.getElementById('scheduleContainer');
    container.innerHTML = spinner('Loading schedule…');
    const url = config.apiBase + (day ? '?day=' + day : '');
    fetch(url, { cache: 'no-store' })
      .then(r => r.json())
      .then(data => {
        if (!data.ok) throw new Error(data.error || 'API error');
        Object.assign(fullSchedule, data.schedule);
        render();
      })
      .catch(() => { container.innerHTML = errorState(); });
  }

  function loadSeason(season, year) {
    const container = document.getElementById('scheduleContainer');
    container.innerHTML = spinner('Loading ' + seasonLabel(season, year) + '…');
    const url = config.apiBase + '?season=' + season + '&year=' + year;
    fetch(url, { cache: 'no-store' })
      .then(r => r.json())
      .then(data => {
        if (!data.ok) throw new Error(data.error || 'API error');
        Object.assign(fullSchedule, data.schedule);
        if (activeLayout !== 'card') renderGrid(); else render();
      })
      .catch(() => { container.innerHTML = errorState(); });
  }

  function loadAllAndRender() {
    // Render skeleton immediately so user sees layout at once
    renderGrid();

    if (viewMode === 'seasonal') {
      if (!DAYS.some(d => fullSchedule[d] !== undefined)) loadSeason(viewSeason, viewYear);
      return;
    }

    // Fetch all 7 days in ONE request — much faster on single-threaded PHP server
    const missing = DAYS.filter(d => fullSchedule[d] === undefined);
    if (missing.length) {
      fetch(config.apiBase)
        .then(r => r.json())
        .then(data => {
          if (data.ok) Object.assign(fullSchedule, data.schedule);
          if (activeLayout !== 'card') renderGrid(); else render();
        })
        .catch(() => {});
    }

    // Load Donghua in parallel (fire once, no per-day splitting needed)
    if (config.donghuaApi && !Object.keys(donghuaSchedule).length) {
      fetch(config.donghuaApi)
        .then(r => r.json())
        .then(data => {
          if (data.ok) {
            donghuaSchedule = data.schedule || {};
          }
          if (activeLayout !== 'card') renderGrid(); else render();
        })
        .catch(() => {});
    }

    // Load AniList episode accuracy + premieres in parallel
    if (config.episodeApi && !Object.keys(episodeMap).length) {
      fetch(config.episodeApi)
        .then(r => r.json())
        .then(data => {
          if (data.ok) {
            episodeMap   = data.episodes  || {};
            premiereList = data.premieres || [];
          }
          if (activeLayout !== 'card') renderGrid(); else render();
        })
        .catch(() => {});
    }
  }

  // ── Card layout render ────────────────────────────────────
  function render() {
    if (activeLayout !== 'card') { renderGrid(); return; }

    const container  = document.getElementById('scheduleContainer');
    const todayName  = strtolower(new Date().toLocaleDateString('en', { weekday: 'long' }));
    const daysToShow = activeDay === 'all' ? DAYS : [activeDay];
    const tz         = window.App?.getCurrentTz() || 'UTC';
    const localSched = getLocalSchedule();

    let html = '';
    daysToShow.forEach(day => {
      let anime = localSched[day] || [];
      if (activeType) anime = anime.filter(a => a.type === activeType);
      anime = sortAnime(anime, activeSort);
      if (!anime.length && activeType) return;

      const isToday = weekOffset === 0 && day === todayName;
      html += `
        <section class="day-section" data-day="${day}">
          <div class="day-section-header">
            <h2 class="day-section-title ${isToday ? 'today' : ''}">
              ${capitalize(day)}
              ${isToday ? '<span class="today-label">Today</span>' : ''}
            </h2>
            <span class="day-count">${anime.length} anime</span>
          </div>
          <div class="schedule-row">
            ${anime.length ? anime.map(a => renderCard(a, tz)).join('') : renderEmpty()}
          </div>
        </section>`;
    });

    if (!html) html = `<div class="empty-state"><i class="fa-solid fa-calendar-xmark"></i><p>No anime found for this filter.</p></div>`;
    container.innerHTML = html;
    bindCardButtons(container);
    window.Countdown?.initAll();
  }

  // ── Week-grid layout render ───────────────────────────────
  function renderGrid() {
    const container  = document.getElementById('scheduleContainer');
    const todayDate  = new Date();
    const todayStr   = todayDate.toDateString();
    const dates      = getWeekDates();
    const localSched = getLocalSchedule();
    const tz         = window.App?.getCurrentTz() || 'UTC';

    // For current week, rotate DAYS so today is first
    const todayName = strtolower(todayDate.toLocaleDateString('en', { weekday: 'long' }));
    const todayIdx  = DAYS.indexOf(todayName);
    const orderedDays = (weekOffset === 0 && todayIdx >= 0)
      ? [...DAYS.slice(todayIdx), ...DAYS.slice(0, todayIdx)]
      : DAYS;

    const isColGrid = activeLayout === 'grid';
    let html = `<div class="week-grid ${isColGrid ? 'week-grid--cols' : 'week-grid--rows'}">`;

    orderedDays.forEach(day => {
      const { dateNum, monthStr, fullDate } = dates[day];
      let anime = localSched[day] || [];
      anime = filterForDate(anime, fullDate);
      if (activeType) anime = anime.filter(a => a.type === activeType);
      anime = sortAnime(anime, activeSort);

      const isToday = fullDate.toDateString() === todayStr;
      const loaded  = fullSchedule[day] !== undefined;
      const count   = loaded ? anime.length : '…';

      html += `
        <div class="week-col ${isToday ? 'week-col-today' : ''}" data-day="${day}">
          <div class="week-col-header">
            <span class="week-col-date">${dateNum} ${monthStr}</span>
            <span class="week-col-day">${capitalize(day)}</span>
            <span class="week-col-count">${count}</span>
          </div>
          <div class="week-col-body">
            ${!loaded
              ? '<div class="week-col-loading"><div class="spinner" style="width:22px;height:22px;border-width:2px"></div></div>'
              : anime.length
                ? anime.map(a => renderGridCard(a, tz, fullDate)).join('')
                : '<div class="week-col-empty"><i class="fa-regular fa-moon"></i><span>No anime scheduled</span></div>'}
          </div>
        </div>`;
    });

    html += '</div>';
    container.innerHTML = html;
    bindCardButtons(container);
    window.Countdown?.initAll();
    scrollToToday();
  }

  // Scroll today's column into view — horizontal only, never vertical
  function scrollToToday() {
    setTimeout(() => {
      const todayRow = document.querySelector('.week-col-today');
      if (!todayRow) return;
      todayRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 80);
  }

  // Mobile accordion bindings
  function bindAccordion(container) {
    container.querySelectorAll('.acc-header').forEach(btn => {
      btn.addEventListener('click', () => {
        const row  = btn.closest('.acc-row');
        const body = row.querySelector('.acc-body');
        const open = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', !open);
        if (open) body.setAttribute('hidden', '');
        else body.removeAttribute('hidden');
        const icon = btn.querySelector('.acc-chevron');
        if (icon) icon.className = `fa-solid fa-chevron-${open ? 'down' : 'up'} acc-chevron`;
      });
    });
  }

  // ── Card HTML (card layout) ───────────────────────────────
  function renderCard(a, tz) {
    const base = window.SITE?.base || '';
    const broadcastInfo = a.broadcast?.time ? formatBroadcastTime(a.broadcast, tz) : '';
    const isDonghua = a.donghua === true;
    return `
    <article class="anime-card${isDonghua ? ' donghua-card' : ''}" data-id="${a.id}" data-type="${a.type}"${isDonghua ? ' data-donghua="true"' : ''}>
      <a href="${base}${esc(a.url)}" class="card-cover-link">
        <div class="card-cover-wrap">
          <img src="${esc(a.cover)}" alt="${esc(a.title_en)}" class="card-cover" loading="lazy"
               onerror="this.src='/assets/img/no-cover.svg'">
          ${isDonghua ? '<span class="donghua-badge">🇨🇳 Donghua</span>' : ''}
          <div class="card-overlay">
            <div class="card-score">${a.score ? '&#9733; ' + a.score : 'N/A'}</div>
            <div class="card-actions">
              <button class="card-action-btn wl-btn"
                data-id="${a.id}" data-title="${esc(a.title_en)}"
                data-cover="${esc(a.cover)}" data-format="${esc(a.type)}"
                title="Add to watchlist"><i class="fa-solid fa-plus"></i></button>
              <button class="card-action-btn notif-btn" data-id="${a.id}" title="Get notified">
                <i class="fa-solid fa-bell"></i></button>
            </div>
          </div>
        </div>
      </a>
      <div class="card-info">
        <h3 class="card-title"><a href="${base}${esc(a.url)}">${esc(a.title_en)}</a></h3>
        <div class="card-meta">
          <span class="badge badge-type">${esc(a.type)}</span>
          ${a.episodes ? `<span class="card-ep">${a.episodes} eps</span>` : ''}
          ${a.airing ? '<span class="badge badge-airing">Airing</span>' : ''}
        </div>
        <p class="card-genres">${(a.genres || []).slice(0, 3).join(' \xb7 ')}</p>
        ${broadcastInfo ? `<div class="card-countdown" data-broadcast='${JSON.stringify(a.broadcast)}' data-tz="${esc(tz)}">${broadcastInfo}</div>` : ''}
      </div>
    </article>`;
  }

  // ── Grid card HTML (week-grid columns) ────────────────────
  function renderGridCard(a, tz, weekDate) {
    const base      = window.SITE?.base || '';
    const time      = a.broadcast?.time ? formatTimeCompact(a.broadcast, tz) : '';
    const scoreStr  = a.score ? a.score.toFixed(1) : '';
    const isDonghua = a.donghua === true;
    const nativeTitle = a.title_jp || a.title_cn || '';

    // Episode badge
    let epBadge = '';
    if (weekDate) {
      const epData = getEpisodeForDate(a, weekDate);
      if (epData && typeof epData === 'object') {
        const isNew = a.is_premiere === true || epData.ep === 1;
        const cls   = epData.isFinal ? 'ep-final' : (isNew ? 'ep-new' : '');
        const label = isNew ? `NEW · Ep ${epData.ep}` : `Ep ${epData.ep}${epData.isFinal ? ' · FIN' : ''}`;
        epBadge = `<span class="grid-ep-badge ${cls}">${label}</span>`;
      }
    }

    return `
    <div class="grid-card${isDonghua ? ' donghua-card' : ''}" data-id="${a.id}" data-type="${a.type}"${isDonghua ? ' data-donghua="true"' : ''}>
      <div class="grid-card-topbar">
        <span class="grid-card-time">${time || '--:--'}</span>
        <span class="grid-card-badge">${esc(a.type)}</span>
        ${scoreStr ? `<span class="grid-card-score">★${scoreStr}</span>` : ''}
        ${isDonghua ? '<span class="grid-donghua-badge">CN</span>' : ''}
        <div class="grid-card-actions">
          <button class="grid-action-btn wl-btn"
            data-id="${a.id}" data-title="${esc(a.title_en)}"
            data-cover="${esc(a.cover)}" data-format="${esc(a.type)}"
            title="Watchlist"><i class="fa-solid fa-plus"></i></button>
          <button class="grid-action-btn notif-btn" data-id="${a.id}" title="Notify">
            <i class="fa-solid fa-bell"></i></button>
        </div>
      </div>
      ${epBadge}
      <a href="${base}${esc(a.url)}" class="grid-card-cover-link">
        <img src="${esc(a.cover)}" alt="${esc(a.title_en)}" class="grid-card-cover" loading="lazy"
             onerror="this.src='/assets/img/no-cover.svg'">
        <div class="grid-card-overlay">
          <span class="grid-card-title">${esc(a.title_en)}</span>
          ${nativeTitle ? `<span class="grid-native-title">${esc(nativeTitle)}</span>` : ''}
          ${(a.genres || []).length ? `<span class="grid-card-genre">${esc(a.genres[0])}</span>` : ''}
        </div>
      </a>
    </div>`;
  }

  // ── Mobile card (compact horizontal list item) ────────────
  function renderMobileCard(a, tz, weekDate) {
    const base        = window.SITE?.base || '';
    const time        = a.broadcast?.time ? formatTimeCompact(a.broadcast, tz) : '';
    const isDonghua   = a.donghua === true;
    const nativeTitle = a.title_jp || a.title_cn || '';

    let epStr = '';
    if (weekDate) {
      const epData = getEpisodeForDate(a, weekDate);
      if (epData && typeof epData === 'object') {
        const isNew = a.is_premiere === true || epData.ep === 1;
        epStr = isNew ? `NEW · Ep ${epData.ep}` : `Ep ${epData.ep}${epData.isFinal ? ' · FIN' : ''}`;
      }
    }

    return `
    <div class="mob-card${isDonghua ? ' donghua-card' : ''}" data-id="${a.id}"${isDonghua ? ' data-donghua="true"' : ''}>
      <a href="${base}${esc(a.url)}" class="mob-card-link">
        <img src="${esc(a.cover)}" class="mob-card-cover" loading="lazy"
             onerror="this.src='/assets/img/no-cover.svg'">
        <div class="mob-card-info">
          <div class="mob-card-title">${esc(a.title_en)}${isDonghua ? ' <span class="mob-donghua-badge">CN</span>' : ''}</div>
          ${nativeTitle ? `<div class="mob-native-title">${esc(nativeTitle)}</div>` : ''}
          <div class="mob-card-meta">
            ${time ? `<span class="grid-card-time">${time}</span>` : ''}
            <span class="grid-card-badge">${esc(a.type)}</span>
            ${epStr ? `<span class="mob-ep-badge">${epStr}</span>` : ''}
            ${a.score ? `<span class="grid-card-score">★${a.score.toFixed(1)}</span>` : ''}
          </div>
          <div class="mob-card-genre">${(a.genres || []).slice(0,2).join(' \xb7 ')}</div>
        </div>
      </a>
    </div>`;
  }

  function renderEmpty() {
    return `<div class="empty-state" style="grid-column:1/-1;padding:2rem">
      <i class="fa-solid fa-moon"></i><p>No anime airing.</p></div>`;
  }

  // ── Time formatting ───────────────────────────────────────
  function formatBroadcastTime(broadcast, tz) {
    if (!broadcast?.time) return '';
    try {
      const [h, m] = broadcast.time.split(':').map(Number);
      const now = new Date();
      const utcMs = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate(), h, m) - 9*60*60000;
      const t = new Date(utcMs).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', timeZone: tz });
      return `<i class="fa-regular fa-clock"></i> ${t} <span style="font-size:.7em;color:var(--text3)">(${broadcast.timezone || 'JST'})</span>`;
    } catch { return ''; }
  }

  function getTzLabel(tz) {
    try {
      const s = new Intl.DateTimeFormat('en', { timeZone: tz, timeZoneName: 'short' })
        .formatToParts(new Date()).find(p => p.type === 'timeZoneName');
      return s ? s.value : tz;
    } catch { return tz; }
  }

  function formatTimeCompact(broadcast, tz) {
    if (!broadcast?.time) return '';
    try {
      const [h, m] = broadcast.time.split(':').map(Number);
      const now = new Date();
      const utcMs = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate(), h, m) - 9*60*60000;
      const t = new Date(utcMs).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', timeZone: tz });
      const tzLabel = getTzLabel(tz);
      return `${t} <span class="tz-label">${tzLabel}</span>`;
    } catch { return broadcast.time || ''; }
  }

  // ── Episode for date ──────────────────────────────────────
  // Returns {ep, isFinal, source} | 'ended' | 'future' | null
  function getEpisodeForDate(anime, weekDate) {
    const malId = String(anime.id || anime.mal_id || '');
    const mapEntry = malId && episodeMap[malId];

    // Priority 1: AniList airingSchedules exact data
    if (mapEntry) {
      const diff = Math.abs(weekDate.getTime() / 1000 - mapEntry.airingAt);
      const weeksSince = Math.round((weekDate.getTime() / 1000 - mapEntry.airingAt) / (7 * 3600));
      const adjustedEp = mapEntry.ep + weeksSince;
      if (diff < 3.5 * 86400 || Math.abs(weeksSince) <= 10) {
        const ep = Math.max(1, adjustedEp);
        const isFinal = anime.episodes && ep >= anime.episodes;
        return { ep, isFinal, source: 'anilist' };
      }
    }

    // Priority 2: stored next_episode + airingAt from donghua/premiere
    if (anime.next_episode && anime.airingAt) {
      const weeksSince = Math.round((weekDate.getTime() / 1000 - anime.airingAt) / (7 * 3600));
      const ep = Math.max(1, anime.next_episode + weeksSince);
      const isFinal = anime.episodes && ep >= anime.episodes;
      return { ep, isFinal, source: 'stored' };
    }

    // Priority 3: calculate from aired_from
    if (anime.aired_from) {
      try {
        const start = new Date(anime.aired_from);
        const weeksSince = Math.round((weekDate - start) / (7 * 24 * 3600 * 1000));
        if (weeksSince < 0) return 'future';
        const ep = weeksSince + 1;
        if (anime.episodes && ep > anime.episodes) return 'ended';
        const isFinal = anime.episodes && ep >= anime.episodes;
        return { ep, isFinal, source: 'calc' };
      } catch { return null; }
    }

    return null;
  }

  // ── Filter anime for a specific date (drop ended/future from non-current weeks) ──
  function filterForDate(animeList, weekDate) {
    if (weekOffset === 0) return animeList;
    return animeList.filter(a => {
      if (a.is_premiere === true) return true;
      if (a.airing === false) return false;
      const result = getEpisodeForDate(a, weekDate);
      return result !== 'ended' && result !== 'future';
    });
  }

  // ── Week date calculation ─────────────────────────────────
  function getWeekDates() {
    const now = new Date();
    now.setDate(now.getDate() + weekOffset * 7);
    const dow = now.getDay(); // 0=Sun
    const monday = new Date(now);
    monday.setDate(now.getDate() + (dow === 0 ? -6 : 1 - dow));

    const result = {};
    DAYS.forEach((day, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      result[day] = { dateNum: d.getDate(), monthStr: MON_ABBR[d.getMonth()], fullDate: new Date(d) };
    });
    return result;
  }

  // ── JST → local-day rebucketing ───────────────────────────
  // broadcast.time is stored as JST "HH:MM". Convert to user's local
  // day so shows crossing midnight JST appear on the correct local day.
  function jstToLocalDay(jstDay, jstTime) {
    if (!jstTime) return jstDay;
    try {
      const jstDayIdx = DAYS.indexOf(jstDay.toLowerCase());
      if (jstDayIdx === -1) return jstDay;
      const [h, m] = jstTime.split(':').map(Number);
      // 2025-01-06 (Mon) as stable reference Monday in UTC
      const utcMs = Date.UTC(2025, 0, 6 + jstDayIdx, h, m) - 9 * 3600000;
      const local = new Date(utcMs);
      const localDayIdx = (local.getDay() + 6) % 7; // 0=Mon … 6=Sun
      return DAYS[localDayIdx];
    } catch { return jstDay; }
  }

  function getLocalSchedule() {
    const local = {};
    DAYS.forEach(d => { local[d] = []; });

    // Bucket regular Jikan/MAL anime by local day
    DAYS.forEach(jstDay => {
      (fullSchedule[jstDay] || []).forEach(anime => {
        const localDay = jstToLocalDay(jstDay, anime.broadcast?.time);
        (local[localDay] || local[jstDay]).push(anime);
      });
    });

    // Bucket Donghua by local day (same JST conversion — airingAt was stored as JST)
    const seenIds = new Set();
    DAYS.forEach(jstDay => {
      (fullSchedule[jstDay] || []).forEach(a => { seenIds.add(String(a.id)); if (a.mal_id) seenIds.add('mal_' + a.mal_id); });
      (donghuaSchedule[jstDay] || []).forEach(anime => {
        const localDay = jstToLocalDay(jstDay, anime.broadcast?.time);
        (local[localDay] || local[jstDay]).push(anime);
        seenIds.add(String(anime.id));
      });
    });

    // Inject premieres (upcoming Ep-1 shows from AniList not yet in Jikan/Donghua)
    const dates = getWeekDates();
    premiereList.forEach(premiere => {
      // Skip if already covered by Jikan or Donghua
      const malKey = premiere.mal_id ? 'mal_' + premiere.mal_id : null;
      if (seenIds.has(String(premiere.id)) || (malKey && seenIds.has(malKey))) return;
      // Find which day of the displayed week this premiere falls on
      const airingDate = new Date(premiere.airingAt * 1000);
      const airingStr  = airingDate.toDateString();
      const matchDay   = DAYS.find(d => dates[d].fullDate.toDateString() === airingStr);
      if (!matchDay) return; // not this week
      const localDay = jstToLocalDay(premiere.broadcast.day, premiere.broadcast.time);
      (local[localDay] || local[matchDay]).push(premiere);
      seenIds.add(String(premiere.id));
    });

    return local;
  }

  // ── Sorting ───────────────────────────────────────────────
  function sortAnime(anime, sort) {
    return [...anime].sort((a, b) => {
      switch (sort) {
        case 'score':   return (b.score || 0) - (a.score || 0);
        case 'title':   return a.title.localeCompare(b.title);
        case 'time': {
          // Convert JST broadcast time → user's local timezone minutes, then sort morning→night
          const toLocalMins = (bc) => {
            if (!bc?.time) return 99 * 60 + 99;
            try {
              const [h, m] = bc.time.split(':').map(Number);
              const now = new Date();
              const utcMs = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate(), h, m) - 9 * 3600000;
              const local = new Date(utcMs);
              return local.getHours() * 60 + local.getMinutes();
            } catch { return 99 * 60 + 99; }
          };
          return toLocalMins(a.broadcast) - toLocalMins(b.broadcast);
        }
        default:        return b.members - a.members;
      }
    });
  }

  // ── Layout UI ─────────────────────────────────────────────
  function applyLayoutUI() {
    const rowsBtn    = document.getElementById('layoutRows');
    const gridBtn    = document.getElementById('layoutGrid');
    const cardBtn    = document.getElementById('layoutCard');
    const dayTabs    = document.getElementById('dayTabs');
    const weekNavBar = document.getElementById('weekNavBar');

    [rowsBtn, gridBtn, cardBtn].forEach(btn => {
      if (!btn) return;
      const id = btn.id.replace('layout','').toLowerCase();
      const active = activeLayout === id;
      btn.classList.toggle('active', active);
      btn.setAttribute('aria-pressed', String(active));
    });

    // Show week-nav for rows/grid views; show day-tabs for card view
    const isWeekView = activeLayout !== 'card';
    if (dayTabs)    dayTabs.style.display    = isWeekView ? 'none' : '';
    if (weekNavBar) weekNavBar.style.display = isWeekView ? 'flex' : 'none';
    updateWeekNavLabel();
  }

  function bindLayoutToggle() {
    document.getElementById('layoutRows')?.addEventListener('click', () => {
      activeLayout = 'rows';
      localStorage.setItem('scheduleLayout', 'rows');
      applyLayoutUI();
      loadAllAndRender();
    });
    document.getElementById('layoutGrid')?.addEventListener('click', () => {
      activeLayout = 'grid';
      localStorage.setItem('scheduleLayout', 'grid');
      applyLayoutUI();
      loadAllAndRender();
    });
    document.getElementById('layoutCard')?.addEventListener('click', () => {
      activeLayout = 'card';
      localStorage.setItem('scheduleLayout', 'card');
      applyLayoutUI();
      if (viewMode === 'seasonal') loadSeason(viewSeason, viewYear);
      else render();
    });
  }

  // ── Day/filter bindings ───────────────────────────────────
  function bindDayTabs() {
    document.getElementById('dayTabs')?.addEventListener('click', e => {
      const btn = e.target.closest('.day-tab');
      if (!btn) return;
      document.querySelectorAll('.day-tab').forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected','false'); });
      btn.classList.add('active'); btn.setAttribute('aria-selected','true');
      activeDay = btn.dataset.day;
      if (activeDay !== 'all' && !fullSchedule[activeDay]) loadDay(activeDay);
      else render();
    });
  }

  function bindTypeFilter() {
    document.getElementById('typeFilter')?.addEventListener('click', e => {
      const chip = e.target.closest('.chip');
      if (!chip) return;
      document.querySelectorAll('#typeFilter .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeType = chip.dataset.type;
      activeLayout !== 'card' ? renderGrid() : render();
    });
  }

  function bindSortSelect() {
    document.getElementById('sortSelect')?.addEventListener('change', e => {
      activeSort = e.target.value;
      activeLayout !== 'card' ? renderGrid() : render();
    });
  }

  function bindCardButtons(container) {
    container.querySelectorAll('.wl-btn').forEach(btn => {
      btn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation();
        window.App?.openWatchlistModal({ id:btn.dataset.id, title:btn.dataset.title, cover:btn.dataset.cover, format:btn.dataset.format });
      });
    });
    container.querySelectorAll('.notif-btn').forEach(btn => {
      btn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation();
        window.Push?.toggleAnime(parseInt(btn.dataset.id));
      });
    });
  }

  // Re-render when timezone changes
  window.addEventListener('tzChanged', () => activeLayout !== 'card' ? renderGrid() : render());
  // Re-render on resize (switch between grid and accordion)
  let resizeTimer;
  window.addEventListener('resize', () => {
    if (activeLayout === 'card') return;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(renderGrid, 250);
  });

  // ── Helpers ───────────────────────────────────────────────
  function strtolower(s) { return s.toLowerCase(); }
  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
  function spinner(msg) {
    return `<div class="loading-state"><div class="spinner"></div><p>${msg}</p></div>`;
  }
  function errorState() {
    return `<div class="error-state"><i class="fa-solid fa-triangle-exclamation"></i>
      <p>Failed to load schedule. Please refresh.</p>
      <button class="btn btn-ghost" onclick="location.reload()">Retry</button></div>`;
  }

  return { init };
})();
