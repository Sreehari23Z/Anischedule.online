<?php
// ============================================================
//  Search Page
// ============================================================
require_once __DIR__ . '/config.php';
$q      = trim($_GET['q'] ?? '');
$page_title    = $q ? "\"$q\" Anime Search Results — AniSchedule" : 'Search Anime | Find Any Anime Series — AniSchedule';
$page_desc     = $q ? "Search results for \"$q\". Find anime schedules, episodes, streaming links and more on AniSchedule." : 'Search over 20,000 anime series. Find air schedules, streaming links, episode guides, scores and more.';
$page_keywords = $q ? "$q anime, $q watch online, $q episodes, $q schedule" : 'search anime, find anime, anime search, anime database, anime list';
// Tell Google not to index search result pages (avoids duplicate/low-quality content)
$meta_robots   = $q ? 'noindex, follow' : 'index, follow';
$active_nav = 'search';
include __DIR__ . '/includes/header.php';
?>

<div class="page-search">
  <div class="container">

    <!-- Search form -->
    <div class="search-hero">
      <form id="searchForm" action="<?= rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') ?>/search.php" method="get" class="search-form-big">
        <div class="search-input-wrap">
          <i class="fa-solid fa-magnifying-glass search-icon"></i>
          <input type="text" name="q" id="searchInput"
                 value="<?= htmlspecialchars($q) ?>"
                 placeholder="Search anime titles…"
                 autocomplete="off" autofocus>
          <button type="submit" class="btn btn-primary">Search</button>
        </div>
      </form>
    </div>

    <!-- Filters -->
    <div class="search-filters">
      <div class="filter-group">
        <label>Type</label>
        <div class="filter-chips" id="searchTypeFilter">
          <button class="chip active" data-type="">All</button>
          <button class="chip" data-type="tv">TV</button>
          <button class="chip" data-type="movie">Movie</button>
          <button class="chip" data-type="ova">OVA</button>
          <button class="chip" data-type="ona">ONA</button>
          <button class="chip" data-type="special">Special</button>
        </div>
      </div>
      <div class="filter-group">
        <label>Status</label>
        <div class="filter-chips" id="searchStatusFilter">
          <button class="chip active" data-status="">All</button>
          <button class="chip" data-status="airing">Airing</button>
          <button class="chip" data-status="complete">Completed</button>
          <button class="chip" data-status="upcoming">Upcoming</button>
        </div>
      </div>
    </div>

    <!-- Results -->
    <div id="searchResults" class="anime-grid">
      <?php if (!$q): ?>
      <div class="empty-state">
        <i class="fa-solid fa-magnifying-glass"></i>
        <p>Enter a title to search for anime.</p>
      </div>
      <?php endif; ?>
    </div>

    <!-- Load more -->
    <div id="loadMoreWrap" class="load-more-wrap" style="display:none">
      <button id="loadMoreBtn" class="btn btn-ghost">Load More <i class="fa-solid fa-chevron-down"></i></button>
    </div>

  </div>
</div>

<script>
(function() {
  let currentPage  = 1;
  let currentQuery = <?= json_encode($q) ?>;
  let currentType  = '';
  let currentStatus = '';
  let hasNext      = false;

  function fetchResults(reset = true) {
    if (reset) currentPage = 1;
    const q = document.getElementById('searchInput').value.trim();
    if (q.length < 1) return;

    currentQuery = q;
    const grid = document.getElementById('searchResults');
    if (reset) {
      grid.innerHTML = '<div class="loading-state"><div class="spinner"></div><p>Searching…</p></div>';
    }

    const params = new URLSearchParams({
      q, page: currentPage, type: currentType, status: currentStatus
    });

    fetch(`${window.SITE.base}/api/search.php?${params}`)
      .then(r => r.json())
      .then(d => {
        if (!d.ok) throw new Error(d.error);
        hasNext = d.has_next;
        document.getElementById('loadMoreWrap').style.display = hasNext ? 'flex' : 'none';
        if (reset) grid.innerHTML = '';
        if (!d.anime.length && reset) {
          grid.innerHTML = '<div class="empty-state"><i class="fa-solid fa-circle-xmark"></i><p>No results found for "' + escHtml(q) + '".</p></div>';
          return;
        }
        d.anime.forEach(a => {
          grid.insertAdjacentHTML('beforeend', `
            <article class="anime-card" data-id="${a.id}">
              <a href="${(window.SITE?.base||'')}${a.url}" class="card-cover-link">
                <div class="card-cover-wrap">
                  <img src="${a.cover}" alt="${escHtml(a.title_en)}" class="card-cover" loading="lazy">
                  <div class="card-overlay">
                    <div class="card-score">${a.score ? '★ '+a.score : 'N/A'}</div>
                    <div class="card-actions">
                      <button class="card-action-btn wl-btn"
                        data-id="${a.id}" data-title="${escHtml(a.title_en)}"
                        data-cover="${a.cover}" data-format="${a.type}"
                        title="Add to watchlist"><i class="fa-solid fa-plus"></i></button>
                    </div>
                  </div>
                </div>
              </a>
              <div class="card-info">
                <h3 class="card-title"><a href="${(window.SITE?.base||'')}${a.url}">${escHtml(a.title_en)}</a></h3>
                <div class="card-meta">
                  <span class="badge badge-type">${a.type}</span>
                  ${a.episodes ? `<span class="card-ep">${a.episodes} eps</span>` : ''}
                  ${a.year ? `<span class="card-year">${a.year}</span>` : ''}
                  ${a.airing ? '<span class="badge badge-airing">Airing</span>' : ''}
                </div>
                <p class="card-genres">${(a.genres||[]).slice(0,3).join(' · ')}</p>
              </div>
            </article>
          `);
        });
        // Bind watchlist buttons
        grid.querySelectorAll('.wl-btn').forEach(b => b.addEventListener('click', e => {
          e.preventDefault();
          window.App.openWatchlistModal({ id: b.dataset.id, title: b.dataset.title, cover: b.dataset.cover, format: b.dataset.format });
        }));
      })
      .catch(() => {
        grid.innerHTML = '<div class="error-state"><i class="fa-solid fa-triangle-exclamation"></i><p>Search failed. Try again.</p></div>';
      });
  }

  // Auto-search on input with debounce
  let debounceTimer;
  document.getElementById('searchInput').addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => fetchResults(true), 400);
  });

  document.getElementById('searchForm').addEventListener('submit', e => {
    e.preventDefault();
    fetchResults(true);
    history.replaceState({}, '', (window.SITE.base||'') + '/search.php?q=' + encodeURIComponent(document.getElementById('searchInput').value.trim()));
  });

  // Filter chips
  document.getElementById('searchTypeFilter').addEventListener('click', e => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    document.querySelectorAll('#searchTypeFilter .chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    currentType = chip.dataset.type;
    fetchResults(true);
  });

  document.getElementById('searchStatusFilter').addEventListener('click', e => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    document.querySelectorAll('#searchStatusFilter .chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    currentStatus = chip.dataset.status;
    fetchResults(true);
  });

  document.getElementById('loadMoreBtn').addEventListener('click', () => {
    currentPage++;
    fetchResults(false);
  });

  // Initial search if query is present
  if (currentQuery) fetchResults(true);

  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
