<?php
// ============================================================
//  Top Anime — /top.php
//  Tabs: Top Airing / Top All Time / Most Popular
//  25 per page, paginated
// ============================================================
require_once __DIR__ . '/config.php';
$page_title    = 'Top Anime ' . date('Y') . ' | Best Rated & Most Popular — AniSchedule';
$page_desc     = 'Discover the best anime of all time. Browse top-rated, highest scored, and most popular anime series ranked by fans worldwide. Updated daily.';
$page_keywords = 'top anime, best anime, highest rated anime, most popular anime, top anime list, anime rankings, best anime series, top rated anime ' . date('Y');
$active_nav = 'top';
include __DIR__ . '/includes/header.php';
?>

<div class="page-top">

  <!-- ── Hero ───────────────────────────────────────────── -->
  <section class="upcoming-hero">
    <div class="upcoming-hero-inner">
      <h1 class="hero-title">Top <span class="gradient-text">Anime</span></h1>
      <p class="hero-sub">The best-rated and most-loved anime, sourced from MyAnimeList.</p>
    </div>
  </section>

  <!-- ── Tabs ───────────────────────────────────────────── -->
  <div class="container" style="padding-top:1.5rem">
    <div class="top-tabs" id="topTabs">
      <button class="top-tab active" data-filter="airing">🔴 Top Airing</button>
      <button class="top-tab" data-filter="">⭐ Top All Time</button>
      <button class="top-tab" data-filter="bypopularity">🔥 Most Popular</button>
    </div>
  </div>

  <!-- ── List ───────────────────────────────────────────── -->
  <div class="container" style="padding-top:1.5rem;padding-bottom:2rem">
    <div id="topList" class="top-list">
      <div class="loading-state"><div class="spinner"></div><p>Loading…</p></div>
    </div>
    <!-- Pagination -->
    <div id="topPagination" class="pagination"></div>
  </div>

</div>

<script>
(function(){
  const base    = window.SITE?.base ?? '';
  const list    = document.getElementById('topList');
  const pager   = document.getElementById('topPagination');
  const tabs    = document.querySelectorAll('.top-tab');
  let   filter  = 'airing';
  let   page    = 1;

  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    filter = t.dataset.filter;
    page   = 1;
    load();
  }));

  function load() {
    list.innerHTML  = '<div class="loading-state"><div class="spinner"></div><p>Loading…</p></div>';
    pager.innerHTML = '';
    const url = `${base}/api/top.php?filter=${encodeURIComponent(filter)}&page=${page}`;
    fetch(url)
      .then(r => r.json())
      .then(json => {
        if (!json.ok || !json.data?.length) {
          list.innerHTML = '<div class="empty-state"><i class="fa-solid fa-list-ol"></i><p>No data.</p></div>';
          return;
        }
        const offset = (page - 1) * 25;
        list.innerHTML = json.data.map((a, i) => buildRow(a, offset + i + 1)).join('');
        renderPager(json.pagination);
      })
      .catch(() => {
        list.innerHTML = '<div class="error-state"><i class="fa-solid fa-triangle-exclamation"></i><p>Failed to load.</p></div>';
      });
  }

  function buildRow(a, rank) {
    const title   = a.title_en || a.title;
    const cover   = a.cover || '';
    const genres  = (a.genres || []).slice(0,3).join(' · ');
    const synopsis = (a.synopsis || '').slice(0, 180) + (a.synopsis?.length > 180 ? '…' : '');
    return `
      <div class="top-row">
        <div class="rank-badge">#${rank}</div>
        <a href="${base}/anime.php?id=${a.id}" class="top-cover-link">
          ${cover ? `<img src="${cover}" alt="${escHtml(title)}" class="top-cover" loading="lazy">` : '<div class="top-cover-placeholder"></div>'}
        </a>
        <div class="top-info">
          <div class="top-title"><a href="${base}/anime.php?id=${a.id}">${escHtml(title)}</a></div>
          <div class="top-meta">
            <span class="badge badge-type">${a.type || 'TV'}</span>
            ${a.episodes ? `<span class="card-ep">${a.episodes} eps</span>` : ''}
            ${a.score    ? `<span class="score-pill"><i class="fa-solid fa-star"></i> ${a.score}</span>` : ''}
            ${a.members  ? `<span class="card-ep">${fmtNum(a.members)} members</span>` : ''}
          </div>
          ${genres ? `<div class="top-genres">${escHtml(genres)}</div>` : ''}
          ${synopsis ? `<p class="top-synopsis">${escHtml(synopsis)}</p>` : ''}
        </div>
      </div>`;
  }

  function renderPager(pagination) {
    if (!pagination) return;
    const total  = pagination.last_visible_page || 1;
    if (total <= 1) return;
    let html = '';
    if (page > 1) html += `<button class="page-btn" data-p="${page-1}">‹ Prev</button>`;
    const start = Math.max(1, page - 2);
    const end   = Math.min(total, page + 2);
    for (let i = start; i <= end; i++) {
      html += `<button class="page-btn ${i === page ? 'active' : ''}" data-p="${i}">${i}</button>`;
    }
    if (page < total) html += `<button class="page-btn" data-p="${page+1}">Next ›</button>`;
    pager.innerHTML = html;
    pager.querySelectorAll('.page-btn').forEach(b => b.addEventListener('click', () => {
      page = parseInt(b.dataset.p);
      load();
      window.scrollTo({top:0, behavior:'smooth'});
    }));
  }

  function fmtNum(n) {
    if (n >= 1000000) return (n/1000000).toFixed(1)+'M';
    if (n >= 1000) return (n/1000).toFixed(0)+'K';
    return n;
  }

  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  load();
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
