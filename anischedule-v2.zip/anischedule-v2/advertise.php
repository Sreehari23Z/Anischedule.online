<?php
require_once __DIR__ . '/config.php';
$page_title = 'Advertise — ' . SITE_NAME;
$page_desc  = 'Reach millions of anime fans. Advertise on AniSchedule and connect with a passionate, engaged audience.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">

  <div class="legal-hero">
    <i class="fa-solid fa-bullhorn legal-hero-icon"></i>
    <h1>Advertise on AniSchedule</h1>
    <p>Reach a passionate, engaged anime audience at the moment they're deciding what to watch.</p>
  </div>

  <!-- Audience stats -->
  <div class="adv-stats-row">
    <div class="adv-stat">
      <span class="adv-stat-num">500K+</span>
      <span class="adv-stat-label">Monthly visitors</span>
    </div>
    <div class="adv-stat">
      <span class="adv-stat-num">2.4M+</span>
      <span class="adv-stat-label">Monthly page views</span>
    </div>
    <div class="adv-stat">
      <span class="adv-stat-num">72%</span>
      <span class="adv-stat-label">18–34 age group</span>
    </div>
    <div class="adv-stat">
      <span class="adv-stat-num">Global</span>
      <span class="adv-stat-label">Audience reach</span>
    </div>
  </div>

  <!-- Why advertise -->
  <div class="adv-section">
    <h2 class="about-section-title">Why Advertise With Us</h2>
    <div class="adv-why-grid">
      <div class="adv-why-card">
        <i class="fa-solid fa-users"></i>
        <h3>Highly Targeted</h3>
        <p>Our audience is 100% anime fans — actively engaged with seasonal content, streaming services, manga, and merchandise. Zero wasted impressions.</p>
      </div>
      <div class="adv-why-card">
        <i class="fa-solid fa-calendar-check"></i>
        <h3>High Intent Moments</h3>
        <p>Users visit AniSchedule to decide what to watch next. It's the perfect moment to surface your streaming platform, product, or promotion.</p>
      </div>
      <div class="adv-why-card">
        <i class="fa-solid fa-globe"></i>
        <h3>Global Reach</h3>
        <p>Traffic from Japan, US, UK, Australia, Canada, Germany, France, Brazil, and more — with strong representation across Asia-Pacific.</p>
      </div>
      <div class="adv-why-card">
        <i class="fa-solid fa-chart-line"></i>
        <h3>Seasonal Spikes</h3>
        <p>Traffic surges at season starts (January, April, July, October) when new anime premieres drive massive interest. Perfect timing for seasonal campaigns.</p>
      </div>
    </div>
  </div>

  <!-- Ad formats -->
  <div class="adv-section">
    <h2 class="about-section-title">Ad Formats Available</h2>
    <div class="adv-formats">

      <div class="adv-format-card">
        <div class="adv-format-tag">Display</div>
        <h3>Banner Ads</h3>
        <p>Standard IAB display units across schedule, seasonal, and detail pages. Sizes: 728×90 (leaderboard), 300×250 (medium rectangle), 160×600 (wide skyscraper).</p>
        <ul>
          <li>Desktop and mobile placements</li>
          <li>High-visibility above-the-fold slots available</li>
          <li>Supports static images and HTML5 animated creatives</li>
        </ul>
      </div>

      <div class="adv-format-card">
        <div class="adv-format-tag">Sponsored</div>
        <h3>Sponsored Seasonal Spotlight</h3>
        <p>Feature your anime title, streaming service, or product at the top of a seasonal chart page for an entire season (3 months).</p>
        <ul>
          <li>Premium placement above organic results</li>
          <li>Custom cover art, title, and CTA button</li>
          <li>Clearly labelled "Sponsored" for transparency</li>
        </ul>
      </div>

      <div class="adv-format-card">
        <div class="adv-format-tag">Newsletter</div>
        <h3>Newsletter Sponsorship</h3>
        <p>Reach our most engaged users directly in their inbox through our weekly new-season announcement email.</p>
        <ul>
          <li>Dedicated placement in weekly digest</li>
          <li>Logo, tagline, and link to your destination</li>
          <li>Typically 30–40% open rate among subscribers</li>
        </ul>
      </div>

      <div class="adv-format-card">
        <div class="adv-format-tag">Affiliate</div>
        <h3>Affiliate &amp; CPA</h3>
        <p>Performance-based partnerships for streaming services, merchandise shops, VPN services, and anime subscription boxes.</p>
        <ul>
          <li>CPC, CPM, and CPA models available</li>
          <li>Deep-linked to relevant anime pages</li>
          <li>Monthly reporting and analytics access</li>
        </ul>
      </div>

    </div>
  </div>

  <!-- Who's a good fit -->
  <div class="adv-section">
    <h2 class="about-section-title">Who Advertises With Us</h2>
    <div class="adv-fit-list">
      <div class="adv-fit-item"><i class="fa-solid fa-play"></i> Anime streaming platforms (Crunchyroll, HIDIVE, Netflix, etc.)</div>
      <div class="adv-fit-item"><i class="fa-solid fa-box"></i> Anime merchandise and figure retailers</div>
      <div class="adv-fit-item"><i class="fa-solid fa-book-open"></i> Manga subscription services and publishers</div>
      <div class="adv-fit-item"><i class="fa-solid fa-shield"></i> VPN and privacy services</div>
      <div class="adv-fit-item"><i class="fa-solid fa-gamepad"></i> Gaming and mobile app publishers</div>
      <div class="adv-fit-item"><i class="fa-solid fa-headphones"></i> Anime music and soundtrack platforms</div>
      <div class="adv-fit-item"><i class="fa-solid fa-shirt"></i> Anime fashion and cosplay brands</div>
      <div class="adv-fit-item"><i class="fa-solid fa-star"></i> Anime conventions and events</div>
    </div>
  </div>

  <!-- CTA -->
  <div class="about-cta">
    <i class="fa-solid fa-paper-plane"></i>
    <div>
      <h3>Request a Media Kit</h3>
      <p>Get full audience demographics, traffic data, pricing, and creative specs. We'll reply within 2 business days.</p>
    </div>
    <a href="<?= $base ?>/contact.php?reason=Advertising" class="btn btn-primary">Get in Touch</a>
  </div>

  <p class="adv-note">All advertising on AniSchedule is clearly labelled. We do not accept ads for adult content, gambling, or crypto/NFT products. We reserve the right to decline any campaign that conflicts with our community values.</p>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
