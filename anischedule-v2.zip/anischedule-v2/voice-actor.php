<?php
// ============================================================
//  Voice Actor Profile — /voice-actor.php?id=MAL_PERSON_ID
// ============================================================
require_once __DIR__ . '/config.php';

$person_id = intval($_GET['id'] ?? 0);

if ($person_id <= 0) {
    header('Location: ' . ($base ?? '') . '/characters.php');
    exit;
}

require_once __DIR__ . '/api/anilist.php';
$person = jikan_person($person_id);

if ($person) {
    $pname       = $person['name'] ?? 'Unknown';
    $given_name  = $person['given_name'] ?? '';
    $family_name = $person['family_name'] ?? '';
    $birthday    = $person['birthday'] ?? '';
    $nationality = $person['nationality'] ?? '';
    $about       = $person['about'] ?? '';
    $image       = $person['images']['jpg']['image_url'] ?? '';
    $website     = $person['website_url'] ?? '';
    $favorites   = $person['favorites'] ?? 0;
    $voices      = $person['voices'] ?? [];
    $anime       = $person['anime'] ?? [];

    $birthday_fmt = '';
    if ($birthday) {
        try {
            $dt = new DateTime($birthday);
            $birthday_fmt = $dt->format('F j, Y');
        } catch(Exception $e) {
            $birthday_fmt = $birthday;
        }
    }

    $page_title = $pname . ' — Voice Actor | ' . SITE_NAME;
    $page_desc  = "$pname is a voice actor" . ($nationality ? " from $nationality" : '') . ". Browse their character roles and anime appearances on " . SITE_NAME . ".";
} else {
    $page_title = 'Voice Actor Not Found — ' . SITE_NAME;
    $page_desc  = 'Voice actor data unavailable.';
    $pname = $image = $given_name = $family_name = '';
    $birthday = $birthday_fmt = $nationality = $about = $website = '';
    $favorites = 0;
    $voices = $anime = [];
}

$active_nav = 'character';
include __DIR__ . '/includes/header.php';
?>

<?php if (!$person): ?>
<div class="container" style="padding:5rem 1rem;text-align:center">
  <i class="fa-solid fa-microphone-slash" style="font-size:3rem;color:var(--danger);margin-bottom:1rem;display:block"></i>
  <h2>Voice Actor Not Found</h2>
  <p style="color:var(--text3);margin:.75rem 0 1.5rem">Could not load data for person ID <?= $person_id ?>.</p>
  <a href="<?= $base ?>/characters.php" class="btn btn-primary"><i class="fa-solid fa-arrow-left"></i> Browse Characters</a>
</div>
<?php else: ?>

<div class="page-va-detail">

  <!-- ── Hero ─────────────────────────────────────────────── -->
  <section class="va-hero">
    <?php if ($image): ?>
      <div class="va-hero-bg" style="background-image:url('<?= htmlspecialchars($image) ?>')"></div>
    <?php endif; ?>
    <div class="va-hero-overlay"></div>

    <div class="container">
      <div class="va-hero-inner">

        <!-- Photo -->
        <div class="va-photo-wrap">
          <?php if ($image): ?>
            <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($pname) ?>" class="va-photo">
          <?php else: ?>
            <div class="va-photo va-photo-ph"><i class="fa-solid fa-microphone"></i></div>
          <?php endif; ?>
        </div>

        <!-- Info -->
        <div class="va-hero-info">
          <nav class="char-detail-breadcrumb">
            <a href="<?= $base ?>/characters.php">Characters</a>
            <i class="fa-solid fa-chevron-right" style="font-size:.6rem;opacity:.5"></i>
            <span>Voice Actor</span>
            <i class="fa-solid fa-chevron-right" style="font-size:.6rem;opacity:.5"></i>
            <span><?= htmlspecialchars($pname) ?></span>
          </nav>

          <h1 class="va-name"><?= htmlspecialchars($pname) ?></h1>
          <?php if ($given_name || $family_name): ?>
            <p class="va-name-native"><?= htmlspecialchars(trim("$given_name $family_name")) ?></p>
          <?php endif; ?>

          <div class="va-meta-chips">
            <?php if ($nationality): ?>
              <span class="va-chip"><i class="fa-solid fa-flag"></i> <?= htmlspecialchars($nationality) ?></span>
            <?php endif; ?>
            <?php if ($birthday_fmt): ?>
              <span class="va-chip"><i class="fa-solid fa-cake-candles"></i> <?= htmlspecialchars($birthday_fmt) ?></span>
            <?php endif; ?>
            <span class="va-chip"><i class="fa-solid fa-heart"></i> <?= number_format($favorites) ?> favourites</span>
            <?php if ($voices): ?>
              <span class="va-chip"><i class="fa-solid fa-user"></i> <?= count($voices) ?> character role<?= count($voices)!==1?'s':'' ?></span>
            <?php endif; ?>
          </div>

          <div class="va-actions" style="margin-top:1.2rem">
            <a href="https://myanimelist.net/people/<?= $person_id ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> View on MAL
            </a>
            <?php if ($website): ?>
              <a href="<?= htmlspecialchars($website) ?>" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">
                <i class="fa-solid fa-globe"></i> Website
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── Tabs ──────────────────────────────────────────────── -->
  <div class="char-tabs-bar">
    <div class="container">
      <div class="char-tabs" role="tablist">
        <button class="char-tab active" data-tab="roles">Character Roles <?php if($voices): ?><span class="char-tab-count"><?= count($voices) ?></span><?php endif; ?></button>
        <?php if ($about): ?>
          <button class="char-tab" data-tab="bio">Biography</button>
        <?php endif; ?>
        <?php if ($anime): ?>
          <button class="char-tab" data-tab="anime">Anime <?php if($anime): ?><span class="char-tab-count"><?= count($anime) ?></span><?php endif; ?></button>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="container" style="padding-top:1.5rem;padding-bottom:3rem">

    <!-- CHARACTER ROLES -->
    <div class="char-tab-panel active" id="tab-roles" role="tabpanel">
      <h3 class="char-box-heading" style="margin-bottom:1.25rem">
        <i class="fa-solid fa-masks-theater"></i> Character Roles
      </h3>
      <?php if (empty($voices)): ?>
        <p style="color:var(--text3);font-style:italic">No character role data available.</p>
      <?php else: ?>
        <div class="va-roles-grid">
          <?php foreach ($voices as $role):
            $c    = $role['character'] ?? [];
            $lang = $role['role']      ?? '';
            $a    = $role['anime']     ?? [];
            $cid  = $c['mal_id'] ?? 0;
            $cimg = $c['images']['jpg']['image_url'] ?? '';
          ?>
          <div class="va-role-card">
            <a href="<?= $base ?>/character.php?id=<?= $cid ?>" class="va-role-char">
              <img src="<?= htmlspecialchars($cimg) ?>"
                   alt="<?= htmlspecialchars($c['name'] ?? '') ?>"
                   onerror="this.src='<?= $base ?>/assets/img/placeholder-char.svg'"
                   class="va-role-char-img">
              <div class="va-role-char-info">
                <span class="va-role-char-name"><?= htmlspecialchars($c['name'] ?? '') ?></span>
                <span class="va-role-type"><?= htmlspecialchars($lang) ?></span>
              </div>
            </a>
            <?php if ($a): ?>
            <a href="<?= $base ?>/anime.php?id=<?= $a['mal_id'] ?>" class="va-role-anime">
              <img src="<?= htmlspecialchars($a['images']['jpg']['image_url'] ?? '') ?>"
                   alt="<?= htmlspecialchars($a['title'] ?? '') ?>"
                   onerror="this.src='<?= $base ?>/assets/img/placeholder.svg'"
                   class="va-role-anime-img">
              <span class="va-role-anime-title"><?= htmlspecialchars($a['title'] ?? '') ?></span>
            </a>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- BIOGRAPHY -->
    <?php if ($about): ?>
    <div class="char-tab-panel" id="tab-bio" role="tabpanel">
      <div class="char-card-box">
        <h3 class="char-box-heading"><i class="fa-solid fa-id-card"></i> Biography</h3>
        <div class="char-about-body">
          <?= nl2br(htmlspecialchars(mb_substr($about, 0, 1500))) ?>
          <?php if (mb_strlen($about) > 1500): ?>
            <div id="vaBioExtra" style="display:none"><?= nl2br(htmlspecialchars(mb_substr($about, 1500))) ?></div>
            <button class="char-read-more-btn" id="vaBioReadMore">
              Read more <i class="fa-solid fa-chevron-down"></i>
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- ANIME STAFF -->
    <?php if ($anime): ?>
    <div class="char-tab-panel" id="tab-anime" role="tabpanel">
      <h3 class="char-box-heading" style="margin-bottom:1.25rem">
        <i class="fa-solid fa-film"></i> Anime Filmography
      </h3>
      <div class="char-appear-list">
        <?php foreach (array_slice($anime, 0, 40) as $entry):
          $a    = $entry['anime']    ?? [];
          $pos  = $entry['position'] ?? '';
        ?>
        <a href="<?= $base ?>/anime.php?id=<?= $a['mal_id'] ?>" class="char-appear-row">
          <img src="<?= htmlspecialchars($a['images']['jpg']['image_url'] ?? '') ?>"
               alt="<?= htmlspecialchars($a['title'] ?? '') ?>"
               onerror="this.src='<?= $base ?>/assets/img/placeholder.svg'"
               class="char-appear-img">
          <div class="char-appear-info">
            <span class="char-appear-title"><?= htmlspecialchars($a['title'] ?? '') ?></span>
            <span class="char-appear-role"><?= htmlspecialchars($pos) ?></span>
          </div>
          <i class="fa-solid fa-chevron-right char-appear-arrow"></i>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div><!-- /container -->
</div><!-- /page-va-detail -->

<script>
(function(){
  // Tab switching
  const tabs   = document.querySelectorAll('.char-tab');
  const panels = document.querySelectorAll('.char-tab-panel');
  tabs.forEach(btn => {
    btn.addEventListener('click', () => {
      tabs.forEach(b => b.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const target = document.getElementById('tab-' + btn.dataset.tab);
      if (target) target.classList.add('active');
    });
  });

  // Biography read more
  const bioBtn = document.getElementById('vaBioReadMore');
  if (bioBtn) {
    bioBtn.addEventListener('click', () => {
      const extra = document.getElementById('vaBioExtra');
      const open  = extra.style.display !== 'none';
      extra.style.display = open ? 'none' : 'block';
      bioBtn.innerHTML = open
        ? 'Read more <i class="fa-solid fa-chevron-down"></i>'
        : 'Show less <i class="fa-solid fa-chevron-up"></i>';
    });
  }
})();
</script>

<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
