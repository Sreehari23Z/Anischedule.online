<?php
// ============================================================
//  Database connection + helpers
// ============================================================
require_once __DIR__ . '/../config.php';

function db(): PDO {
    static $pdo = null;
    // Skip immediately if credentials are still the placeholder defaults
    if (DB_USER === 'your_db_user' || DB_PASS === 'your_db_password') {
        throw new \RuntimeException('MySQL not configured — using file cache');
    }
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET . ';connect_timeout=2';
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }
    return $pdo;
}

// ── Cache helpers ──────────────────────────────────────────

// File cache directory — used as fallback when MySQL is unavailable
function _file_cache_path(string $key): string {
    $dir = __DIR__ . '/../cache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir . '/' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key) . '.json';
}

function cache_get(string $key): ?array {
    // 1. Try MySQL first
    try {
        $stmt = db()->prepare('SELECT data FROM api_cache WHERE cache_key = ? AND expires_at > NOW()');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        if ($row) return json_decode($row['data'], true);
    } catch (Exception $e) { /* fall through to file cache */ }

    // 2. File cache fallback
    $path = _file_cache_path($key);
    if (file_exists($path)) {
        $raw = @file_get_contents($path);
        if ($raw) {
            $wrapper = json_decode($raw, true);
            if ($wrapper && isset($wrapper['expires_at']) && $wrapper['expires_at'] > time()) {
                return $wrapper['data'];
            }
        }
    }
    return null;
}

function cache_set(string $key, array $data, int $ttl = 3600): void {
    // 1. Try MySQL
    $mysql_ok = false;
    try {
        $json = json_encode($data);
        $stmt = db()->prepare(
            'INSERT INTO api_cache (cache_key, data, expires_at)
             VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))
             ON DUPLICATE KEY UPDATE data = VALUES(data), expires_at = VALUES(expires_at)'
        );
        $stmt->execute([$key, $json, $ttl]);
        $mysql_ok = true;
    } catch (Exception $e) { /* fall through */ }

    // 2. File cache fallback (always write so we have it on disk)
    $path = _file_cache_path($key);
    $wrapper = json_encode(['expires_at' => time() + $ttl, 'data' => $data]);
    @file_put_contents($path, $wrapper, LOCK_EX);
}

function cache_delete(string $key): void {
    try {
        db()->prepare('DELETE FROM api_cache WHERE cache_key = ?')->execute([$key]);
    } catch (Exception $e) {}
    // Also delete file cache
    $path = _file_cache_path($key);
    if (file_exists($path)) @unlink($path);
}
