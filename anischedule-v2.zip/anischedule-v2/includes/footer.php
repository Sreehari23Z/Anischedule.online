<?php
// ============================================================
//  Shared Footer — include at bottom of every page
//  $base is set in header.php and available here
// ============================================================
$base = $base ?? '';
?>
</main><!-- /main-content -->

<!-- ── Footer ──────────────────────────────────────────── -->
<footer class="site-footer site-footer-slim">

  <!-- Footer nav links -->
  <div class="footer-nav-row">
    <nav class="footer-nav-links" aria-label="Footer navigation">
      <a href="<?= $base ?>/about.php">About</a>
      <a href="<?= $base ?>/contact.php">Contact</a>
      <a href="<?= $base ?>/advertise.php">Advertise</a>
      <a href="<?= $base ?>/api-docs.php">API</a>
      <a href="<?= $base ?>/rss.php"><i class="fa-solid fa-rss"></i> RSS</a>
      <span class="footer-nav-divider"></span>
      <a href="<?= $base ?>/privacy.php">Privacy</a>
      <a href="<?= $base ?>/terms.php">Terms</a>
      <a href="<?= $base ?>/copyright.php">Copyright</a>
    </nav>
  </div>

  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
    <p class="footer-disclaimer">Anime images and titles are property of their respective owners. Schedule data sourced from <a href="https://myanimelist.net" target="_blank" rel="noopener">MyAnimeList</a> and <a href="https://anilist.co" target="_blank" rel="noopener">AniList</a>.</p>
  </div>
</footer>

<!-- ── Toast notifications ──────────────────────────────── -->
<div id="toastContainer" class="toast-container"></div>

<!-- ── Watchlist modal ──────────────────────────────────── -->
<div id="watchlistModal" class="modal" role="dialog" aria-modal="true" aria-labelledby="wlModalTitle">
  <div class="modal-overlay" id="watchlistModalOverlay"></div>
  <div class="modal-box">
    <div class="modal-header">
      <h3 id="wlModalTitle">Add to Watchlist</h3>
      <button class="modal-close" id="wlModalClose" aria-label="Close">&times;</button>
    </div>
    <div class="modal-body" id="wlModalBody">
      <p>Loading…</p>
    </div>
  </div>
</div>

<!-- ── Scripts ──────────────────────────────────────────── -->
<script>
  window.SITE = {
    base: '<?= $base ?>',
    url:  '<?= SITE_URL ?>',
    user: <?= auth_user() ? json_encode(['id' => auth_user()['id'], 'username' => auth_user()['username']]) : 'null' ?>,
    vapidPublic: '<?= VAPID_PUBLIC ?>',
    csrf: '<?= csrf_token() ?>'
  };
</script>
<script src="<?= $base . asset_ver('assets/js/app.js') ?>"></script>
<script src="<?= $base . asset_ver('assets/js/countdown.js') ?>"></script>
<script src="<?= $base . asset_ver('assets/js/push.js') ?>"></script>
<script src="<?= $base . asset_ver('assets/js/notify.js') ?>"></script>
<script>
// "More" nav dropdown toggle
(function(){
  const btn      = document.getElementById('navMoreBtn');
  const dropdown = document.getElementById('navMoreDropdown');
  if (!btn || !dropdown) return;
  btn.addEventListener('click', function(e) {
    e.stopPropagation();
    const open = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', !open);
    dropdown.classList.toggle('open', !open);
  });
  document.addEventListener('click', function() {
    btn.setAttribute('aria-expanded', 'false');
    dropdown.classList.remove('open');
  });
})();
</script>
</body>
</html>
