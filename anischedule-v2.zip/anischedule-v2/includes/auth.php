<?php
// ============================================================
//  Authentication helpers
// ============================================================
require_once __DIR__ . '/db.php';

function session_start_safe(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function auth_user(): ?array {
    session_start_safe();
    if (!isset($_SESSION['user_id'])) return null;
    try {
        $stmt = db()->prepare('SELECT id, username, email, avatar, timezone, theme FROM users WHERE id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch() ?: null;
    } catch (Exception $e) { return null; }
}

function auth_login(string $email, string $password): array {
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([strtolower(trim($email))]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($password, $user['password'])) {
        return ['ok' => false, 'error' => 'Invalid email or password.'];
    }
    session_start_safe();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    return ['ok' => true, 'user' => $user];
}

function auth_register(string $username, string $email, string $password): array {
    $username = trim($username);
    $email    = strtolower(trim($email));

    if (strlen($username) < 3 || strlen($username) > 50) {
        return ['ok' => false, 'error' => 'Username must be 3–50 characters.'];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'Invalid email address.'];
    }
    if (strlen($password) < 8) {
        return ['ok' => false, 'error' => 'Password must be at least 8 characters.'];
    }

    // Check duplicates
    $stmt = db()->prepare('SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1');
    $stmt->execute([$email, $username]);
    if ($stmt->fetch()) {
        return ['ok' => false, 'error' => 'Username or email already taken.'];
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = db()->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    $stmt->execute([$username, $email, $hash]);
    $id = (int) db()->lastInsertId();

    session_start_safe();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    return ['ok' => true];
}

function auth_logout(): void {
    session_start_safe();
    $_SESSION = [];
    session_destroy();
}

function csrf_token(): string {
    session_start_safe();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_verify(string $token): bool {
    session_start_safe();
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}
