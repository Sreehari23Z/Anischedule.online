<?php
// ============================================================
//  Shared Header  –  include at top of every page
//  $page_title, $page_desc, $body_class should be set before including
// ============================================================
require_once __DIR__ . '/../includes/auth.php';
$user       = auth_user();
$page_title = $page_title ?? SITE_NAME;
$page_desc  = $page_desc  ?? SITE_DESC;
$body_class = $body_class ?? '';
$csrf       = csrf_token();

// Base path for assets/links.
// Auto-detects subdirectory installs (e.g. /anischedule/) via DOCUMENT_ROOT diff.
// Falls back to '' (root) which is correct for PHP built-in server and most setups.
$base = '';
try {
    $sf = str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME'] ?? '');
    $dr = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
    if ($sf && $dr && str_starts_with($sf, $dr)) {
        $rel = substr($sf, strlen($dr));
        $dir = str_replace('\\', '/', dirname($rel));
        if ($dir !== '/' && $dir !== '.' && $dir !== '') {
            $base = rtrim($dir, '/');
        }
    }
} catch (\Throwable $e) {
    $base = '';
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= $user ? htmlspecialchars($user['theme']) : 'dark' ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title) ?></title>
  <meta name="description" content="<?= htmlspecialchars($page_desc) ?>">
  <meta name="keywords"    content="<?= htmlspecialchars($page_keywords ?? 'anime schedule, airing anime, anime timetable, seasonal anime, anime air times, anime countdown, weekly anime schedule, new anime episodes') ?>">
  <meta name="theme-color" content="#6366f1">
  <meta name="robots"      content="<?= htmlspecialchars($meta_robots ?? 'index, follow') ?>">
  <meta name="author"      content="AniSchedule">

  <!-- Canonical URL -->
  <?php
    $canonical_url = $page_canonical ?? (SITE_URL . strtok($_SERVER['REQUEST_URI'], '?'));
  ?>
  <link rel="canonical" href="<?= htmlspecialchars($canonical_url) ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/png" sizes="32x32" href="<?= $base ?>/assets/img/logo.png?v=3">
  <link rel="icon" type="image/png" sizes="16x16" href="<?= $base ?>/assets/img/logo.png?v=3">
  <link rel="apple-touch-icon"                    href="<?= $base ?>/assets/img/logo.png?v=2">
  <link rel="shortcut icon"      type="image/png" href="<?= $base ?>/assets/img/logo.png?v=2">

  <!-- Open Graph -->
  <meta property="og:title"       content="<?= htmlspecialchars($page_title) ?>">
  <meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
  <meta property="og:type"        content="<?= $og_type ?? 'website' ?>">
  <meta property="og:url"         content="<?= htmlspecialchars($canonical_url) ?>">
  <meta property="og:image"       content="<?= htmlspecialchars($og_image ?? SITE_URL . '/assets/img/logo.png') ?>">
  <meta property="og:image:width"  content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:site_name"   content="AniSchedule">
  <meta property="og:locale"      content="en_US">

  <!-- Twitter Card -->
  <meta name="twitter:card"        content="summary_large_image">
  <meta name="twitter:title"       content="<?= htmlspecialchars($page_title) ?>">
  <meta name="twitter:description" content="<?= htmlspecialchars($page_desc) ?>">
  <meta name="twitter:image"       content="<?= htmlspecialchars($og_image ?? SITE_URL . '/assets/img/logo.png') ?>">
  <meta name="twitter:site"        content="@AniSchedule">

  <!-- PWA -->
  <link rel="manifest" href="<?= $base ?>/manifest.json">

  <!-- DNS prefetch for external resources -->
  <link rel="preconnect" href="https://api.jikan.moe">
  <link rel="preconnect" href="https://cdn.myanimelist.net">
  <link rel="dns-prefetch" href="https://graphql.anilist.co">

  <!-- JSON-LD: WebSite + Sitelinks Searchbox -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "AniSchedule",
    "url": "<?= SITE_URL ?>",
    "description": "Free anime airing schedule with timezone support, countdown timers, seasonal charts, and Donghua listings.",
    "potentialAction": {
      "@type": "SearchAction",
      "target": {
        "@type": "EntryPoint",
        "urlTemplate": "<?= SITE_URL ?>/search.php?q={search_term_string}"
      },
      "query-input": "required name=search_term_string"
    }
  }
  </script>
  <?php if (!empty($json_ld)): ?>
  <script type="application/ld+json"><?= $json_ld ?></script>
  <?php endif; ?>

  <!-- Fonts + Icons (local copy — no CDN needed) -->
  <link rel="stylesheet" href="<?= $base . asset_ver('assets/css/fontawesome.min.css') ?>">
  <style>
    :root {
      --font: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
      --font-display: 'Outfit', 'Segoe UI', system-ui, -apple-system, sans-serif;
    }
  </style>

  <!-- Main stylesheet -->
  <link rel="stylesheet" href="<?= $base . asset_ver('assets/css/style.css') ?>">
  <!-- New feature styles (separate file to avoid truncation issue) -->
  <link rel="stylesheet" href="<?= $base . asset_ver('assets/css/features.css') ?>">

  <meta name="csrf-token" content="<?= $csrf ?>">
</head>
<body class="<?= htmlspecialchars($body_class) ?>">

<!-- ── Top Navigation ──────────────────────────────────── -->
<nav class="navbar" id="navbar">
  <div class="nav-container">

    <!-- Logo -->
    <a href="<?= $base ?>/" class="nav-logo">
      <img src="<?= $base ?>/assets/img/logo.png" alt="<?= SITE_NAME ?>" class="nav-logo-img">
      <span class="nav-logo-text"><?= SITE_NAME ?></span>
    </a>

    <!-- Desktop links -->
    <ul class="nav-links" id="navLinks">
      <li><a href="<?= $base ?>/" class="nav-link <?= $active_nav === 'schedule' ? 'active' : '' ?>">
        <i class="fa-solid fa-calendar-days"></i> Schedule
      </a></li>
      <li><a href="<?= $base ?>/upcoming.php" class="nav-link <?= $active_nav === 'upcoming' ? 'active' : '' ?>">
        <i class="fa-solid fa-rocket"></i> Upcoming
      </a></li>
      <li><a href="<?= $base ?>/top.php" class="nav-link <?= $active_nav === 'top' ? 'active' : '' ?>">
        <i class="fa-solid fa-ranking-star"></i> Top Anime
      </a></li>
      <!-- More dropdown -->
      <li class="nav-more-item" id="navMoreItem">
        <button class="nav-link nav-more-btn <?= in_array($active_nav, ['watchorder','season-calendar','character','seasonal','search','birthdays','voice-actor']) ? 'active' : '' ?>" id="navMoreBtn" aria-haspopup="true" aria-expanded="false">
          More <i class="fa-solid fa-chevron-down" style="font-size:.65rem"></i>
        </button>
        <ul class="nav-more-dropdown" id="navMoreDropdown">
          <li><a href="<?= $base ?>/seasonal.php" class="<?= $active_nav === 'seasonal' ? 'active' : '' ?>">
            <i class="fa-solid fa-sun"></i> Seasonal Chart
          </a></li>
          <li><a href="<?= $base ?>/watchorder.php" class="<?= $active_nav === 'watchorder' ? 'active' : '' ?>">
            <i class="fa-solid fa-list-ol"></i> Watch Order
          </a></li>
          <li><a href="<?= $base ?>/season-calendar.php" class="<?= $active_nav === 'season-calendar' ? 'active' : '' ?>">
            <i class="fa-solid fa-table-cells"></i> Season Calendar
          </a></li>
          <li class="nav-dropdown-divider"></li>
          <li><a href="<?= $base ?>/characters.php" class="<?= $active_nav === 'character' ? 'active' : '' ?>">
            <i class="fa-solid fa-users"></i> Characters
          </a></li>
          <li><a href="<?= $base ?>/birthdays.php" class="<?= $active_nav === 'birthdays' ? 'active' : '' ?>">
            <i class="fa-solid fa-cake-candles"></i> Birthdays
          </a></li>
          <li class="nav-dropdown-divider"></li>
          <li><a href="<?= $base ?>/search.php" class="<?= $active_nav === 'search' ? 'active' : '' ?>">
            <i class="fa-solid fa-magnifying-glass"></i> Search
          </a></li>
        </ul>
      </li>
    </ul>

    <!-- Right actions -->
    <div class="nav-actions">
      <?php if (($active_nav ?? '') === 'schedule'): ?>
      <!-- Timezone selector (only on schedule page) -->
      <div class="nav-tz-wrap" id="navTzWrap">
        <i class="fa-solid fa-clock nav-tz-icon"></i>
        <select id="timezoneSelect" class="nav-tz-select" aria-label="Select timezone">
          <option value="auto">Auto-detect timezone</option>
        </select>
      </div>
      <?php endif; ?>
      <button class="nav-icon-btn" id="searchToggle" title="Search" aria-label="Search">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>
      <button class="nav-icon-btn" id="themeToggle" title="Toggle theme" aria-label="Toggle theme">
        <i class="fa-solid fa-moon" id="themeIcon"></i>
      </button>
      <button class="nav-icon-btn" id="notifBtn" title="Notifications" aria-label="Enable notifications">
        <i class="fa-solid fa-bell"></i>
      </button>

      <?php if ($user): ?>
        <div class="nav-user" id="userMenu">
          <button class="nav-avatar-btn" id="userMenuBtn" aria-label="User menu">
            <?php if ($user['avatar']): ?>
              <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="Avatar" class="nav-avatar">
            <?php else: ?>
              <span class="nav-avatar-initial"><?= strtoupper($user['username'][0]) ?></span>
            <?php endif; ?>
          </button>
          <div class="user-dropdown" id="userDropdown">
            <div class="dropdown-header">
              <strong><?= htmlspecialchars($user['username']) ?></strong>
              <small><?= htmlspecialchars($user['email']) ?></small>
            </div>
            <a href="<?= $base ?>/profile.php"><i class="fa-solid fa-list-check"></i> My Watchlist</a>
            <a href="<?= $base ?>/profile.php?tab=settings"><i class="fa-solid fa-gear"></i> Settings</a>
            <div class="dropdown-divider"></div>
            <a href="<?= $base ?>/logout.php" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
          </div>
        </div>
      <?php else: ?>
        <a href="<?= $base ?>/login.php" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-right-to-bracket"></i> Sign In
        </a>
      <?php endif; ?>

      <button class="nav-hamburger" id="hamburger" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>
    </div>

  </div>

  <!-- Mobile search bar -->
  <div class="nav-search-bar" id="navSearchBar">
    <form action="<?= $base ?>/search.php" method="get" class="nav-search-form">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" name="q" placeholder="Search anime..." autocomplete="off">
      <button type="submit">Search</button>
    </form>
  </div>
</nav>

<!-- ── Main content ──────────────────────────────────────── -->
<main class="main-content">
