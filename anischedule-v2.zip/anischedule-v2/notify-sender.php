<?php
// ============================================================
//  notify-sender.php — Cron/CLI script (NOT a web page)
//  Run via: php notify-sender.php
//  Cron example: */5 * * * * /usr/bin/php /path/to/notify-sender.php
//
//  Checks subscriptions for anime airing in the next 60 minutes
//  and sends Email or WhatsApp (Twilio) notifications.
// ============================================================

// Ensure this only runs from CLI
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo 'This script must be run from the command line.';
    exit(1);
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/api/anilist.php';

$log_file = __DIR__ . '/logs/notify-sender.log';
if (!is_dir(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

function ns_log(string $msg): void {
    global $log_file;
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL;
    file_put_contents($log_file, $line, FILE_APPEND | LOCK_EX);
    echo $line;
}

ns_log('notify-sender started.');

try {
    $pdo = db();
} catch (Throwable $e) {
    ns_log('DB connection failed: ' . $e->getMessage());
    exit(1);
}

// ── Step 1: Get all subscriptions grouped by anime_id ────────────────────────

$stmt = $pdo->query("SELECT * FROM notification_subscriptions ORDER BY anime_id");
$subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($subscriptions)) {
    ns_log('No subscriptions found. Exiting.');
    exit(0);
}

// Group by anime_id
$by_anime = [];
foreach ($subscriptions as $sub) {
    $by_anime[$sub['anime_id']][] = $sub;
}

ns_log('Found ' . count($by_anime) . ' unique anime with subscriptions.');

$now          = time();
$window_start = $now;
$window_end   = $now + 3600; // 60 minutes ahead

// ── Step 2: For each anime, fetch broadcast info from Jikan ──────────────────

foreach ($by_anime as $anime_id => $subs) {
    // Small delay to respect Jikan rate limits
    usleep(400000); // 400ms

    $anime = jikan_anime($anime_id);
    if (!$anime) {
        ns_log("  Anime {$anime_id}: could not fetch data, skipping.");
        continue;
    }

    $title    = $anime['title_english'] ?? $anime['title'] ?? 'Unknown Anime';
    $cover    = $anime['images']['jpg']['large_image_url'] ?? $anime['images']['jpg']['image_url'] ?? '';
    $airing   = $anime['airing'] ?? false;
    $broadcast = $anime['broadcast'] ?? [];

    if (!$airing) {
        ns_log("  Anime {$anime_id} ({$title}): not currently airing, skipping.");
        continue;
    }

    // Try to determine the next air timestamp from broadcast info
    // broadcast.day = "Mondays", broadcast.time = "23:30", broadcast.timezone = "Asia/Tokyo"
    $air_ts = calculate_next_air_time($broadcast);

    if (!$air_ts) {
        ns_log("  Anime {$anime_id} ({$title}): cannot determine air time, skipping.");
        continue;
    }

    if ($air_ts < $window_start || $air_ts > $window_end) {
        ns_log("  Anime {$anime_id} ({$title}): airs at " . date('Y-m-d H:i:s', $air_ts) . " — outside 60min window.");
        continue;
    }

    ns_log("  Anime {$anime_id} ({$title}): airs at " . date('Y-m-d H:i:s', $air_ts) . " — SENDING notifications.");

    $episode_aired_dt = date('Y-m-d H:i:s', $air_ts);

    foreach ($subs as $sub) {
        // Check if already sent
        $check = $pdo->prepare("
            SELECT id FROM notification_sent_log
            WHERE subscription_id = ? AND episode_aired_at = ?
        ");
        $check->execute([$sub['id'], $episode_aired_dt]);
        if ($check->fetch()) {
            ns_log("    Sub #{$sub['id']} ({$sub['contact_type']}:{$sub['contact_value']}): already sent, skipping.");
            continue;
        }

        // Send notification
        $sent = false;
        if ($sub['contact_type'] === 'email') {
            $sent = send_email_notification($sub, $title, $cover, $air_ts);
        } elseif ($sub['contact_type'] === 'whatsapp') {
            $sent = send_whatsapp_notification($sub, $title, $cover, $air_ts);
        }

        if ($sent) {
            // Log it
            $log_stmt = $pdo->prepare("
                INSERT IGNORE INTO notification_sent_log (subscription_id, episode_aired_at)
                VALUES (?, ?)
            ");
            $log_stmt->execute([$sub['id'], $episode_aired_dt]);
            ns_log("    Sub #{$sub['id']} ({$sub['contact_type']}:{$sub['contact_value']}): sent OK.");
        } else {
            ns_log("    Sub #{$sub['id']} ({$sub['contact_type']}:{$sub['contact_value']}): send FAILED.");
        }
    }
}

ns_log('notify-sender finished.');
exit(0);

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Given Jikan broadcast info, calculate the next UTC air timestamp.
 */
function calculate_next_air_time(array $broadcast): ?int {
    $day  = $broadcast['day']      ?? ''; // e.g. "Mondays"
    $time = $broadcast['time']     ?? ''; // e.g. "23:30"
    $tz   = $broadcast['timezone'] ?? 'Asia/Tokyo';

    if (!$day || !$time) return null;

    // Map Jikan day names to PHP day numbers (0=Sun…6=Sat)
    $day_map = [
        'sundays'    => 0, 'mondays' => 1, 'tuesdays' => 2,
        'wednesdays' => 3, 'thursdays' => 4, 'fridays' => 5, 'saturdays' => 6,
    ];
    $target_dow = $day_map[strtolower($day)] ?? null;
    if ($target_dow === null) return null;

    try {
        $tz_obj = new DateTimeZone($tz);
    } catch (Exception $e) {
        $tz_obj = new DateTimeZone('Asia/Tokyo');
    }

    // Build a DateTime for this week's occurrence in the broadcast timezone
    $now_local = new DateTime('now', $tz_obj);
    $cur_dow   = (int)$now_local->format('w'); // 0=Sun

    $diff = ($target_dow - $cur_dow + 7) % 7;
    $candidate = clone $now_local;
    $candidate->modify("+{$diff} days");
    $candidate->setTime((int)substr($time, 0, 2), (int)substr($time, 3, 2), 0);

    // If in the past (or within last 1 min), advance by 7 days
    $candidate_utc = (int)$candidate->getTimestamp();
    if ($candidate_utc < time() - 60) {
        $candidate->modify('+7 days');
        $candidate_utc = (int)$candidate->getTimestamp();
    }

    return $candidate_utc;
}

/**
 * Send a notification email via PHP mail()
 */
function send_email_notification(array $sub, string $title, string $cover, int $air_ts): bool {
    $to       = $sub['contact_value'];
    $subject  = "🎌 {$title} is airing now on AniSchedule!";
    $air_time = date('D, d M Y H:i T', $air_ts);

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:system-ui,sans-serif;background:#0a0e1a;color:#e2e8f0;margin:0;padding:0">
  <div style="max-width:560px;margin:0 auto;padding:32px 16px">
    <div style="text-align:center;margin-bottom:24px">
      <h1 style="font-size:1.6rem;color:#a78bfa;margin:0">AniSchedule</h1>
      <p style="color:#94a3b8;font-size:.9rem">Your anime notification</p>
    </div>
    <div style="background:#111827;border:1px solid rgba(255,255,255,.08);border-radius:12px;overflow:hidden">
      HTML;

    if ($cover) {
        $html .= '<img src="' . htmlspecialchars($cover) . '" alt="' . htmlspecialchars($title) . '" style="width:100%;max-height:220px;object-fit:cover">';
    }

    $html .= <<<HTML
      <div style="padding:24px">
        <h2 style="margin:0 0 8px;font-size:1.3rem;color:#e2e8f0">{$title}</h2>
        <p style="color:#94a3b8;margin:0 0 20px">A new episode is airing!</p>
        <p style="background:#1a2035;border-radius:8px;padding:12px;margin:0 0 20px;font-size:.9rem;color:#94a3b8">
          📅 Air time: <strong style="color:#e2e8f0">{$air_time}</strong>
        </p>
        <a href="
HTML;

    $html .= SITE_URL . '/anime.php?id=' . $sub['anime_id'];
    $html .= <<<HTML
" style="display:inline-block;background:#6366f1;color:#fff;text-decoration:none;padding:10px 24px;border-radius:8px;font-weight:600">
          Watch Now →
        </a>
      </div>
    </div>
    <p style="text-align:center;color:#475569;font-size:.78rem;margin-top:20px">
      You're receiving this because you subscribed on <a href="
HTML;

    $html .= SITE_URL;
    $html .= <<<HTML
" style="color:#6366f1">AniSchedule</a>.<br>
      To unsubscribe, visit the anime page and click the notification button again.
    </p>
  </div>
</body>
</html>
HTML;

    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . SITE_NAME . " <noreply@" . parse_url(SITE_URL, PHP_URL_HOST) . ">\r\n";
    $headers .= "X-Mailer: PHP/" . PHP_VERSION;

    return @mail($to, $subject, $html, $headers);
}

/**
 * Send a WhatsApp notification via Twilio API
 * Falls back to file log if Twilio not configured
 */
function send_whatsapp_notification(array $sub, string $title, string $cover, int $air_ts): bool {
    $to       = $sub['contact_value'];
    $air_time = date('D d M H:i T', $air_ts);
    $url_link = SITE_URL . '/anime.php?id=' . $sub['anime_id'];
    $message  = "🎌 *{$title}* is airing now!\n📅 {$air_time}\n\n👉 {$url_link}\n\n_AniSchedule — Never miss an episode_";

    // Check if Twilio is configured
    if (!defined('TWILIO_SID') || !TWILIO_SID || !defined('TWILIO_AUTH') || !TWILIO_AUTH || !defined('TWILIO_WHATSAPP_FROM') || !TWILIO_WHATSAPP_FROM) {
        // Log to file instead
        $log_path = __DIR__ . '/logs/whatsapp-queue.log';
        $entry = json_encode([
            'to'        => $to,
            'message'   => $message,
            'anime_id'  => $sub['anime_id'],
            'anime'     => $title,
            'queued_at' => date('c'),
        ]) . PHP_EOL;
        file_put_contents($log_path, $entry, FILE_APPEND | LOCK_EX);
        return true; // treat as "sent" so we don't spam logs
    }

    // Twilio WhatsApp API
    $twilio_url = 'https://api.twilio.com/2010-04-01/Accounts/' . TWILIO_SID . '/Messages.json';
    $payload    = http_build_query([
        'From' => 'whatsapp:' . TWILIO_WHATSAPP_FROM,
        'To'   => 'whatsapp:' . $to,
        'Body' => $message,
    ]);

    $ch = curl_init($twilio_url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_USERPWD        => TWILIO_SID . ':' . TWILIO_AUTH,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_USERAGENT      => 'AniSchedule/1.0',
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code === 201) return true;

    ns_log("    Twilio error (HTTP {$code}): " . substr($body, 0, 200));
    return false;
}
