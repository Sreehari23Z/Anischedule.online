<?php
require_once __DIR__ . '/config.php';
$page_title = 'API Documentation — ' . SITE_NAME;
$page_desc  = 'AniSchedule public API — access schedule, seasonal, and anime data in JSON format.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container" style="max-width:980px">

  <div class="legal-hero">
    <i class="fa-solid fa-code legal-hero-icon"></i>
    <h1>AniSchedule API</h1>
    <p>Access anime schedule and seasonal data in JSON format. Free for non-commercial use.</p>
  </div>

  <div class="api-notice">
    <i class="fa-solid fa-triangle-exclamation"></i>
    <div>
      <strong>Public Beta</strong> — The AniSchedule API is currently in public beta. Endpoints and response shapes may change. Pin your integrations to a specific version when available.
    </div>
  </div>

  <!-- Base URL -->
  <div class="api-section">
    <h2>Base URL</h2>
    <div class="api-code-block"><code>https://anischedule.net/api</code></div>
    <p>All responses are JSON. All requests are <code>GET</code>. No authentication is required for public endpoints.</p>
  </div>

  <!-- Rate limits -->
  <div class="api-section">
    <h2>Rate Limits</h2>
    <div class="api-limits-table">
      <div class="api-limits-row api-limits-header">
        <span>Plan</span><span>Requests / minute</span><span>Requests / day</span>
      </div>
      <div class="api-limits-row">
        <span><strong>Public (unauthenticated)</strong></span><span>20</span><span>2,000</span>
      </div>
      <div class="api-limits-row">
        <span><strong>Registered (API key)</strong></span><span>60</span><span>20,000</span>
      </div>
      <div class="api-limits-row">
        <span><strong>Commercial (contact us)</strong></span><span>Unlimited</span><span>Unlimited</span>
      </div>
    </div>
    <p>Responses include rate limit headers: <code>X-RateLimit-Limit</code>, <code>X-RateLimit-Remaining</code>, <code>X-RateLimit-Reset</code>.</p>
  </div>

  <!-- Endpoints -->
  <div class="api-section">
    <h2>Endpoints</h2>

    <!-- Schedule -->
    <div class="api-endpoint">
      <div class="api-endpoint-header">
        <span class="api-method get">GET</span>
        <span class="api-path">/api/schedule.php</span>
        <span class="api-desc-short">Airing schedule by day</span>
      </div>
      <div class="api-endpoint-body">
        <h4>Query Parameters</h4>
        <div class="api-params">
          <div class="api-param-row"><code>day</code><span class="api-param-opt">optional</span><span>Day of week: <code>monday</code> … <code>sunday</code>. Omit to fetch all 7 days.</span></div>
          <div class="api-param-row"><code>season</code><span class="api-param-opt">optional</span><span>Season name: <code>winter</code>, <code>spring</code>, <code>summer</code>, <code>fall</code>. Use with <code>year</code>.</span></div>
          <div class="api-param-row"><code>year</code><span class="api-param-opt">optional</span><span>4-digit year (e.g. <code>2026</code>). Defaults to current year when used with <code>season</code>.</span></div>
        </div>
        <h4>Example Request</h4>
        <div class="api-code-block"><code>GET /api/schedule.php?day=monday</code></div>
        <h4>Example Response</h4>
        <div class="api-code-block api-json"><pre>{
  "ok": true,
  "mode": "airing",
  "schedule": {
    "monday": [
      {
        "id": 52991,
        "title": "Witch Hat Atelier",
        "title_en": "Witch Hat Atelier",
        "title_jp": "とんがり帽子のアトリエ",
        "cover": "https://cdn.myanimelist.net/images/anime/...",
        "type": "TV",
        "episodes": 12,
        "score": 8.7,
        "members": 320000,
        "broadcast": { "day": "Mondays", "time": "19:30", "timezone": "Asia/Tokyo" },
        "genres": ["Fantasy", "Magic"],
        "studios": ["Madhouse"],
        "streaming": [
          { "name": "Crunchyroll", "url": "https://crunchyroll.com/..." }
        ],
        "url": "/anime.php?id=52991",
        "status": "Currently Airing",
        "airing": true
      }
    ]
  }
}</pre></div>
      </div>
    </div>

    <!-- Anime detail -->
    <div class="api-endpoint">
      <div class="api-endpoint-header">
        <span class="api-method get">GET</span>
        <span class="api-path">/api/anime-detail.php</span>
        <span class="api-desc-short">Full anime detail by MAL ID</span>
      </div>
      <div class="api-endpoint-body">
        <h4>Query Parameters</h4>
        <div class="api-params">
          <div class="api-param-row"><code>id</code><span class="api-param-req">required</span><span>MAL anime ID (integer).</span></div>
          <div class="api-param-row"><code>recs</code><span class="api-param-opt">optional</span><span>Set to <code>1</code> to include top 10 recommendation entries in the response.</span></div>
        </div>
        <h4>Example Request</h4>
        <div class="api-code-block"><code>GET /api/anime-detail.php?id=52991&recs=1</code></div>
        <h4>Response Fields</h4>
        <div class="api-params">
          <div class="api-param-row"><code>ok</code><span></span><span>Boolean — <code>true</code> on success.</span></div>
          <div class="api-param-row"><code>anime</code><span></span><span>Full anime object (title, synopsis, trailer, characters, relations, streaming, stats, etc.).</span></div>
          <div class="api-param-row"><code>recs</code><span class="api-param-opt">optional</span><span>Array of up to 10 recommended anime (id, title, cover, votes).</span></div>
        </div>
      </div>
    </div>

    <!-- Seasonal -->
    <div class="api-endpoint">
      <div class="api-endpoint-header">
        <span class="api-method get">GET</span>
        <span class="api-path">/api/seasonal.php</span>
        <span class="api-desc-short">Full seasonal anime list</span>
      </div>
      <div class="api-endpoint-body">
        <h4>Query Parameters</h4>
        <div class="api-params">
          <div class="api-param-row"><code>season</code><span class="api-param-req">required</span><span><code>winter</code>, <code>spring</code>, <code>summer</code>, or <code>fall</code>.</span></div>
          <div class="api-param-row"><code>year</code><span class="api-param-req">required</span><span>4-digit year.</span></div>
          <div class="api-param-row"><code>sort</code><span class="api-param-opt">optional</span><span><code>members</code> (default), <code>score</code>, <code>title</code>.</span></div>
          <div class="api-param-row"><code>type</code><span class="api-param-opt">optional</span><span>Filter by type: <code>TV</code>, <code>Movie</code>, <code>OVA</code>, <code>ONA</code>, <code>Special</code>.</span></div>
        </div>
        <h4>Example Request</h4>
        <div class="api-code-block"><code>GET /api/seasonal.php?season=spring&year=2026&sort=score</code></div>
      </div>
    </div>

    <!-- Search -->
    <div class="api-endpoint">
      <div class="api-endpoint-header">
        <span class="api-method get">GET</span>
        <span class="api-path">/api/search.php</span>
        <span class="api-desc-short">Search anime by title</span>
      </div>
      <div class="api-endpoint-body">
        <h4>Query Parameters</h4>
        <div class="api-params">
          <div class="api-param-row"><code>q</code><span class="api-param-req">required</span><span>Search query (min 3 characters).</span></div>
          <div class="api-param-row"><code>type</code><span class="api-param-opt">optional</span><span>Filter by type: <code>tv</code>, <code>movie</code>, <code>ova</code>, <code>ona</code>, <code>special</code>.</span></div>
          <div class="api-param-row"><code>page</code><span class="api-param-opt">optional</span><span>Page number (default: 1).</span></div>
        </div>
        <h4>Example Request</h4>
        <div class="api-code-block"><code>GET /api/search.php?q=attack+on+titan&type=tv</code></div>
      </div>
    </div>

  </div><!-- /api-section -->

  <!-- Error responses -->
  <div class="api-section">
    <h2>Error Responses</h2>
    <p>All errors return HTTP 200 with <code>"ok": false</code> and an <code>"error"</code> message string.</p>
    <div class="api-code-block api-json"><pre>{
  "ok": false,
  "error": "Invalid anime ID."
}</pre></div>
  </div>

  <!-- Caching -->
  <div class="api-section">
    <h2>Caching</h2>
    <p>All API responses are server-side cached:</p>
    <div class="api-params">
      <div class="api-param-row"><code>/api/schedule.php</code><span></span><span>30 minutes</span></div>
      <div class="api-param-row"><code>/api/seasonal.php</code><span></span><span>1 hour</span></div>
      <div class="api-param-row"><code>/api/anime-detail.php</code><span></span><span>2 hours</span></div>
      <div class="api-param-row"><code>/api/search.php</code><span></span><span>15 minutes</span></div>
    </div>
    <p>Upstream data is sourced from the <a href="https://jikan.moe/" target="_blank" rel="noopener">Jikan v4 API</a> (MyAnimeList). We are not affiliated with Jikan or MyAnimeList.</p>
  </div>

  <!-- Terms -->
  <div class="api-section">
    <h2>API Terms of Use</h2>
    <ul class="legal-body" style="margin:0">
      <li>Free for personal and open-source projects.</li>
      <li>Commercial use requires a paid plan — <a href="<?= $base ?>/contact.php?reason=API+Access">contact us</a>.</li>
      <li>Do not resell or republish raw API responses as your own data product.</li>
      <li>Credit "AniSchedule" or link back to <code>anischedule.net</code> in public projects.</li>
      <li>We reserve the right to block abusive clients without notice.</li>
    </ul>
  </div>

  <!-- CTA -->
  <div class="about-cta">
    <i class="fa-solid fa-key"></i>
    <div>
      <h3>Request an API Key</h3>
      <p>Get higher rate limits, usage analytics, and priority support for your integration.</p>
    </div>
    <a href="<?= $base ?>/contact.php?reason=API+Access" class="btn btn-primary">Request Access</a>
  </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
