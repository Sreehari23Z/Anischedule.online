<?php
// ============================================================
//  Season Calendar — /season-calendar.php
//  4-column grid (Winter/Spring/Summer/Fall) for a given year
// ============================================================
require_once __DIR__ . '/config.php';
$current_year = (int)date('Y');
$year = (int)($_GET['year'] ?? $current_year);
$year = max($current_year - 2, min($current_year + 2, $year));

$page_title = "Season Calendar {$year} — " . SITE_NAME;
$page_desc  = "All {$year} anime seasons at a glance — Winter, Spring, Summer, and Fall.";
$active_nav = 'season-calendar';
include __DIR__ . '/includes/header.php';
?>

<div class="page-calendar">

  <!-- ── Hero ───────────────────────────────────────────── -->
  <section class="upcoming-hero">
    <div class="upcoming-hero-inner">
      <h1 class="hero-title">Season <span class="gradient-text">Calendar</span></h1>
      <p class="hero-sub">All <?= $year ?> seasons in one place.</p>
      <!-- Year selector -->
      <div class="year-selector" style="margin-top:1.25rem">
        <?php for ($y = $current_year - 2; $y <= $current_year + 2; $y++): ?>
          <a href="<?= $base ?>/season-calendar.php?year=<?= $y ?>"
             class="year-btn <?= $y === $year ? 'active' : '' ?>"><?= $y ?></a>
        <?php endfor; ?>
      </div>
    </div>
  </section>

  <!-- ── Calendar grid ──────────────────────────────────── -->
  <div class="container" style="padding-top:2rem;padding-bottom:3rem">
    <div class="calendar-grid" id="calendarGrid">
      <?php
      $seasons = [
        'winter' => ['label'=>'❄️ Winter','months'=>'Jan–Mar'],
        'spring' => ['label'=>'🌸 Spring','months'=>'Apr–Jun'],
        'summer' => ['label'=>'☀️ Summer','months'=>'Jul–Sep'],
        'fall'   => ['label'=>'🍂 Fall',  'months'=>'Oct–Dec'],
      ];
      foreach ($seasons as $slug => $s): ?>
        <div class="calendar-column" id="col-<?= $slug ?>">
          <div class="calendar-col-header">
            <h2 class="calendar-season-title"><?= $s['label'] ?></h2>
            <span class="calendar-months"><?= $s['months'] ?></span>
          </div>
          <div class="calendar-anime-list" id="anime-<?= $slug ?>">
            <div class="loading-state" style="padding:2rem 0">
              <div class="spinner" style="width:28px;height:28px"></div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
(function(){
  const base    = window.SITE?.base ?? '';
  const year    = <?= $year ?>;
  const seasons = ['winter','spring','summer','fall'];

  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function loadSeason(season) {
    const container = document.getElementById('anime-' + season);
    fetch(`${base}/api/season-data.php?year=${year}&season=${season}`)
      .then(r => r.json())
      .then(json => {
        if (!json.ok || !json.data?.length) {
          container.innerHTML = `<p class="calendar-empty">No data available.</p>`;
          return;
        }
        container.innerHTML = json.data.slice(0, 30).map(a => {
          const title = a.title_en || a.title;
          const cover = a.cover || '';
          return `
            <a href="${base}/anime.php?id=${a.id}" class="calendar-anime-item" title="${escHtml(title)}">
              ${cover ? `<img src="${escHtml(cover)}" alt="${escHtml(title)}" class="calendar-anime-cover" loading="lazy">` : '<div class="calendar-anime-cover-placeholder"></div>'}
              <span class="calendar-anime-title">${escHtml(title)}</span>
            </a>`;
        }).join('');
      })
      .catch(() => {
        container.innerHTML = `<p class="calendar-empty">Failed to load.</p>`;
      });
  }

  seasons.forEach(s => loadSeason(s));
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
