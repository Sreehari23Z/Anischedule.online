<?php
// ============================================================
//  AniSchedule — Configuration
//  Edit DB_* constants to match your Hostinger MySQL credentials
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'anischedule');       // your database name
define('DB_USER', 'your_db_user');      // your database username
define('DB_PASS', 'your_db_password');  // your database password
define('DB_CHARSET', 'utf8mb4');

// Site — *** UPDATE SITE_URL WITH YOUR ACTUAL HOSTINGER DOMAIN ***
define('SITE_NAME', 'AniSchedule');
define('SITE_URL',  'https://yourdomain.com');  // ← CHANGE THIS to e.g. https://anischedule.com
define('SITE_DESC', 'Free anime airing schedule with timezone support, episode countdowns, seasonal charts, and streaming links.');

// Cache TTL (seconds)
define('CACHE_SCHEDULE', 1800);   // 30 min
define('CACHE_SEASONAL', 3600);   // 1 hour
define('CACHE_ANIME',    86400);  // 24 hours

// VAPID keys for Web Push notifications
// Generate at: https://web-push-codelab.glitch.me/
define('VAPID_PUBLIC',  'YOUR_VAPID_PUBLIC_KEY');
define('VAPID_PRIVATE', 'YOUR_VAPID_PRIVATE_KEY');
define('VAPID_SUBJECT', 'mailto:admin@yourdomain.com');

// Session lifetime (seconds)
define('SESSION_LIFETIME', 2592000); // 30 days

// Jikan v4 API base URL (free, no key needed)
define('JIKAN_API', 'https://api.jikan.moe/v4');

// AniList GraphQL API
define('ANILIST_API', 'https://graphql.anilist.co');

// Affiliate IDs — replace with your own
define('CRUNCHYROLL_AFFILIATE', '');   // add your Crunchyroll affiliate ID if you have one
define('AMAZON_AFFILIATE', '');        // e.g. 'yourtag-20'

// ── Twilio (for WhatsApp notifications via notify-sender.php) ─────────────
// Sign up at https://www.twilio.com/  — leave empty to disable WhatsApp sending
// (messages will be queued to logs/whatsapp-queue.log instead)
define('TWILIO_SID',            '');  // e.g. 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
define('TWILIO_AUTH',           '');  // Twilio Auth Token
define('TWILIO_WHATSAPP_FROM',  '');  // Your Twilio WhatsApp-enabled number, e.g. '+14155238886'

// Debug mode — set false on production
define('DEBUG', false);

// Asset version helper — appends ?v=filemtime to bust proxy/browser cache
function asset_ver(string $path): string {
    $full = __DIR__ . '/' . ltrim($path, '/');
    $v    = file_exists($full) ? filemtime($full) : time();
    return $path . '?v=' . $v;
}

// Timezone (server default)
date_default_timezone_set('UTC');

// Error reporting
if (DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
