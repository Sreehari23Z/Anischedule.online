<?php
// ============================================================
//  Login / Register Page
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';

if (auth_user()) { header('Location: /profile.php'); exit; }

$tab = $_GET['tab'] ?? 'login';
$page_title = ($tab === 'register' ? 'Create Account' : 'Sign In') . ' — ' . SITE_NAME;
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>
<div class="page-auth">
  <div class="auth-card">
    <div class="auth-logo">
      <img src="/assets/img/logo.svg" alt="<?= SITE_NAME ?>">
      <span><?= SITE_NAME ?></span>
    </div>
    <div class="auth-tabs">
      <button class="auth-tab <?= $tab !== 'register' ? 'active' : '' ?>" data-tab="login">Sign In</button>
      <button class="auth-tab <?= $tab === 'register' ? 'active' : '' ?>" data-tab="register">Create Account</button>
    </div>
    <div id="authMsg" class="auth-msg" style="display:none"></div>
    <form id="loginForm" class="auth-form <?= $tab === 'register' ? 'hidden' : '' ?>">
      <input type="hidden" name="action" value="login">
      <div class="form-group">
        <label for="loginEmail">Email</label>
        <input type="email" id="loginEmail" name="email" placeholder="you@example.com" required autocomplete="email">
      </div>
      <div class="form-group">
        <label for="loginPassword">Password</label>
        <div class="password-wrap">
          <input type="password" id="loginPassword" name="password" placeholder="••••••••" required autocomplete="current-password">
          <button type="button" class="pw-toggle" data-target="loginPassword"><i class="fa-solid fa-eye"></i></button>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-right-to-bracket"></i> Sign In
      </button>
      <p class="auth-switch">No account? <a href="#" class="switch-link" data-tab="register">Create one</a></p>
    </form>
    <form id="registerForm" class="auth-form <?= $tab !== 'register' ? 'hidden' : '' ?>">
      <input type="hidden" name="action" value="register">
      <div class="form-group">
        <label for="regUsername">Username</label>
        <input type="text" id="regUsername" name="username" placeholder="animefan123" required minlength="3" maxlength="50">
      </div>
      <div class="form-group">
        <label for="regEmail">Email</label>
        <input type="email" id="regEmail" name="email" placeholder="you@example.com" required>
      </div>
      <div class="form-group">
        <label for="regPassword">Password <small>(min. 8 characters)</small></label>
        <div class="password-wrap">
          <input type="password" id="regPassword" name="password" placeholder="••••••••" required minlength="8">
          <button type="button" class="pw-toggle" data-target="regPassword"><i class="fa-solid fa-eye"></i></button>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-block">
        <i class="fa-solid fa-user-plus"></i> Create Account
      </button>
      <p class="auth-switch">Have an account? <a href="#" class="switch-link" data-tab="login">Sign in</a></p>
    </form>
  </div>
</div>
<script>
(function(){
  const tabs={};document.querySelectorAll('.auth-tab').forEach(t=>tabs[t.dataset.tab]=t);
  const forms={login:document.getElementById('loginForm'),register:document.getElementById('registerForm')};
  const msgEl=document.getElementById('authMsg');
  function showTab(n){
    Object.values(tabs).forEach(t=>t.classList.toggle('active',t.dataset.tab===n));
    Object.entries(forms).forEach(([k,f])=>f.classList.toggle('hidden',k!==n));
    msgEl.style.display='none';
  }
  document.querySelectorAll('.auth-tab').forEach(t=>t.addEventListener('click',()=>showTab(t.dataset.tab)));
  document.querySelectorAll('.switch-link').forEach(l=>l.addEventListener('click',e=>{e.preventDefault();showTab(l.dataset.tab);}));
  document.querySelectorAll('.pw-toggle').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const inp=document.getElementById(btn.dataset.target);
      const show=inp.type==='password';inp.type=show?'text':'password';
      btn.innerHTML=show?'<i class="fa-solid fa-eye-slash"></i>':'<i class="fa-solid fa-eye"></i>';
    });
  });
  function showMsg(txt,type='error'){msgEl.textContent=txt;msgEl.className='auth-msg auth-msg-'+type;msgEl.style.display='block';}
  async function submitForm(form){
    const data=Object.fromEntries(new FormData(form).entries());
    const btn=form.querySelector('[type=submit]');
    btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Please wait…';
    try{
      const res=await fetch('/api/auth.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
      const json=await res.json();
      if(json.ok){showMsg('Success! Redirecting…','success');setTimeout(()=>window.location.href='/profile.php',800);}
      else{showMsg(json.error||'Something went wrong.');btn.disabled=false;btn.innerHTML=form.id==='loginForm'?'<i class="fa-solid fa-right-to-bracket"></i> Sign In':'<i class="fa-solid fa-user-plus"></i> Create Account';}
    }catch{showMsg('Network error.');btn.disabled=false;}
  }
  forms.login.addEventListener('submit',e=>{e.preventDefault();submitForm(forms.login);});
  forms.register.addEventListener('submit',e=>{e.preventDefault();submitForm(forms.register);});
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
