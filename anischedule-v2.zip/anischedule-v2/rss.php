<?php
require_once __DIR__ . '/config.php';

// If ?feed=schedule or ?feed=seasonal, serve actual XML
$feed = $_GET['feed'] ?? '';

if ($feed === 'schedule') {
    header('Content-Type: application/rss+xml; charset=UTF-8');
    require_once __DIR__ . '/api/anilist.php';
    $today = strtolower(date('l'));
    $items = [];
    try { $items = jikan_schedule($today); } catch (\Throwable $e) { $items = []; }
    echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>AniSchedule — Today's Airing Anime</title>
    <link><?= SITE_URL ?></link>
    <description>Anime airing today (<?= ucfirst($today) ?>) on AniSchedule</description>
    <language>en-us</language>
    <ttl>60</ttl>
    <atom:link href="<?= SITE_URL ?>/rss.php?feed=schedule" rel="self" type="application/rss+xml"/>
    <?php foreach ($items as $a): ?>
    <item>
      <title><?= htmlspecialchars($a['title'] ?? '') ?></title>
      <link><?= SITE_URL ?>/anime.php?id=<?= (int)($a['mal_id'] ?? 0) ?></link>
      <description><?= htmlspecialchars(mb_substr($a['synopsis'] ?? '', 0, 300)) ?>…</description>
      <guid isPermaLink="true"><?= SITE_URL ?>/anime.php?id=<?= (int)($a['mal_id'] ?? 0) ?></guid>
    </item>
    <?php endforeach; ?>
  </channel>
</rss>
<?php
    exit;
}

// HTML page
$page_title = 'RSS Feeds — ' . SITE_NAME;
$page_desc  = 'Subscribe to AniSchedule RSS feeds to get the latest airing and seasonal anime updates.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">

  <div class="legal-hero">
    <i class="fa-solid fa-rss legal-hero-icon" style="color:#f26522"></i>
    <h1>RSS Feeds</h1>
    <p>Subscribe to stay updated with the latest airing schedules and seasonal anime — in your favourite RSS reader.</p>
  </div>

  <div class="rss-feeds-grid">

    <div class="rss-feed-card">
      <div class="rss-feed-icon"><i class="fa-solid fa-calendar-day"></i></div>
      <div class="rss-feed-info">
        <h3>Today's Airing Anime</h3>
        <p>Updates every hour with all anime airing today, including air times, scores, and episode numbers.</p>
        <div class="rss-feed-url">
          <code><?= SITE_URL ?>/rss.php?feed=schedule</code>
          <a href="/rss.php?feed=schedule" class="btn btn-ghost btn-sm rss-sub-btn" target="_blank">
            <i class="fa-solid fa-rss"></i> Subscribe
          </a>
        </div>
      </div>
    </div>

    <div class="rss-feed-card">
      <div class="rss-feed-icon"><i class="fa-solid fa-sun"></i></div>
      <div class="rss-feed-info">
        <h3>Current Season Anime</h3>
        <p>All anime in the currently airing season — updated daily with scores, streaming links, and episode counts.</p>
        <div class="rss-feed-url">
          <code><?= SITE_URL ?>/rss.php?feed=seasonal</code>
          <a href="/rss.php?feed=seasonal" class="btn btn-ghost btn-sm rss-sub-btn" target="_blank">
            <i class="fa-solid fa-rss"></i> Subscribe
          </a>
        </div>
      </div>
    </div>

    <div class="rss-feed-card">
      <div class="rss-feed-icon"><i class="fa-solid fa-rocket"></i></div>
      <div class="rss-feed-info">
        <h3>Upcoming Anime</h3>
        <p>Newly announced anime and confirmed premiere dates — subscribe to never miss a new season announcement.</p>
        <div class="rss-feed-url">
          <code><?= SITE_URL ?>/rss.php?feed=upcoming</code>
          <a href="/rss.php?feed=upcoming" class="btn btn-ghost btn-sm rss-sub-btn" target="_blank">
            <i class="fa-solid fa-rss"></i> Subscribe
          </a>
        </div>
      </div>
    </div>

    <div class="rss-feed-card">
      <div class="rss-feed-icon"><i class="fa-solid fa-ranking-star"></i></div>
      <div class="rss-feed-info">
        <h3>Top Anime Chart</h3>
        <p>Weekly snapshot of the top 50 highest-rated anime — track how scores shift as new episodes air.</p>
        <div class="rss-feed-url">
          <code><?= SITE_URL ?>/rss.php?feed=top</code>
          <a href="/rss.php?feed=top" class="btn btn-ghost btn-sm rss-sub-btn" target="_blank">
            <i class="fa-solid fa-rss"></i> Subscribe
          </a>
        </div>
      </div>
    </div>

  </div>

  <!-- How to subscribe -->
  <div class="rss-howto">
    <h2>How to Subscribe</h2>
    <p>RSS feeds work with any feed reader. Copy the feed URL and paste it into your reader, or click Subscribe to open it directly.</p>
    <div class="rss-readers-grid">
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> Feedly</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> Inoreader</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> NewsBlur</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> NetNewsWire</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> Reeder</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> Miniflux</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> FreshRSS</div>
      <div class="rss-reader"><i class="fa-solid fa-check-circle"></i> Any Atom/RSS reader</div>
    </div>
  </div>

  <!-- Format info -->
  <div class="legal-body">
    <h2>Feed Format</h2>
    <p>All feeds are served as valid <strong>RSS 2.0</strong> with <code>atom:link</code> self-reference, UTF-8 encoding, and a 60-minute TTL. Each item includes:</p>
    <ul>
      <li>Anime title (English and Japanese)</li>
      <li>Direct link to the AniSchedule anime page</li>
      <li>Synopsis excerpt (up to 300 characters)</li>
      <li>Score, episode count, and broadcast time where available</li>
      <li>Unique <code>&lt;guid&gt;</code> for deduplication</li>
    </ul>
    <h2>Programmatic Access</h2>
    <p>If you're building an application, consider using the <a href="<?= $base ?>/api-docs.php">AniSchedule JSON API</a> instead — it provides richer data, filtering, and higher update frequency than RSS.</p>
  </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
