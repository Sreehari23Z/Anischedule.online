<?php
require_once __DIR__ . '/config.php';
$page_title = 'About — ' . SITE_NAME;
$page_desc  = 'Learn about AniSchedule — your ultimate anime airing schedule and tracker.';
$active_nav = '';
include __DIR__ . '/includes/header.php';
?>

<div class="page-legal container">

  <div class="legal-hero">
    <i class="fa-solid fa-circle-info legal-hero-icon"></i>
    <h1>About AniSchedule</h1>
    <p>Built by anime fans, for anime fans.</p>
  </div>

  <!-- Mission -->
  <div class="about-mission">
    <div class="about-mission-text">
      <h2>Our Mission</h2>
      <p>AniSchedule started with a single frustration shared by every seasonal anime watcher: keeping track of what airs, when it airs, and where to watch it. Episode trackers were scattered, schedules were buried in wikis, and timezone confusion was a weekly headache.</p>
      <p>We built AniSchedule to fix that — a clean, fast, and always up-to-date schedule that adjusts to <em>your</em> timezone, shows countdowns to the next episode, and links directly to every legal streaming platform.</p>
      <p>No accounts required to browse. No bloat. Just the anime schedule you actually need.</p>
    </div>
    <div class="about-stat-grid">
      <div class="about-stat">
        <span class="about-stat-num">900+</span>
        <span class="about-stat-label">Airing anime tracked</span>
      </div>
      <div class="about-stat">
        <span class="about-stat-num">50+</span>
        <span class="about-stat-label">Timezones supported</span>
      </div>
      <div class="about-stat">
        <span class="about-stat-num">Real-time</span>
        <span class="about-stat-label">Episode countdowns</span>
      </div>
      <div class="about-stat">
        <span class="about-stat-num">Free</span>
        <span class="about-stat-label">Always, forever</span>
      </div>
    </div>
  </div>

  <!-- Features -->
  <div class="about-features">
    <h2 class="about-section-title">What We Offer</h2>
    <div class="about-feature-grid">
      <div class="about-feature-card">
        <i class="fa-solid fa-calendar-week"></i>
        <h3>Weekly Grid Schedule</h3>
        <p>See every airing anime laid out across the week in a clean grid view. Filter by type, sort by popularity or score, and navigate week to week.</p>
      </div>
      <div class="about-feature-card">
        <i class="fa-solid fa-clock"></i>
        <h3>Timezone-Aware Countdowns</h3>
        <p>Every episode countdown is calculated in your local timezone automatically. Switch to any timezone at any time — from Asia/Tokyo to America/New_York.</p>
      </div>
      <div class="about-feature-card">
        <i class="fa-solid fa-sun"></i>
        <h3>Seasonal Charts</h3>
        <p>Browse every anime from Winter, Spring, Summer, or Fall seasons. Filter by genre, studio, format, and streaming platform.</p>
      </div>
      <div class="about-feature-card">
        <i class="fa-solid fa-rocket"></i>
        <h3>Upcoming Anime</h3>
        <p>Stay ahead of the next season. Our upcoming page tracks announced titles, premiere dates, and studios months in advance.</p>
      </div>
      <div class="about-feature-card">
        <i class="fa-solid fa-ranking-star"></i>
        <h3>Top Anime Charts</h3>
        <p>Explore the highest-rated anime across all time, by genre, or by season — powered by live MAL and AniList scores.</p>
      </div>
      <div class="about-feature-card">
        <i class="fa-solid fa-list-check"></i>
        <h3>Personal Watchlist</h3>
        <p>Create a free account to track what you're watching, plan to watch, or have completed. Sync your progress across devices.</p>
      </div>
    </div>
  </div>

  <!-- Data sources -->
  <div class="about-data">
    <h2 class="about-section-title">Our Data Sources</h2>
    <p class="about-data-intro">AniSchedule aggregates data from the most trusted anime databases in the world to give you the most accurate and complete information available.</p>
    <div class="about-source-grid">
      <div class="about-source-card">
        <div class="about-source-logo">MAL</div>
        <h3>MyAnimeList / Jikan</h3>
        <p>Schedule data, scores, episode counts, genres, studios, and streaming links — sourced via the Jikan v4 API, the unofficial MAL REST API.</p>
        <a href="https://jikan.moe/" target="_blank" rel="noopener">jikan.moe <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
      </div>
      <div class="about-source-card">
        <div class="about-source-logo">AL</div>
        <h3>AniList</h3>
        <p>Supplementary seasonal data, broadcast times, and streaming platform availability — sourced via the AniList GraphQL API.</p>
        <a href="https://anilist.co/" target="_blank" rel="noopener">anilist.co <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
      </div>
    </div>
    <p class="about-data-note"><i class="fa-solid fa-circle-exclamation"></i> AniSchedule is an independent fan site and is not affiliated with MyAnimeList, AniList, or any anime studio or streaming service.</p>
  </div>

  <!-- Contact CTA -->
  <div class="about-cta">
    <i class="fa-solid fa-envelope"></i>
    <div>
      <h3>Get in Touch</h3>
      <p>Found a bug? Have a feature request? Want to advertise? We'd love to hear from you.</p>
    </div>
    <a href="<?= $base ?>/contact.php" class="btn btn-primary">Contact Us</a>
  </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
