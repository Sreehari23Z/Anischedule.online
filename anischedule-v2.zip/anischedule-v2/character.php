<?php
// ============================================================
//  Character Detail — /character.php?id=MAL_CHARACTER_ID
// ============================================================
require_once __DIR__ . '/config.php';

$char_id = intval($_GET['id'] ?? 0);

// No ID → redirect to characters browser
if ($char_id <= 0) {
    header('Location: ' . ($base ?? '') . '/characters.php');
    exit;
}

require_once __DIR__ . '/api/anilist.php';
$char = jikan_character($char_id);

if ($char) {
    $name       = $char['name'] ?? 'Unknown';
    $name_jp    = $char['name_kanji'] ?? '';
    $about      = $char['about'] ?? '';
    $image      = $char['images']['jpg']['image_url'] ?? '';
    $nicknames  = $char['nicknames'] ?? [];
    $favorites  = $char['favorites'] ?? 0;
    $voices     = $char['voices'] ?? [];
    $anime_list = $char['anime'] ?? [];
    $manga_list = $char['manga'] ?? [];

    $first_anime = $anime_list[0]['anime']['title'] ?? '';
    $about_short = $about ? mb_substr(strip_tags($about), 0, 200) . '…' : '';

    $page_title = $name . ($first_anime ? " ({$first_anime})" : '') . ' — ' . SITE_NAME;
    $page_desc  = $about_short ?: "$name character profile, voice actors, and anime appearances on " . SITE_NAME . ".";
} else {
    $page_title = 'Character Not Found — ' . SITE_NAME;
    $page_desc  = 'Character data unavailable.';
    $name = $image = $name_jp = $about = '';
    $nicknames = $voices = $anime_list = $manga_list = [];
    $favorites = 0;
    $first_anime = '';
}

$active_nav = 'character';
include __DIR__ . '/includes/header.php';
?>

<?php if (!$char): ?>
<div class="container" style="padding:5rem 1rem;text-align:center">
  <i class="fa-solid fa-user-slash" style="font-size:3rem;color:var(--danger);margin-bottom:1rem;display:block"></i>
  <h2>Character Not Found</h2>
  <p style="color:var(--text3);margin:.75rem 0 1.5rem">No character with ID <?= $char_id ?> found, or the API is temporarily unavailable.</p>
  <a href="<?= $base ?>/characters.php" class="btn btn-primary"><i class="fa-solid fa-arrow-left"></i> Browse Characters</a>
</div>
<?php else: ?>

<div class="page-char-detail">

  <!-- ── Hero ─────────────────────────────────────────────── -->
  <section class="char-detail-hero">
    <?php if ($image): ?>
      <div class="char-detail-hero-bg" style="background-image:url('<?= htmlspecialchars($image) ?>')"></div>
    <?php endif; ?>
    <div class="char-detail-hero-overlay"></div>

    <div class="container">
      <div class="char-detail-hero-inner">

        <!-- Avatar -->
        <div class="char-detail-avatar-wrap">
          <?php if ($image): ?>
            <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($name) ?>" class="char-detail-avatar">
          <?php else: ?>
            <div class="char-detail-avatar char-detail-avatar-ph"><i class="fa-solid fa-user"></i></div>
          <?php endif; ?>
        </div>

        <!-- Info -->
        <div class="char-detail-hero-info">
          <nav class="char-detail-breadcrumb" aria-label="breadcrumb">
            <a href="<?= $base ?>/characters.php">Characters</a>
            <i class="fa-solid fa-chevron-right" style="font-size:.6rem;opacity:.5"></i>
            <span><?= htmlspecialchars($name) ?></span>
          </nav>

          <h1 class="char-detail-name"><?= htmlspecialchars($name) ?></h1>
          <?php if ($name_jp): ?>
            <p class="char-detail-name-jp"><?= htmlspecialchars($name_jp) ?></p>
          <?php endif; ?>

          <?php if ($nicknames): ?>
            <p class="char-detail-nicknames">
              <i class="fa-solid fa-tag" style="opacity:.6;font-size:.8rem"></i>
              <?= htmlspecialchars(implode(' · ', $nicknames)) ?>
            </p>
          <?php endif; ?>

          <!-- Anime appearances -->
          <div class="char-detail-anime-pills">
            <?php foreach (array_slice($anime_list, 0, 4) as $ap): ?>
              <a href="<?= $base ?>/anime.php?id=<?= $ap['anime']['mal_id'] ?>" class="char-detail-anime-pill">
                <?= htmlspecialchars($ap['anime']['title'] ?? '') ?>
              </a>
            <?php endforeach; ?>
          </div>

          <!-- Stats row -->
          <div class="char-detail-stats">
            <div class="char-detail-stat">
              <i class="fa-solid fa-heart"></i>
              <span><?= number_format($favorites) ?> favourites</span>
            </div>
            <?php if ($anime_list): ?>
            <div class="char-detail-stat">
              <i class="fa-solid fa-tv"></i>
              <span><?= count($anime_list) ?> anime</span>
            </div>
            <?php endif; ?>
            <?php if ($voices): ?>
            <div class="char-detail-stat">
              <i class="fa-solid fa-microphone"></i>
              <span><?= count($voices) ?> VA<?= count($voices) > 1 ? 's' : '' ?></span>
            </div>
            <?php endif; ?>
          </div>

          <div class="char-detail-actions" style="margin-top:1.2rem">
            <a href="<?= htmlspecialchars($char['url'] ?? '') ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> View on MAL
            </a>
          </div>
        </div><!-- /hero-info -->
      </div>
    </div>
  </section>

  <!-- ── Tabs ──────────────────────────────────────────────── -->
  <div class="char-tabs-bar">
    <div class="container">
      <div class="char-tabs" role="tablist">
        <button class="char-tab active" data-tab="overview" role="tab" aria-selected="true">Overview</button>
        <?php if ($voices): ?>
          <button class="char-tab" data-tab="voices" role="tab">Voice Actors <span class="char-tab-count"><?= count($voices) ?></span></button>
        <?php endif; ?>
        <?php if ($anime_list): ?>
          <button class="char-tab" data-tab="anime" role="tab">Anime <span class="char-tab-count"><?= count($anime_list) ?></span></button>
        <?php endif; ?>
        <?php if ($manga_list): ?>
          <button class="char-tab" data-tab="manga" role="tab">Manga <span class="char-tab-count"><?= count($manga_list) ?></span></button>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- ── Panels ────────────────────────────────────────────── -->
  <div class="container" style="padding-top:1.5rem;padding-bottom:3rem">

    <!-- OVERVIEW -->
    <div class="char-tab-panel active" id="tab-overview" role="tabpanel">
      <div class="char-overview-layout">

        <!-- About column -->
        <div>
          <div class="char-card-box">
            <h3 class="char-box-heading"><i class="fa-solid fa-circle-info"></i> About</h3>
            <?php if ($about): ?>
              <div class="char-about-body" id="charAboutBody">
                <?= nl2br(htmlspecialchars(mb_substr($about, 0, 900))) ?>
                <?php if (mb_strlen($about) > 900): ?>
                  <div id="charAboutExtra" style="display:none"><?= nl2br(htmlspecialchars(mb_substr($about, 900))) ?></div>
                  <button class="char-read-more-btn" id="charReadMoreBtn">
                    Read more <i class="fa-solid fa-chevron-down"></i>
                  </button>
                <?php endif; ?>
              </div>
            <?php else: ?>
              <p style="color:var(--text3);font-style:italic">No description available for this character.</p>
            <?php endif; ?>
          </div>
        </div>

        <!-- Sidebar -->
        <div>
          <!-- Quick facts -->
          <div class="char-card-box">
            <h3 class="char-box-heading"><i class="fa-solid fa-list"></i> Quick Facts</h3>
            <div class="char-facts">
              <div class="char-fact">
                <span class="char-fact-lbl">Favourites</span>
                <span class="char-fact-val"><?= number_format($favorites) ?></span>
              </div>
              <?php if ($nicknames): ?>
              <div class="char-fact">
                <span class="char-fact-lbl">Nicknames</span>
                <span class="char-fact-val"><?= htmlspecialchars(implode(', ', $nicknames)) ?></span>
              </div>
              <?php endif; ?>
              <div class="char-fact">
                <span class="char-fact-lbl">Anime</span>
                <span class="char-fact-val"><?= count($anime_list) ?> appearance<?= count($anime_list) !== 1 ? 's' : '' ?></span>
              </div>
              <?php if ($manga_list): ?>
              <div class="char-fact">
                <span class="char-fact-lbl">Manga</span>
                <span class="char-fact-val"><?= count($manga_list) ?> appearance<?= count($manga_list) !== 1 ? 's' : '' ?></span>
              </div>
              <?php endif; ?>
              <div class="char-fact">
                <span class="char-fact-lbl">Voice Actors</span>
                <span class="char-fact-val"><?= count($voices) ?: 'N/A' ?></span>
              </div>
            </div>
          </div>

          <!-- Japanese VA highlight -->
          <?php
          $ja_va = null;
          foreach ($voices as $v) {
              if (strtolower($v['language'] ?? '') === 'japanese') { $ja_va = $v; break; }
          }
          if ($ja_va):
            $vp = $ja_va['person'];
          ?>
          <div class="char-card-box" style="margin-top:1rem">
            <h3 class="char-box-heading"><i class="fa-solid fa-microphone"></i> Japanese VA</h3>
            <a href="<?= $base ?>/voice-actor.php?id=<?= $vp['mal_id'] ?>" class="char-va-highlight">
              <img src="<?= htmlspecialchars($vp['images']['jpg']['image_url'] ?? '') ?>"
                   alt="<?= htmlspecialchars($vp['name']) ?>"
                   onerror="this.src='<?= $base ?>/assets/img/placeholder-char.svg'"
                   class="char-va-hl-img">
              <div>
                <div class="char-va-hl-name"><?= htmlspecialchars($vp['name']) ?></div>
                <div class="char-va-hl-role">Japanese</div>
              </div>
              <i class="fa-solid fa-chevron-right" style="margin-left:auto;opacity:.4"></i>
            </a>
          </div>
          <?php endif; ?>
        </div>

      </div><!-- /overview-layout -->
    </div>

    <!-- VOICE ACTORS -->
    <?php if ($voices): ?>
    <div class="char-tab-panel" id="tab-voices" role="tabpanel">
      <h3 class="char-box-heading" style="margin-bottom:1.25rem"><i class="fa-solid fa-microphone"></i> Voice Actors</h3>
      <div class="char-va-grid">
        <?php foreach ($voices as $v):
          $vp   = $v['person'] ?? [];
          $lang = $v['language'] ?? '';
          $vid  = $vp['mal_id'] ?? 0;
        ?>
        <a href="<?= $base ?>/voice-actor.php?id=<?= $vid ?>" class="char-va-card2">
          <img src="<?= htmlspecialchars($vp['images']['jpg']['image_url'] ?? '') ?>"
               alt="<?= htmlspecialchars($vp['name'] ?? '') ?>"
               onerror="this.src='<?= $base ?>/assets/img/placeholder-char.svg'"
               class="char-va-card2-img">
          <div class="char-va-card2-info">
            <span class="char-va-card2-name"><?= htmlspecialchars($vp['name'] ?? '') ?></span>
            <span class="char-va-card2-lang"><?= htmlspecialchars($lang) ?></span>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- ANIME -->
    <?php if ($anime_list): ?>
    <div class="char-tab-panel" id="tab-anime" role="tabpanel">
      <h3 class="char-box-heading" style="margin-bottom:1.25rem"><i class="fa-solid fa-tv"></i> Anime Appearances</h3>
      <div class="char-appear-list">
        <?php foreach ($anime_list as $ap):
          $a = $ap['anime'] ?? [];
        ?>
        <a href="<?= $base ?>/anime.php?id=<?= $a['mal_id'] ?>" class="char-appear-row">
          <img src="<?= htmlspecialchars($a['images']['jpg']['image_url'] ?? '') ?>"
               alt="<?= htmlspecialchars($a['title'] ?? '') ?>"
               onerror="this.src='<?= $base ?>/assets/img/placeholder.svg'"
               class="char-appear-img">
          <div class="char-appear-info">
            <span class="char-appear-title"><?= htmlspecialchars($a['title'] ?? '') ?></span>
            <span class="char-appear-role"><?= htmlspecialchars($ap['role'] ?? '') ?></span>
          </div>
          <i class="fa-solid fa-chevron-right char-appear-arrow"></i>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- MANGA -->
    <?php if ($manga_list): ?>
    <div class="char-tab-panel" id="tab-manga" role="tabpanel">
      <h3 class="char-box-heading" style="margin-bottom:1.25rem"><i class="fa-solid fa-book"></i> Manga Appearances</h3>
      <div class="char-appear-list">
        <?php foreach ($manga_list as $mp):
          $m = $mp['manga'] ?? [];
        ?>
        <div class="char-appear-row">
          <img src="<?= htmlspecialchars($m['images']['jpg']['image_url'] ?? '') ?>"
               alt="<?= htmlspecialchars($m['title'] ?? '') ?>"
               onerror="this.src='<?= $base ?>/assets/img/placeholder.svg'"
               class="char-appear-img">
          <div class="char-appear-info">
            <span class="char-appear-title"><?= htmlspecialchars($m['title'] ?? '') ?></span>
            <span class="char-appear-role"><?= htmlspecialchars($mp['role'] ?? '') ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div><!-- /container -->
</div><!-- /page-char-detail -->

<script>
(function(){
  // Tab switching
  const tabs   = document.querySelectorAll('.char-tab');
  const panels = document.querySelectorAll('.char-tab-panel');
  tabs.forEach(btn => {
    btn.addEventListener('click', () => {
      tabs.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
      panels.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      btn.setAttribute('aria-selected','true');
      const target = document.getElementById('tab-' + btn.dataset.tab);
      if (target) target.classList.add('active');
    });
  });

  // Read more
  const rmBtn = document.getElementById('charReadMoreBtn');
  if (rmBtn) {
    rmBtn.addEventListener('click', () => {
      const extra = document.getElementById('charAboutExtra');
      const open  = extra.style.display !== 'none';
      extra.style.display = open ? 'none' : 'block';
      rmBtn.innerHTML = open
        ? 'Read more <i class="fa-solid fa-chevron-down"></i>'
        : 'Show less <i class="fa-solid fa-chevron-up"></i>';
    });
  }
})();
</script>

<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
